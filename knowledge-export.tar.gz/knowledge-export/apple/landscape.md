# Apple Intelligence 현황 (2024-2026)

> 최종 업데이트: 2026-02-18 | 소스: Apple 공식, Wikipedia, MacRumors, 9to5Mac, Apple Security Research

---

## 1. 개요

Apple Intelligence는 Apple이 개발한 생성형 AI 시스템으로, 온디바이스 처리와 서버 처리를 결합한다. 2024년 6월 10일 WWDC에서 발표되었으며, iOS 18, iPadOS 18, macOS Sequoia에 내장된 기능으로 출시되었다. **지원 기기를 가진 모든 사용자에게 무료 제공.**

### 핵심 철학
- **프라이버시 우선**: 온디바이스 처리 + Private Cloud Compute
- **시스템 전반 통합**: OS 레벨에서 모든 앱에 AI 기능 제공
- **무료**: 추가 요금 없음 (ChatGPT 유료 기능 제외)

---

## 2. 주요 기능

### 2.1 Writing Tools
- **교정(Proofread)**: 맞춤법, 문법, 단어 선택, 문장 구조 검사
- **리라이트(Rewrite)**: Friendly / Professional / Concise 톤 변환
- **요약(Summarize)**: 단락, 핵심 포인트, 리스트, 테이블 형태로 요약
- **오픈엔드 편집**: 원하는 변경 사항을 자유롭게 서술
- **Compose**: ChatGPT 통합으로 처음부터 텍스트 생성
- 텍스트 선택 가능한 모든 곳에서 사용 가능

### 2.2 Siri 개편
- **새 UI**: 화면 가장자리 글로우 애니메이션 (iPhone/iPad/CarPlay)
- **Type to Siri**: 화면 하단 더블탭으로 텍스트 입력 (Mac: Cmd 2회)
- **대화 맥락 유지**: 이전 질문 참조 가능
- **자연어 처리 향상**: 말 더듬거리거나 문장 중간 변경 시 인식
- **제품 지식**: Apple 지원 문서 기반 기기 설정/기능 질문 응답
- **ChatGPT 통합** (iOS 18.2+): 복잡한 요청을 ChatGPT(GPT-4o)에 위임, 옵트인 방식
- **향후**: 온스크린 인지, 개인 맥락, 앱 간 액션 (2025년 후반~)

### 2.3 이미지 생성
- **Image Playground**: 텍스트 프롬프트로 Animation/Illustration/Sketch 스타일 이미지 생성
  - 독립 앱 + Messages/Notes 통합
  - iOS/iPadOS/macOS 26에서 ChatGPT 이미지 모델 통합
  - **포토리얼리스틱 이미지 생성 불가** (의도적 제한)
- **Image Wand**: Notes 앱에서 텍스트/빈 공간을 맥락 관련 이미지로 변환
  - iPad에서 Apple Pencil 스케치 → 정교한 이미지 변환
- **Genmoji**: 텍스트 설명으로 커스텀 이모지 생성
  - 인라인 메시지, 스티커로 사용 가능
  - iOS 18.1 미만/Android에서는 제대로 표시 안됨

### 2.4 Photos
- **Memory Movie**: 설명만으로 자동 포토 무비 생성 ("내 고양이 2024년")
- **Clean Up**: 배경의 불필요한 오브젝트 제거 (탭/원/브러시)
- **자연어 검색**: "Eric이 초록색 옷 입고 롤러스케이팅" 같은 검색
- **비디오 내 특정 순간 검색**

### 2.5 Mail
- **이메일 요약**: 인박스 리스트에서 첫 줄 대신 AI 요약 표시
- **Priority Messages**: 긴급 이메일 (당일 초대, 탑승권) 우선 표시
- **Smart Reply**: 맥락 기반 빠른 답장 옵션
- **메일 분류**: Primary / Transactions / Updates / Promotions (온디바이스)

### 2.6 알림 요약
- **Notification Summary**: 여러 알림을 한 줄로 요약
- **Reduce Interruptions Focus**: 중요한 알림만 표시, 나머지 무음

### 2.7 Visual Intelligence (iPhone 16+)
- Camera Control 버튼 길게 누르면 활성화
- 물체/가게 정보 조회, ChatGPT로 질문, Google 검색
- 텍스트 읽기, 전화번호/주소 인식, 텍스트 복사
- iOS 18.4부터 iPhone 15 Pro/16e에서도 사용 가능

### 2.8 실시간 번역
- Messages, FaceTime, 전화 통화에서 실시간 번역
- AirPods Live Translation으로 대면 대화 동시통역

### 2.9 통화 녹음 및 요약
- 통화 녹음 + 전사(transcription) → AI 요약 생성
- Notes 앱에 저장

---

## 3. 기술 아키텍처

### 3.1 온디바이스 모델
- Apple 자체 foundation model + 특화 adapter 모델 (요약, 톤 조정 등)
- Apple Silicon (A17 Pro / M1 이상) 필수 — Neural Engine 성능 요구
- **성능 벤치마크** (Apple 자체 평가):
  - 온디바이스 모델: Mistral, Microsoft, Google의 동급 소형 모델과 동등 또는 우위
  - 서버 모델: GPT-3 능가, GPT-4에 근접

### 3.2 Private Cloud Compute (PCC)
- **Apple의 가장 혁신적인 프라이버시 기술**
- Apple Silicon 기반 커스텀 서버 하드웨어
- iOS/macOS에서 파생된 hardened OS
- **핵심 보장 사항**:
  1. **Stateless 처리**: 사용자 데이터는 요청 처리 후 삭제, 로깅 없음
  2. **기술적으로 강제 가능한 보장**: TLS 로드밸런서 등 외부 컴포넌트에 의존하지 않음
  3. **특권 접근 불가**: Apple SRE도 데이터 접근 불가
  4. **비표적성**: 특정 사용자 타겟팅 불가, 전체 시스템 공격 필요
  5. **검증 가능한 투명성**: 보안 연구자가 서버 소프트웨어 검증 가능
- End-to-end 암호화: 사용자 기기 → PCC 노드 직접 암호화
- Secure Boot + Code Signing으로 인증된 코드만 실행
- JIT 컴파일/코드 인젝션 차단

### 3.3 Google Gemini 파트너십 (2026년 1월 발표)
- Apple-Google 다년 파트너십
- Gemini 모델 (1.2조 파라미터) 온디바이스 통합 예정
- Apple 자체 모델 개발이 차질을 겪으면서 추진
- Private Cloud Compute 체계는 유지

### 3.4 Foundation Models Framework (WWDC 2025)
- 서드파티 개발자에게 온디바이스 foundation model API 공개
- Swift 3줄로 모델 접근 가능
- 구조화된 데이터 응답, tool calling 지원
- 오프라인 동작, 요청당 무료

---

## 4. 출시 타임라인

| 버전 | 날짜 | 주요 기능 |
|------|------|-----------|
| iOS 18.1 / macOS 15.1 | 2024-10-28 | Writing Tools (교정/요약/리라이트), 새 Siri UI, Smart Reply, 알림 요약, Photos Clean Up, Memory Maker |
| iOS 18.2 / macOS 15.2 | 2024-12-11 | Image Playground, Genmoji, Siri ChatGPT 통합, Visual Intelligence, Mail 분류, Compose |
| iOS 18.4 / macOS 15.4 | 2025-03-31 | Priority Notifications, Image Playground Sketch, Visual Intelligence 확대 |
| iOS 26.0 / macOS 26 | 2025-09-15 | 실시간 번역, 향상된 Genmoji/Visual Intelligence, Image Playground ChatGPT 통합, Foundation Models Framework, Apple Watch Workout Buddy |
| iOS 26.1 | 2025-11-03 | 추가 언어: 중국어(번체), 덴마크어, 네덜란드어, 노르웨이어, 스웨덴어, 터키어 |
| iOS 26.4 | TBA | Playlist Playground |

### 언어 지원 확대
- 2024-10: 영어(미국)만
- 2024-12: 영어 6개 지역
- 2025-03: 중국어(간체), 프랑스어, 독일어, 이탈리아어, 일본어, 한국어, 포르투갈어, 스페인어, 베트남어 등
- 2025-11: 중국어(번체), 덴마크어, 네덜란드어, 노르웨이어, 스웨덴어, 터키어

---

## 5. 지원 기기

### iPhone
- iPhone 15 Pro / 15 Pro Max (A17 Pro)
- iPhone 16e / 16 / 16 Plus (A18) / 16 Pro / 16 Pro Max (A18 Pro)
- iPhone 17 / 17 Pro / 17 Pro Max (A19/A19 Pro)
- iPhone Air (A19 Pro)

### iPad
- iPad Pro (M1, 5세대, 2021) 이상
- iPad Air (M1, 5세대, 2022) 이상
- iPad mini (A17 Pro, 7세대, 2024) 이상

### Mac
- MacBook Air/Pro (M1, 2020) 이상
- iMac (M1, 2021) 이상
- Mac mini (M1, 2020) 이상
- Mac Studio (M1 Max/Ultra, 2022) 이상
- Mac Pro (M2 Ultra, 2023)

### 기타
- Apple Vision Pro (M2) 이상 (visionOS 2.4, 2025-03-31~)

---

## 6. 강점

1. **프라이버시**: 업계 최고 수준의 프라이버시 보호. PCC는 클라우드 AI의 새로운 기준 제시
2. **시스템 통합**: OS 레벨 통합으로 어디서나 자연스럽게 사용 가능
3. **무료**: 추가 비용 없이 모든 지원 기기 사용자에게 제공
4. **개발자 생태계**: Foundation Models Framework로 서드파티 앱에 AI 기능 무료 제공
5. **하드웨어-소프트웨어 수직 통합**: Neural Engine 최적화, 온디바이스 처리 효율
6. **ChatGPT 통합**: OpenAI 파트너십으로 복잡한 요청 처리 능력 확보
7. **Google Gemini 통합 예정**: 1.2조 파라미터 모델로 성능 대폭 강화 기대

---

## 7. 약점 & 비판

1. **기기 제한**: A17 Pro / M1 이상만 지원 → 구형 기기 사용자 배제
2. **점진적 출시**: 핵심 기능(온스크린 인지, 개인 맥락 Siri)이 아직 미출시 또는 진행 중
3. **이미지 생성 품질**: Image Playground는 카툰/일러스트 스타일만 — 포토리얼리스틱 불가
4. **알림 요약 논란**: 뉴스 등의 요약이 부정확할 수 있다는 비판 (BBC 등 언론사 지적)
5. **자체 모델 한계**: Apple 자체 foundation model 개발 차질 → Google Gemini 의존으로 방향 전환
6. **언어 지원 지연**: 영어 이외 언어 지원이 수개월씩 지연
7. **외장 드라이브 부팅 시 사용 불가** (Mac)
8. **경쟁사 대비 뒤처진 출발**: ChatGPT 출시(2022말)에 놀랐고, 후발 주자로 시작

---

## 8. 커뮤니티/전문가 평가

### 긍정적
- 프라이버시 접근법은 업계에서 유일무이하며, PCC 아키텍처는 "클라우드 AI 보안의 세대적 도약"
- Writing Tools는 실용적이며 일상에서 가장 많이 사용되는 기능
- 시스템 전반 통합이 경쟁사 대비 자연스러움
- Foundation Models Framework 공개는 개발자 생태계에 긍정적

### 부정적
- "혁신이 아니라 따라잡기" — 경쟁사가 이미 제공하던 기능의 Apple 버전
- Siri 개선이 약속 대비 느림
- Image Playground 품질이 Midjourney/DALL-E 대비 현저히 뒤처짐
- 알림 요약의 부정확성이 실제 오해를 유발할 수 있음
- Google Gemini 파트너십은 Apple의 자체 AI 역량 부족을 방증

### 시장 영향
- Apple Intelligence는 iPhone 업그레이드 동기 부여에는 기대만큼 크지 않았다는 분석
- 그러나 20억+ Apple 기기 생태계에 AI 기능 기본 탑재는 장기적으로 의미 있음
- Xiaomi가 Writing Tools를 복제하는 등, 업계 트렌드에 영향

---

## 9. 2025-2026 전망

1. **Siri 대규모 업데이트**: 온스크린 인지, 개인 맥락, 앱 간 액션 (2025 후반~2026)
2. **Google Gemini 통합 본격화**: 온디바이스 Gemini 모델로 성능 도약 예상
3. **다국어 확대**: 2025-2026에 걸쳐 지속 확대
4. **Foundation Models Framework 활용 앱 생태계 성장**
5. **iOS 19/macOS 27에서 다음 세대 AI 기능 발표 예상 (WWDC 2026)**
6. **Apple Watch 확장**: Workout Buddy 시작으로 웨어러블 AI 확대

---

## 소스

- Apple 공식 사이트: https://www.apple.com/apple-intelligence/
- Apple Developer: https://developer.apple.com/apple-intelligence/
- Apple Security Research (PCC): https://security.apple.com/blog/private-cloud-compute
- Wikipedia: https://en.wikipedia.org/wiki/Apple_Intelligence
- MacRumors Guide: https://www.macrumors.com/guide/apple-intelligence/
- 9to5Mac Guide: https://9to5mac.com/guides/apple-intelligence/
