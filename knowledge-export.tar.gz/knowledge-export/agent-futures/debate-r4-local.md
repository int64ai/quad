# 토론 R4: 로컬/온디바이스 에이전트

**작성일:** 2026-02-18  
**주제:** "Llama 4, Phi-4, Qwen3.5로 완전히 로컬에서 동작하는 개인 AI 에이전트가 가능한가? 괴리가 있는가?"

---

## 1. 현황 분석: 로컬 LLM 생태계의 2026년

### 모델 지형도

2026년 2월 기준, 로컬에서 실행할 수 있는 오픈웨이트 모델의 수준은 1년 전과 비교하면 극적으로 진화했다:

| 모델 | 아키텍처 | 활성 파라미터 | 전체 파라미터 | 특징 |
|------|---------|-------------|-------------|------|
| **Llama 4 Scout** | MoE | 17B | 109B | 16개 전문가, 10M 토큰 컨텍스트, 멀티모달 |
| **Llama 4 Maverick** | MoE | 17B | 400B | 128개 전문가, GPT-4o급 벤치마크 주장 |
| **Qwen3-32B** | Dense | 32B | 32B | 강력한 tool use, 한중일 다국어 |
| **Qwen3-VL** | Dense+Vision | 다양 | 다양 | 비전 + 텍스트, 로컬에서 인기 |
| **Phi-4** | Dense | 14B | 14B | Microsoft, 추론 특화, 소형 장치 겨냥 |
| **GPT-OSS 20B/120B** | MoE | 20B/120B | — | OpenAI 오픈웨이트, 에이전틱 RL 검증 중 |
| **Gemma 3** | Dense | 다양 | 다양 | Google, 경량 모바일 타겟 |

핵심 트렌드: **MoE(Mixture of Experts) 아키텍처의 대중화**. Llama 4 Scout는 전체 109B 파라미터지만 추론 시 17B만 활성화한다. 이론적으로 "거대한 모델을 작은 VRAM으로" 돌릴 수 있다는 약속이지만, 실제로는 전체 가중치를 메모리에 올려야 하므로 VRAM/RAM 요구량은 여전히 크다.

### 실행 환경: Ollama, LM Studio, llama.cpp

HN의 "Ask HN: Are you running local LLMs?" (2025.08, briansun) 스레드가 현재 생태계를 잘 보여준다:

> "2025 feels like a breakout year for local models. Open-weight releases are getting genuinely useful... the gap with frontier commercial models keeps narrowing for many day-to-day tasks. Yet outside of this community, local LLMs still don't seem mainstream. My hunch: great UX and durable apps are still thin on the ground."

주요 로컬 실행 환경:
- **Ollama**: 가장 대중적. `ollama pull llama4-scout`로 원클릭 실행. OpenAI 호환 API 제공
- **LM Studio**: GUI 기반. 비개발자 친화적이지만 "even with quantized 7B models, machine often slows down" (HN, M1 Max 64GB 사용자)
- **llama.cpp**: 최고 성능의 C++ 추론 엔진. Metal/CUDA/Vulkan 지원
- **MLX**: Apple Silicon 네이티브. Swift 생태계와 통합
- **Vesta** (2026.02, HN Show): SwiftUI 네이티브 macOS 앱. llama.cpp + MLX + Apple Intelligence 5개 백엔드 통합, 33+ MCP 도구, Kokoro TTS, WhisperKit STT — "It's not Electron. It's a real macOS app"

**Codex CLI + Ollama** (2026.01): OpenAI의 Codex CLI가 Ollama를 통해 로컬 모델(gpt-oss:20b, gpt-oss:120b)과 직접 작동. 로컬 코딩 에이전트의 실용적 진입점.

### 하이브리드 아키텍처의 부상: Minions

Stanford Hazy Research의 **Minions** 프로토콜 (2025.02)이 특히 주목할 만하다:

- **Minion 프로토콜**: 클라우드 모델(GPT-4o)이 로컬 모델(Llama 3.2 via Ollama)과 "대화"하며 협업 → 클라우드 비용 **30.4x 절감**, 성능 87% 유지
- **MinionS 프로토콜**: 클라우드 모델이 작업을 분해, 로컬 모델들이 병렬 처리 → 클라우드 비용 **5.7x 절감**, 성능 97.9% 유지

이것은 "로컬 vs 클라우드"의 이분법을 넘어서는 **가장 현실적인 접근**이다. 프라이버시 민감한 데이터는 로컬에서, 복잡한 추론은 클라우드에서.

---

## 2. 비저너리 시각: 로컬 에이전트의 약속

### 2.1 프라이버시 완전 보장 + 비용 $0의 가치

로컬 에이전트의 가장 강력한 가치제안은 **프라이버시와 비용의 동시 해결**이다:

- **의료/법률 데이터**: HIPAA, GDPR 규제 하에서 환자 데이터나 법률 문서를 클라우드로 보내는 건 컴플라이언스 악몽이다. 로컬 에이전트는 데이터가 장치를 떠나지 않으므로 규제를 구조적으로 충족한다
- **기업 내부 문서**: "Our CTO said no cloud AI for internal code" — 이런 기업이 2026년에도 수두룩하다
- **개인 데이터**: 일기, 메시지, 사진, 금융 정보를 AI에 넣고 싶지만 OpenAI에는 보내기 싫은 사람들
- **비용**: 하드웨어 초기 투자 후 **한계비용 $0**. 하루 1000번 추론해도 API 비용 없음

### 2.2 오프라인 에이전트: 인터넷 없이도 동작

비행기, 지하철, 오지, 군사시설, 에어갭 환경... 인터넷 없는 곳은 생각보다 많다. 로컬 에이전트는:

- 비행기 내 코딩 어시스턴트
- 선박/원격지 작업 지원
- 군사/정보기관의 분류 문서 분석
- 개발도상국의 제한적 인터넷 환경에서의 교육 도구

### 2.3 "프라이버시 프리미엄" 비즈니스

> 로컬 에이전트를 유료로 파는 비즈니스가 성립할 수 있다.

**Vesta** (kruks.ai)가 이미 이 모델을 실험 중이다. 네이티브 macOS 앱에 로컬 모델 실행 + MCP 도구 + TTS/STT를 패키지로 제공. 이는:

- **하드웨어 회사의 차별화 전략**: Apple Silicon Mac을 사면 "무료 로컬 AI"가 따라옴 — Apple Intelligence가 정확히 이 전략
- **B2B SaaS**: "당신의 데이터는 당신의 서버를 떠나지 않습니다" → 규제 산업(금융, 의료, 법률)에 프리미엄 가격 청구
- **하드웨어 번들**: "AI PC" 마케팅 — Intel, AMD, Qualcomm 모두 NPU를 밀고 있는 이유

### 2.4 엣지 컴퓨팅: 스마트폰/태블릿에서 동작하는 에이전트

Phi-4 (14B), Gemma 3 (2B/9B), Llama 3.2 (1B/3B)는 스마트폰에서 돌릴 수 있는 크기다:

- **Apple Intelligence**: 이미 온디바이스 모델로 Siri를 구동. Foundation Models 프레임워크로 앱 개발자에게 개방 (단, 하드코딩된 컨텍스트 크기 제한이 실망스럽다는 평가)
- **Google Gemini Nano**: Pixel 폰에서 온디바이스 실행
- **Qualcomm AI Engine**: Snapdragon 8 Gen 4의 NPU로 7B 모델 실시간 추론 목표

미래 시나리오: 스마트폰의 로컬 에이전트가 **항상 켜져 있으면서** 캘린더, 이메일, 메시지를 관찰하고, 필요할 때만 클라우드 모델을 호출하는 **하이브리드 구조**. Minions 프로토콜의 모바일 버전.

---

## 3. 크리틱 시각: 현실의 괴리

### 3.1 Function Calling — 에이전트의 핵심 능력, 로컬의 최대 약점

에이전트의 본질은 **도구를 호출하는 것**이다. 대화만 하는 건 챗봇이지 에이전트가 아니다.

**OpenEnv** (Meta + HuggingFace, 2026.02)의 연구가 이 격차를 정량화한다:

> "AI agents often perform impressively in controlled research settings, yet struggle when deployed in real-world systems where they must reason across multiple steps, interact with real tools and APIs, operate under partial information, and recover from errors."

Calendar Gym 벤치마크 결과:
- 명시적 식별자가 있는 작업: **~90% 성공**
- 자연어 설명만으로 같은 작업: **~40%로 급락**
- 실패 원인의 **절반 이상**이 올바른 도구를 선택하고도 **잘못된 인자 형식이나 순서**

이건 **GPT-4o 급 모델에서도** 일어나는 문제다. 로컬의 17B-32B 모델에서는 더 심할 수밖에 없다.

**LinkedIn의 GPT-OSS 에이전틱 RL 연구** (2026.01)에서도:
- GPT-OSS 20B의 초기 에이전틱 RL 훈련에서 **KL divergence 폭발**, 보상 미증가 관찰
- MoE 아키텍처 특유의 **라우팅 불안정성**이 PPO 훈련을 방해
- 해결에 상당한 엔지니어링 (dual forward pass 문제, attention sink 수정 등)이 필요

**결론**: 로컬 모델이 "대화"는 잘 하지만, **안정적으로 도구를 호출하고, 결과를 해석하고, 다음 행동을 결정하는** 에이전틱 루프는 아직 프론티어 모델과 현격한 차이가 있다.

### 3.2 하드웨어 요구사항: "일반인의 PC"에서 돌릴 수 있나?

| 모델 | Q4 양자화 VRAM/RAM | 일반인 가능성 |
|------|-------------------|-------------|
| Llama 4 Scout (109B) | ~60GB | ❌ M4 Max 128GB 또는 A6000 필요 |
| Llama 4 Maverick (400B) | ~200GB+ | ❌❌ 사실상 데이터센터급 |
| Qwen3-32B | ~20GB | ⚠️ RTX 4090 또는 M2 Pro 32GB |
| Phi-4 (14B) | ~10GB | ✅ RTX 3060 12GB, M1 Pro 16GB |
| Qwen3-8B | ~6GB | ✅ 대부분의 최신 노트북 |
| Llama 3.2 3B | ~2GB | ✅✅ 스마트폰도 가능 |

현실: **에이전트로 쓸 만한 모델(32B+)은 일반인 하드웨어로 부족**하고, **일반인 하드웨어에서 돌아가는 모델(~8B)은 에이전트로 쓰기엔 function calling이 불안정**하다. 이것이 핵심 괴리다.

HN의 M1 Max 64GB 사용자조차 "even with quantized 7B models, my machine often slows down or hangs during inference"라고 보고한다. 에이전트는 한 번의 추론이 아니라 **루프를 돌며 연속적으로 추론**해야 하므로 지연이 누적된다.

### 3.3 도구 호출 정확도 — 에이전트의 사활적 문제

에이전트 = 추론 + 행동의 루프. 이 루프에서:

1. **도구 선택**: 20개 도구 중 올바른 것을 고르기
2. **인자 생성**: JSON 스키마에 맞는 정확한 인자
3. **결과 해석**: 도구 반환값을 이해하고 다음 행동 결정
4. **에러 복구**: 실패했을 때 재시도하거나 대안 찾기

각 단계에서 90% 정확도라면, 4단계 루프에서 성공률은 0.9⁴ = **65.6%**. 이걸 5번 반복하면 0.656⁵ = **12.6%**. 에이전트에서 정확도는 곱셈적으로 작동한다.

프론티어 모델(Claude 3.5 Sonnet, GPT-4o)이 **단일 스텝 98%+** 정확도를 목표로 하는 이유가 여기에 있다. 로컬 모델이 이 수준에 도달하지 못하면, 복잡한 에이전트 워크플로우에서는 **사실상 사용 불가**다.

### 3.4 "로컬 에이전트"가 실제로 필요한 사람이 몇 명?

냉정한 시장 분석:

- **개인 사용자**: 대부분 ChatGPT Plus $20/월이면 충분. "프라이버시"를 위해 $3000 GPU를 사는 사람은 극소수
- **개발자**: 로컬 모델로 코딩 에이전트를 쓸 수 있지만, Copilot/Cursor가 이미 월 $20-40에 프론티어 모델을 제공
- **기업**: 규제 산업은 관심이 있지만, 자체 인프라 운영 비용 + 전문 인력 필요
- **연구자**: 가장 실질적인 사용자층. 모델 커스터마이징, 파인튜닝, 실험에 로컬 필수

> "If you're not using local models yet, what's the blocker — setup friction, quality, missing integrations, battery/thermals, or just 'cloud is easier'?" — HN thread (2025.08)

대부분의 답: **"cloud is easier."**

---

## 4. Agent Skills: 격차를 줄이는 새로운 접근

HuggingFace의 **Agent Skills** 패러다임 (2026.01-02)이 로컬 에이전트의 가능성을 변화시킬 수 있다:

### 개념

> "Agent skills are a practical medium to share capabilities across models and tools... they're most useful in specific domains or hard problems. Not stuff the model can do well anyway."

**Upskill** 프레임워크의 접근:
1. **교사 모델(Claude Opus 4.5)** 로 어려운 작업을 수행하고 트레이스를 기록
2. 트레이스에서 **Skill 파일**(~550 토큰의 구조화된 가이드 + 참조 스크립트)을 생성
3. 이 Skill을 **로컬/저렴한 모델**에 적용하여 성능 부스트

### 결과

- CUDA 커널 작성 같은 전문 작업에서, Skill이 있는 오픈소스 모델이 **Skill 없는 상태보다 의미있게 향상**
- 단, **모든 모델에 동일하게 작동하지 않음** — Kimi-K2-Thinking에선 정확도+토큰 효율 모두 개선, Claude Opus 4.5에선 오히려 토큰 사용량 증가
- 핵심: 도메인 지식을 **파일로 패키징**하면, 작은 모델도 전문 작업을 수행할 수 있다

### 로컬 에이전트에의 함의

이 패턴을 일반화하면: **특정 도메인(이메일 분류, 캘린더 관리, 코드 리뷰 등)에 최적화된 Skill 파일을 로컬 모델에 적용**하면, 범용 function calling 능력이 부족해도 **좁은 영역에서는 충분히 쓸 만한 에이전트**가 될 수 있다.

이것은 "범용 로컬 에이전트"에서 **"특화형 로컬 에이전트"**로의 패러다임 전환을 시사한다.

---

## 5. OpenClaw + 로컬 모델: 현실적 조합

OpenClaw의 아키텍처는 모델을 교체 가능하게 설계되어 있다. 이론적으로:

```
OpenClaw Gateway → Ollama (로컬) → Qwen3-32B
                 → 필요시 Claude/GPT-4o (클라우드)
```

**가능한 시나리오:**
- 일상적 대화, 간단한 도구 호출: 로컬 Qwen3-32B
- 복잡한 멀티스텝 에이전트 작업: 클라우드 모델로 자동 전환
- 프라이버시 민감 데이터 처리: 항상 로컬

**현실적 한계:**
- OpenClaw의 도구 생태계(Discord, 브라우저, 파일시스템 등)는 **정확한 function calling**을 요구
- 로컬 모델의 도구 호출 불안정성은 UX를 직접적으로 훼손
- Minions 스타일 하이브리드가 현실적이지만, 라우팅 로직의 복잡성 추가

---

## 6. 종합 판정

### 핵심 괴리: 있다, 그리고 크다

"로컬에서 동작하는 개인 AI 에이전트"에는 **명확한 괴리**가 존재한다:

| 차원 | 클라우드 프론티어 | 로컬 현실 (2026.02) | 격차 |
|------|----------------|-------------------|------|
| Function calling 정확도 | 95-98% | 70-85% (32B급) | 치명적 |
| 멀티스텝 추론 | 10+ 스텝 안정 | 3-5 스텝에서 불안정 | 심각 |
| 에러 복구 | 자연스러운 재시도 | 루프에 빠지거나 포기 | 심각 |
| 응답 속도 | <2초 | 5-30초 (하드웨어 의존) | 불편 |
| 진입장벽 | 브라우저만 열면 됨 | GPU, RAM, 설정 필요 | 높음 |
| 비용 | $20-200/월 | 초기 $500-3000, 이후 $0 | 장기 유리 |
| 프라이버시 | 데이터가 외부로 나감 | 완전 로컬 | 절대 우위 |

### 실현 가능한 것과 불가능한 것

**지금 가능한 것 ✅:**
- 대화형 비서 (채팅, Q&A, 요약)
- 1-2 스텝의 간단한 도구 호출 (파일 읽기, 검색)
- 특정 도메인에 Skill로 최적화된 좁은 범위의 자동화
- Minions 스타일 하이브리드 (로컬이 데이터 접근, 클라우드가 추론)
- 코딩 어시스턴트 (자동완성, 간단한 리팩토링)

**아직 불가능한 것 ❌:**
- 10+ 도구를 넘나드는 복잡한 에이전트 워크플로우를 로컬만으로
- OpenClaw 급의 풀 에이전트 경험 (Discord + 브라우저 + 파일 + 크론 + 노드)
- "설정하고 잊어버리기" — 로컬 모델은 장기 작업에서 드리프트 발생
- 일반인이 설정 없이 바로 쓰는 로컬 에이전트

### 2026-2027 예측

1. **하이브리드가 정답이다**: 순수 로컬도, 순수 클라우드도 아닌, Minions 스타일의 협업이 주류가 될 것
2. **Skill 기반 특화가 격차를 줄인다**: 범용 능력 부족을 도메인 특화 Skill 파일로 보완하는 패턴이 표준화
3. **하드웨어가 병목을 해소한다**: M5/M6 세대, RTX 60 시리즈의 통합 메모리/대용량 VRAM이 32B+ 모델의 쾌적한 실행을 가능하게 할 것
4. **에이전틱 RL이 로컬 모델을 변화시킨다**: LinkedIn의 GPT-OSS 연구처럼, 에이전틱 RL로 학습된 소형 모델이 도구 사용 정확도를 90%+ 수준으로 끌어올릴 것
5. **Apple/Google이 키 플레이어**: 온디바이스 AI를 OS 수준에서 통합하는 회사가 "로컬 에이전트"를 대중화할 가능성이 가장 높다

### 최종 판정

> **로컬 에이전트는 "가능하냐"가 아니라 "어디까지 가능하냐"의 문제다.** 대화와 간단한 자동화는 지금도 가능하다. 복잡한 멀티스텝 에이전트는 아직 1-2년 뒤다. 그 사이를 연결하는 것이 하이브리드 아키텍처(Minions), Skill 기반 특화, 그리고 에이전틱 RL이다. "로컬이냐 클라우드냐"는 잘못된 이분법이다 — 답은 "적절한 작업을 적절한 곳에서"다.

---

## 참조 자료

- **Ask HN: Are you running local LLMs?** (2025.08) — 로컬 모델 실사용 현황 서베이
- **Minions: where local and cloud LLMs meet** (Stanford Hazy Research, 2025.02) — 로컬+클라우드 협업 프로토콜
- **OpenEnv: Evaluating Tool-Using Agents in Real-World Environments** (Meta+HF, 2026.02) — 에이전트 도구 사용 평가 프레임워크
- **Unlocking Agentic RL Training for GPT-OSS** (LinkedIn+HF, 2026.01) — MoE 모델의 에이전틱 RL 훈련 과제
- **Upskill / Agent Skills** (HuggingFace, 2026.01-02) — 에이전트 스킬 전이 프레임워크
- **Custom Kernels for All from Codex and Claude** (HuggingFace, 2026.02) — 에이전트 스킬의 실전 적용
- **Vesta AI Explorer** (Show HN, 2026.02) — 네이티브 macOS 로컬 AI 앱의 실례
- **OpenAI Codex with Ollama** (Ollama Blog, 2026.01) — Codex CLI + 로컬 모델 통합
