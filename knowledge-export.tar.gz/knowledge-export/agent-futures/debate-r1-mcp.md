# 토론 라운드 1: MCP 생태계의 빈 구멍

**작성일**: 2026-02-18
**조사 소스**: GitHub (modelcontextprotocol/servers, punkpeye/awesome-mcp-servers 81k★, topics/mcp-server 7,658 repos), mcp.so (284 pages), glama.ai/mcp/servers, Hacker News, Reddit (r/ClaudeAI, r/LocalLLaMA, r/mcp 80k members), Glama "State of MCP in 2025" 리포트, Pomerium best-of 리스트, MCP Registry

---

## 1. 현황 스냅샷

### 핵심 수치
- **modelcontextprotocol/servers**: 78.9k ★, 9.6k forks, 4,046 commits
- **awesome-mcp-servers (punkpeye)**: 81k ★, 7.3k forks, 3,618 commits — 사실상 가장 큰 MCP 서버 카탈로그
- **GitHub "mcp-server" topic**: 7,658 public repos
- **mcp.so**: 284 pages × ~50 servers/page ≈ **14,000+ 등록 서버**
- **Glama 등록 서버**: 11,415 servers (2025년)
- **NPM 주간 다운로드**: MCP 생태계 전체 **31M/week**
- **r/mcp 서브레딧**: 80k members, 2025년 7.3M visitors
- **벤처 투자**: MCP 생태계 직접 투자 최소 **$73M+** (Obot AI $35M, Daloopa $13M, Runlayer $11M, Alpic $6M, Glue $20M 등)

### 공식 레퍼런스 서버 (modelcontextprotocol/servers)
| 서버 | 설명 |
|------|------|
| Everything | 테스트/레퍼런스 서버 |
| Fetch | 웹 콘텐츠 가져오기 & LLM 최적화 변환 |
| Filesystem | 안전한 파일 작업 |
| Git | Git 저장소 조작 |
| Memory | 지식 그래프 기반 영속 메모리 |
| Sequential Thinking | 구조화된 사고 체인 |
| Time | 시간대 변환 |

> 📌 Brave Search, GitHub, GitLab, Google Drive, Google Maps, PostgreSQL, Puppeteer 등은 **아카이브** → 각 벤더가 자체 공식 서버로 이관

### SDK 지원 현황 (10개 언어)
TypeScript, Python, Go, Rust, Java, Kotlin, C#, PHP, Ruby, Swift

---

## 2. 🔥 인기 MCP 서버 TOP 10 (Stars + 실사용)

| # | 서버 | Stars | NPM 주간 DL | 카테고리 |
|---|------|-------|------------|---------|
| 1 | **github/github-mcp-server** | 15.2k | - (Go) | 개발도구/VCS |
| 2 | **microsoft/playwright-mcp** | 11.6k | 951,444 | 브라우저 자동화 |
| 3 | **upstash/context7** | ~8k | 396,605 | 문서/개발도구 |
| 4 | **@anthropic/filesystem** | (공식) | 197,481 | 파일시스템 |
| 5 | **ChromeDevTools/chrome-devtools-mcp** | ~6k | 124,998 | 브라우저 |
| 6 | **awslabs/mcp** | 3.7k | - | 클라우드 |
| 7 | **@anthropic/sequential-thinking** | (공식) | 82,078 | 추론/사고 |
| 8 | **fastmcp** (Glama) | - | 74,295 | 프레임워크 |
| 9 | **@anthropic/memory** | (공식) | 66,986 | 지식/메모리 |
| 10 | **czlonkowski/n8n-mcp** | ~3k | 61,995 | 워크플로우 자동화 |

> 💡 **핵심 인사이트**: 실사용(NPM DL) 기준 Playwright가 압도적 1위. GitHub MCP는 stars 기준 1위. 개발도구 + 브라우저 자동화가 킬러 카테고리.

---

## 3. 카테고리별 분류

awesome-mcp-servers 기준 **30+ 카테고리**가 존재. 주요 카테고리:

### 📊 포화도 맵

| 카테고리 | 서버 수 | 포화도 | 대표 서버 |
|----------|---------|--------|-----------|
| **브라우저 자동화** | 30+ | 🔴 과포화 | Playwright, Puppeteer, BrowserBase |
| **개발도구** | 50+ | 🔴 과포화 | GitHub, GitLab, Sentry, dbt |
| **데이터베이스** | 30+ | 🔴 과포화 | PostgreSQL, Redis, MongoDB, Neon |
| **검색/추출** | 20+ | 🟡 높음 | Brave Search, Firecrawl, Exa.ai |
| **클라우드 플랫폼** | 15+ | 🟡 높음 | AWS, Terraform, Cloudflare |
| **커뮤니케이션** | 10+ | 🟡 중간 | Slack, Discord |
| **파일시스템** | 10+ | 🟡 중간 | Filesystem, Google Drive |
| **지도/위치** | 5+ | 🟢 낮음 | Google Maps, Amap(고덕), Baidu Maps |
| **금융/핀테크** | 5+ | 🟢 낮음 | Alpha Vantage, KOSPI-KOSDAQ |
| **보안** | 5+ | 🟢 낮음 | Bitwarden, Tansive |
| **법률** | 3+ | 🟢 매우 낮음 | - |
| **교육** | 2+ | 🟢 매우 낮음 | - |
| **헬스케어** | 5+ | 🟢 낮음 | FHIR, Apple Health |
| **홈 오토메이션** | 3+ | 🟢 매우 낮음 | - |
| **마케팅** | 3+ | 🟢 매우 낮음 | DataForSEO |
| **여행/교통** | 2+ | 🟢 매우 낮음 | - |
| **스포츠** | 1+ | 🟢 거의 없음 | - |
| **한국 특화** | 2 | 🟢 거의 없음 | KOSPI-KOSDAQ, (Amap은 중국) |

---

## 4. 🔮 비저너리: 빈 구멍 — 아직 존재하지 않는 고가치 MCP 서버 아이디어 10개

### 아이디어 1: **MCP Auth Gateway / OAuth Proxy**
- **문제**: 모든 MCP 서버가 각자 인증을 구현. 사용자는 10개 서버에 10개 API 키 관리
- **솔루션**: 통합 OAuth2/OIDC 프록시. 하나의 MCP 서버가 모든 인증을 중개
- **수익 모델**: SaaS — 월 $10-50/user (비밀 관리 포함)
- **경쟁**: Pomerium이 일부 커버하지만 MCP-native가 아님. Obot AI가 $35M 투자받아 진입 중
- **기회 크기**: 🌟🌟🌟🌟🌟 (에코시스템 인프라)

### 아이디어 2: **MCP Observability & Audit Logger**
- **문제**: 에이전트가 어떤 도구를 왜 호출했는지 추적 불가. 기업 감사 요건 충족 못함
- **솔루션**: MCP 프록시로 모든 tool call을 로깅, 대시보드, 알림, 비용 추적
- **수익 모델**: freemium — 무료 1k calls/day, 유료 $29-199/mo
- **경쟁**: MCPCat.io (초기), Sentry/Datadog 진입 중이지만 MCP-전용은 거의 없음
- **기회 크기**: 🌟🌟🌟🌟🌟

### 아이디어 3: **E-Commerce MCP (Shopify/WooCommerce/Amazon Seller)**
- **문제**: 이커머스 셀러들이 AI로 상품 관리, 가격 조정, 주문 추적을 하고 싶지만 MCP 서버 없음
- **솔루션**: Shopify Admin API, WooCommerce REST API, Amazon SP-API를 MCP로 래핑
- **수익 모델**: freemium — 무료 1 스토어, $19/mo per store
- **경쟁**: 거의 없음. PipeDream이 일부 커버하지만 전문성 부족
- **기회 크기**: 🌟🌟🌟🌟

### 아이디어 4: **Personal Finance MCP (Plaid/은행 연동)**
- **문제**: 개인 재정 관리를 AI 에이전트에 맡기고 싶지만, 은행 데이터 접근이 불가
- **솔루션**: Plaid, Toss, 오픈뱅킹 API를 통한 거래 내역 조회, 예산 분석, 이상 지출 감지
- **수익 모델**: $9.99/mo (API 비용 커버 + 마진)
- **경쟁**: Alpha Vantage(주식만), 개인금융 MCP는 없음
- **기회 크기**: 🌟🌟🌟🌟 (보안 리스크가 진입장벽이자 해자)

### 아이디어 5: **CRM MCP (Salesforce/HubSpot)**
- **문제**: 영업팀이 Claude에게 "이 리드의 최근 활동 요약해줘"를 하고 싶음
- **솔루션**: Salesforce, HubSpot, Pipedrive REST API → MCP 서버
- **수익 모델**: $29-99/mo/seat
- **경쟁**: 놀랍도록 거의 없음. HubSpot이 자체 MCP 만들 수 있지만 아직 안 함
- **기회 크기**: 🌟🌟🌟🌟🌟

### 아이디어 6: **CI/CD Pipeline MCP**
- **문제**: "마지막 빌드 왜 실패했어?", "스테이징 배포해줘"를 AI에게 시킬 수 없음
- **솔루션**: GitHub Actions, Jenkins, CircleCI, ArgoCD 통합 MCP
- **수익 모델**: 오픈소스 + 엔터프라이즈 ($49/mo)
- **경쟁**: GitHub MCP가 부분적 커버. 전문 CI/CD MCP는 없음
- **기회 크기**: 🌟🌟🌟🌟

### 아이디어 7: **Legal Document MCP (계약서 분석)**
- **문제**: 법률 분야 MCP가 거의 없음. 계약서 검토, 조항 비교, 위험 플래그
- **솔루션**: PDF 파싱 + 법률 특화 프롬프트 + 판례 DB 연동
- **수익 모델**: $99-499/mo (법률사무소는 높은 가격 지불 의향)
- **경쟁**: 거의 제로
- **기회 크기**: 🌟🌟🌟🌟 (규제가 느리지만 수익성 높음)

### 아이디어 8: **Calendar + Email Unified MCP**
- **문제**: Google Calendar, Outlook Calendar, Gmail, Outlook Mail을 통합한 "비서" MCP
- **솔루션**: 하나의 MCP로 일정 조회/생성, 이메일 검색/응답, 스마트 요약
- **수익 모델**: freemium $9.99/mo
- **경쟁**: 개별 서비스 MCP는 있지만 통합 비서는 없음
- **기회 크기**: 🌟🌟🌟🌟

### 아이디어 9: **MCP Testing & Validation Framework**
- **문제**: MCP 서버를 만들고 테스트하는 표준 도구가 없음. Glama Inspector가 있지만 제한적
- **솔루션**: MCP 서버 자동 테스트, 스키마 검증, 성능 벤치마크, 보안 스캔
- **수익 모델**: 오픈소스 + 엔터프라이즈 CI 통합 ($19/mo)
- **경쟁**: MCP Inspector (Glama, 기본적), MCPJam (devtools)
- **기회 크기**: 🌟🌟🌟🌟 ("삽을 파는" 전략의 핵심)

### 아이디어 10: **Accounting/ERP MCP (QuickBooks, Xero, SAP)**
- **문제**: 회계사/CFO가 "이번 달 비용 요약", "미수금 목록" 등을 AI에 물어볼 수 없음
- **솔루션**: QuickBooks, Xero, FreshBooks API → MCP (읽기 전용부터 시작)
- **수익 모델**: $49-199/mo
- **경쟁**: 거의 없음
- **기회 크기**: 🌟🌟🌟🌟🌟 (B2B SaaS 수익성 최고)

---

## 5. 🇰🇷 한국 특화 MCP 서버 기회

현재 한국 관련 MCP: **KOSPI/KOSDAQ 주식 서버** 1개만 확인. 중국은 고덕지도, 바이두지도, 즈푸(Zhipu) 검색, 치뉴(Qiniu) 클라우드 등 이미 다수 존재. 한국은 **완전한 블루오션**.

| 아이디어 | API 소스 | 난이도 | 기회 |
|----------|----------|--------|------|
| **카카오 통합 MCP** (카카오톡 알림, 카카오맵, 카카오페이 결제내역) | Kakao Developers API | 중 | 🌟🌟🌟🌟🌟 |
| **네이버 통합 MCP** (네이버 검색, 블로그, 쇼핑, 지도, 예약) | Naver Open API | 중 | 🌟🌟🌟🌟🌟 |
| **공공데이터 MCP** (기상청, 국토교통부, 건강보험, 국세청) | data.go.kr REST API | 하 | 🌟🌟🌟🌟 |
| **토스/카카오뱅크 MCP** (오픈뱅킹 거래내역, 잔액 조회) | 오픈뱅킹 API | 상 | 🌟🌟🌟🌟 |
| **배달의민족/쿠팡이츠 MCP** (주문, 리뷰 분석, 매출 대시보드) | 사장님 포털 API (비공식) | 상 | 🌟🌟🌟 |
| **한국 부동산 MCP** (국토부 실거래가, KB부동산, 직방) | 공공데이터 + 크롤링 | 중 | 🌟🌟🌟🌟 |
| **한국 주식 Pro MCP** (KRX, 증권사 API, 공시정보 DART) | DART OpenAPI, 한투 API | 중 | 🌟🌟🌟🌟🌟 |
| **한국어 법률 MCP** (법령정보, 판례 검색, 법률 QA) | 법제처 API, 법원 판례DB | 중 | 🌟🌟🌟🌟 |
| **한국 교육 MCP** (수능 기출, 학교 정보, 나이스 성적) | 나이스 API, 한국교육과정평가원 | 하 | 🌟🌟🌟 |
| **한국 의료 MCP** (건강보험 진료내역, 약국/병원 찾기) | 건강보험공단 API | 중 | 🌟🌟🌟 |

> 💡 **전략적 인사이트**: 중국 MCP 생태계를 벤치마크할 것. 고덕지도(Amap), 바이두지도, 샤오홍슈 다운로더 등 중국 특화 서버가 이미 mcp.so에서 인기. 한국은 같은 패턴으로 네이버/카카오 래핑하면 된다.

---

## 6. 🔍 크리틱: 냉혹한 현실 점검

### Q1: 대부분의 MCP 서버가 실제로 쓰이는가?

**결론: 대부분 안 쓰인다. 극소수만 실제로 쓰인다.**

- 11,415개 등록 서버 중 NPM 주간 10k+ 다운로드는 **10개 미만**
- Playwright 혼자 주간 951k DL — 나머지 전체의 합보다 많을 수 있음
- Glama 리포트: "가장 오래된 기간 동안, MCP 생태계에는 사용자보다 만드는 사람이 더 많았다"
- **81개** MCP 관련 회사 추적 → "절반 이상이 사이트 사망 또는 피벗" (Glama 2025 리포트)
- mcp.so 284 페이지 중 뒷페이지들은 거의 다 0 star, "mirror of" 복제판, 개인 학습 프로젝트

**핵심 데이터:**
```
Top 5 NPM (주간 DL):
1. @playwright/mcp:              951,444  (실사용 킬러)
2. @upstash/context7-mcp:        396,605  (코딩 에이전트 필수)
3. @mcp/server-filesystem:       197,481  (기본 중의 기본)
4. chrome-devtools-mcp:          124,998  (Chrome 확장 필수)
5. mcp-proxy:                    111,085  (인프라)
---
나머지 11,400개 합산: ???
```

→ **"파워 법칙" 극단**: 상위 0.1%가 99% 트래픽을 가져간다.

### Q2: MCP 서버가 비즈니스가 될 수 있는가?

**결론: 가능하지만, 대부분은 commodity가 된다. "삽을 팔아야" 한다.**

#### 비즈니스 가능 영역 (수익화 증명됨):
- **데이터 API 래핑** — Bright Data, Exa.ai, Tavily, DataForSEO 모델. 기존 pay-per-request를 MCP 채널로 확장. API 키만 바꿈 → **기존 비즈니스의 MCP 채널 확장**
- **인프라/플랫폼** — Obot AI ($35M), Alpic ($6M), Runlayer ($11M). 호스팅, 보안, 거버넌스. **진짜 돈이 여기에 몰린다**
- **엔터프라이즈 private registry** — "대기업과 정부기관이 폭증" (Glama). 자체 인프라에서 MCP 서버 호스팅/관리/모니터링

#### commodity 위험 높은 영역:
- 단순 API 래핑 MCP — 누구나 1-3일에 만들 수 있음. 오픈소스로 무료 대체 가능
- 검색/크롤링 MCP — 이미 과포화
- 기본 DB 연결 MCP — PostgreSQL, Redis, MongoDB 전부 공식 버전 존재

#### 핵심 질문: 왜 사람들이 **유료** MCP 서버를 쓰는가?
1. **신뢰할 수 있는 데이터** (DataForSEO, Bright Data — 데이터 자체가 유료)
2. **호스팅 + 보안** (로컬 설치 귀찮음. 원격 MCP가 이김 — Glama 서베이)
3. **엔터프라이즈 지원** (SLA, 감사 로그, SSO)

### Q3: 보안 문제는 얼마나 심각한가?

**결론: 매우 심각하다. 이것이 가장 큰 기회이자 위험이다.**

#### 현재 보안 위협:
- **"MCP Servers: The New Security Nightmare"** (Equixly, 2025년 HN 게시물)
- 로컬 MCP 서버 = 로컬 머신 전체 접근 가능. 악성 서버가 파일 삭제, 크레덴셜 탈취 가능
- **"Did that MCP Server leak your database?"** (Tansive, HN 게시물) — SQL 인젝션, 데이터 유출
- Prompt injection을 통한 MCP 서버 악용 가능
- 11,000+ 서버 중 대다수가 감사를 받지 않음

#### Glama 리포트 핵심:
> "로컬 바이너리는 더 위험하다 — 로컬 머신에 접근할 수 있기 때문. 이를 개선하려면 MCP 서버의 무결성을 검증하는 더 나은 방법이 필요하다. Microsoft, Google, Anthropic, OpenAI 같은 회사가 MCP 레지스트리를 만들고 서버 작성자를 검증하지 않는 한 이것은 일어나지 않을 것이다."

→ **보안이 곧 비즈니스 기회**: Pomerium, Tansive, Runlayer ($11M) 등이 진입 중

### Q4: MCP 서버 마켓플레이스가 필요한가?

**결론: 필요하지만, 현재 형태는 아닐 수 있다.**

- 이미 존재: glama.ai, mcp.so, Smithery, MCP Registry (공식), mcp-get.com, PulseMCP 등 **6개 이상의 디렉토리/마켓플레이스**
- 문제: **절반 이상이 사망 또는 피벗** (Glama 리포트)
- 생존 조건: 단순 리스팅이 아닌 **호스팅 + 결제 + 보안 + 관측성** 플랫폼이어야 함
- 비유: npm registry가 성공한 이유 = 패키지 설치의 단일 인터페이스. MCP에도 같은 것이 필요
- **Glama의 전략**: 레지스트리 → 호스팅 → 게이트웨이 → 수익 공유 (진행 중)

> Glama: "우리는 오픈소스 MCP 서버 작성자를 위한 수익 공유 모델을 개발 중"

---

## 7. 종합: 1인 개발자 전략

### "삽을 파는" 전략 — 수익성 순위

| 순위 | 전략 | 예상 월 수익 | 난이도 | 시간 |
|------|------|-------------|--------|------|
| 1 | **MCP Observability SaaS** (로깅, 비용 추적, 대시보드) | $5k-50k/mo | 중-상 | 2-4주 |
| 2 | **한국 특화 MCP 번들** (네이버+카카오+공공데이터) | $1k-10k/mo | 중 | 1-2주 |
| 3 | **E-Commerce MCP** (Shopify/Coupang 셀러 도구) | $3k-30k/mo | 중 | 2-3주 |
| 4 | **MCP Testing CLI** (오픈소스 + 유료 CI 통합) | $2k-20k/mo | 중 | 1-2주 |
| 5 | **CRM MCP** (HubSpot 통합) | $5k-50k/mo | 중 | 2-3주 |
| 6 | **Accounting MCP** (Xero/QuickBooks) | $3k-30k/mo | 중 | 2-3주 |
| 7 | **한국 주식 Pro** (DART + 증권사 + 실시간) | $1k-5k/mo | 중 | 1-2주 |
| 8 | **Legal Document MCP** | $5k-50k/mo | 상 | 4-8주 |
| 9 | **Calendar+Email 통합 비서** | $2k-10k/mo | 중-상 | 3-4주 |
| 10 | **MCP Auth Proxy** | $5k-50k/mo | 상 | 4-8주 |

### 🎯 1인 개발자 추천 1순위: **한국 특화 MCP 번들**

**이유:**
1. **경쟁 제로** — 한국 MCP는 KOSPI 서버 1개뿐
2. **낮은 난이도** — 네이버/카카오 API는 잘 문서화되어 있음
3. **큰 잠재 시장** — 한국 개발자 + AI 얼리어답터 수십만 명
4. **"중국 패턴" 검증** — 중국 특화 MCP (고덕지도, 바이두, 샤오홍슈 등)가 이미 인기
5. **확장 가능** — 네이버 검색 → 쇼핑 → 블로그 → 지도로 점진적 확장
6. **수익화** — 무료 기본 + Pro 기능 (실시간 알림, 대량 검색) $9.99/mo

### 🎯 1인 개발자 추천 2순위: **MCP Observability/Testing 도구**

**이유:**
1. **"삽 파는" 전략의 정석** — 골드러시에서 리바이스가 됨
2. **모든 MCP 사용자가 잠재 고객**
3. **11,000+ 서버 작성자 + 수만 명 사용자**
4. **아직 제대로 된 도구 없음** (MCP Inspector가 최선이지만 기본적)
5. **엔터프라이즈 포텐셜** — "감사 로그" 한 마디에 기업이 지갑 열음

---

## 8. MCP 생태계 향후 6개월 예측 (2026년 2월 → 8월)

### 확실한 것 (High Confidence)

1. **원격 MCP가 로컬을 압도한다** — Glama 서베이에서 이미 확인. Docker/uv 설치 귀찮음. "원클릭 원격 서버"가 표준이 됨
2. **GitHub/공식 MCP Registry 강화** — GitHub이 이미 "MCP Registry" 메뉴를 네비게이션에 추가. npm처럼 될 것
3. **벤더 자체 MCP 서버 폭증** — 모든 SaaS가 "MCP 서버 제공"을 마케팅 체크리스트에 추가. REST API → MCP 래핑이 표준 패턴
4. **서버 수 2만+ 돌파** — 현재 11.4k → 6개월 내 20k+ (GitHub topic 7.6k가 이미 빠르게 증가 중)
5. **보안 사고 발생** — 악성 MCP 서버를 통한 데이터 유출 사건이 뉴스에 등장. 이후 보안 도구 수요 폭증

### 가능성 높은 것 (Medium Confidence)

6. **MCP Apps (UI 렌더링) 표준화** — 2025-11-21 제안됨. "에이전틱 앱 런타임"으로 발전
7. **통합 결제 모델 등장** — Glama의 수익 공유 모델이 실현되면 게임 체인저
8. **50% 이상의 소규모 MCP 회사 사망** — 현재 81개 추적 중 절반 이상 이미 사망. 더 가속화
9. **Microsoft/Google이 자체 MCP 호스팅 출시** — Azure MCP, Google Cloud MCP 서비스
10. **"Background Agent" 사용이 Chat을 넘어섬** — CI/CD, 데이터 파이프라인에서 MCP 사용이 주류

### 와일드카드 (Low Confidence, High Impact)

11. **OpenAI가 MCP를 포크하거나 경쟁 프로토콜 발표** — 현재 MCP 지원 중이지만, 독자 프로토콜 가능성
12. **MCP 서버 공급망 공격** — npm left-pad 사건의 MCP 버전. 인기 서버가 악성 업데이트
13. **한국/일본 MCP 생태계 독자 성장** — 현지 특화 서버가 글로벌 디렉토리에 못 들어가고 로컬 에코시스템 형성

---

## 부록: 조사 소스 목록

| 소스 | URL | 상태 |
|------|-----|------|
| 공식 서버 목록 | github.com/modelcontextprotocol/servers | ✅ 78.9k★ |
| 커뮤니티 서버 | github.com/topics/mcp-server | ✅ 7,658 repos |
| awesome-mcp-servers | github.com/punkpeye/awesome-mcp-servers | ✅ 81k★ |
| mcp.so | mcp.so/servers | ✅ 284 pages |
| Glama 디렉토리 | glama.ai/mcp/servers | ✅ 11,415 servers |
| MCP Registry (공식) | registry.modelcontextprotocol.io | ✅ API 운영 중 |
| Hacker News | hn.algolia.com | ✅ MCP 관련 다수 |
| r/ClaudeAI | reddit.com/r/ClaudeAI | ✅ MCP 서버 팁 다수 |
| r/LocalLLaMA | reddit.com/r/LocalLLaMA | ✅ 로컬 MCP 가이드 |
| r/mcp | reddit.com/r/mcp | ✅ 80k members |
| Glama State of MCP | glama.ai/blog/2025-12-07-the-state-of-mcp-in-2025 | ✅ 핵심 리포트 |
| Pomerium Best MCP | pomerium.com/blog/best-mcp-servers-2025 | ✅ 보안 관점 |

---

*이 문서는 2026-02-18 기준 조사 결과입니다. MCP 생태계는 매우 빠르게 변하고 있으므로, 월 1회 업데이트를 권장합니다.*
