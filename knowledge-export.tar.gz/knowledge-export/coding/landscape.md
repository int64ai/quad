# 코딩 AI 지형도 (2026년 2월 기준)

---

## 👑 절대 강자 (Top Tier)

### Claude Code (Anthropic)
- **티어:** 절대 강자
- **ARR:** $2.5B+ (2026.02)
- **GitHub 커밋 점유율:** ~4% (2026.02), 연말 20% 전망 (SemiAnalysis)
- **SWE-bench:** 72.7% SOTA
- **연속 작업:** 30시간+ (Sonnet 4.5)

**강점:**
- 2025.02 출시 → ~6개월 만에 ARR $1B → 2026.02 $2.5B+. SaaS 역사상 최고 성장 속도급
- 6단계 메모리 계층: ①관리자 정책 ②프로젝트 CLAUDE.md ③프로젝트 규칙(.claude/rules/) ④사용자 메모리 ⑤로컬 프로젝트 메모리 ⑥Auto Memory (AI 자동 학습 노트)
- 세션 연속성 3종: resume, teleport, remote. Agent Teams로 멀티 에이전트 병렬 작업

**약점:**
- Opus 기반 시 비용 부담 (Opus $15/$75 per M)
- 터미널 기반이라 GUI 선호 사용자에게 진입장벽

**커뮤니티 평가:** '코드베이스 전체를 읽고 기존 스타일을 따라하는 시니어' — Codex 대비 핵심 강점

---

### Cursor (Anysphere)
- **티어:** 절대 강자
- **ARR:** $1B+ (2025.11) — SaaS 역사상 최단 기간 (약 20개월)
- **밸류에이션:** $29.3B
- **병렬 에이전트:** 최대 8개
- **가격:** $20/월 (Pro)

**강점:**
- Tab 자동완성 + Composer(멀티파일 에이전트) + 8개 병렬 에이전트
- GPT-5, Claude 4, Gemini 2.5 등 멀티모델 선택 가능
- VS Code 포크 → 기존 생태계(확장, 설정) 그대로 활용

**약점:**
- $20/월 — Copilot $10 대비 2배

**커뮤니티 평가:** 'Copilot보다 코드 맥락 이해가 깊다', '에이전트 모드에서 자율 디버깅 강력'. Fortune 500의 50%+ 채택

---

## 💪 주요 경쟁자 (Strong Tier)

### GitHub Copilot (Microsoft)
- **티어:** 주요 경쟁자
- **유료 사용자:** 180만+
- **GitHub 기반:** 1억+ 개발자
- **가격:** $10/월
- **Coding Agent:** GA (2025.09)

**강점:**
- 압도적 배포 채널(GitHub 1억+ 개발자). 가격 $10/월로 접근성 최강
- 멀티모델(GPT-5.1, Claude Opus 4.5, Gemini 등) 지원
- 기업 환경 CI/CD 통합이 핵심 강점

**약점:**
- Cursor 대비 코드 맥락 이해 얕음
- 에이전트 모드 병렬 처리 미지원(1개만)

**커뮤니티 평가:** 'pair programming에는 Copilot 안정적', '자율 에이전트는 Cursor가 앞선다'

---

### OpenAI Codex
- **티어:** 주요 경쟁자
- **모델:** GPT-5-Codex
- **연속 작업:** 7시간+
- **가격:** ChatGPT 구독에 포함
- **방식:** 비동기 클라우드 에이전트

**강점:**
- 클라우드 샌드박스 비동기 병렬 코딩 — 여러 작업을 던져놓고 결과 수집
- CLI + IDE 확장 + 웹 + GitHub + iOS 통합. 별도 구독 불필요
- 태스크 복잡도에 따라 사고 시간 동적 조절

**약점:**
- 기존 코드 스타일 무시 경향
- Windsurf $3B 인수 무산으로 IDE 전략 차질

**커뮤니티 평가:** Claude Code가 '팀 문화를 이해하는 시니어', Codex가 '빠르지만 독자적인 솔로 개발자'

---

### Windsurf → Cognition/Google
- **티어:** 주요 경쟁자
- **인수 전 ARR:** $82M
- **OpenAI 인수가:** $3B (무산)
- **Google 지불:** $2.4B (인력+라이선스)
- **현 소속:** Cognition AI

**강점:**
- Cascade AI 에이전트로 Cursor의 직접 경쟁자. $15/월 가격 경쟁력
- 350+ 기업 고객, 수십만 DAU 보유

**약점:**
- CEO+핵심 임원 Google 영입 → 인력 유출
- Cognition 산하 Devin과의 통합 불확실성

**교훈:** AI 스타트업 가치는 기술보다 팀. 핵심 인력 이탈 후 IP/브랜드 가치 급락

---

### Gemini Code Assist / Jules (Google)
- **티어:** 주요 경쟁자
- **무료 완성:** 월 180K회 (Copilot 무료 대비 90배)
- **모델:** Gemini 2.5
- **가격:** Free / Standard / Enterprise

**강점:**
- 파격적 무료 전략. VS Code·JetBrains 지원
- Jules: GitHub 연동 자율 코딩 에이전트 (비동기 PR 생성)
- IDC MarketScape AI 코딩 어시스턴트 리더 선정
- Google Cloud·Vertex AI 통합 + Windsurf CEO 영입

**약점:**
- 독립 도구로서의 브랜드 인지도 약함
- Jules는 아직 Labs 단계

---

## 💎 숨은 보석 (Hidden Gem)

### Replit / Bolt.new / v0 / Lovable
- **티어:** 숨은 보석
- **Lovable ARR:** $100M (8개월)
- **Lovable 밸류에이션:** $6.6B (2025.12) — 유럽 최고가치 AI 스타트업
- **타겟:** 비개발자 / PM / 1인 창업자

**강점:**
- 'vibe coding' 도구 핵심 플레이어. 프롬프트 → 풀스택 앱
- Replit: 클라우드 IDE + 배포 통합 (교육·프로토타이핑)
- v0 (Vercel): React+Tailwind UI 생성 특화, 기술적 퀄리티 최고
- Bolt.new (StackBlitz): WebContainer로 브라우저 내 풀스택 빌드

**약점:**
- 복잡한 프로덕션 앱에는 한계 — MVP/프로토타입 도구
- 코딩 도구 타겟이 '개발자' → '모든 사람'으로 확장되는 증거

---

## ⚠️ 과대평가 (Overhyped)

### Devin (Cognition)
- **티어:** 과대평가 주의보
- **밸류에이션:** $10.2B (2025.09)
- **Devin ARR:** ~$73M (2025.06)
- **실사용 성공률:** ~15% (Answer.AI 테스트)
- **가격:** $500/월 (Team), $20~ (Pay-as-you-go)

**강점:**
- '최초의 AI 소프트웨어 엔지니어' 포지셔닝
- Windsurf 인수 후 합산 밸류에이션 $10.2B
- Goldman Sachs 등 대기업 사용 주장

**약점:**
- Answer.AI 테스트: 20개 과제 중 3개 성공(15%). '기술적 막다른 골목에 며칠씩 갇힘'
- 공식 문서조차 '주니어 개발자처럼 대하라'고 안내
- ARR 대비 65배 배수는 극단적
- The Register: '최초의 AI 엔지니어가 일을 못한다'

**커뮤니티 평가:** AI 시대 과대평가의 교과서. $500/월 Team 요금 대비 ROI 의문 지속
