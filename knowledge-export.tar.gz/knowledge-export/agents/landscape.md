# 🤖 AI 에이전트 지형도 2025-2026

## 프로토콜 & 표준

### MCP (Anthropic → AAIF)
- **티어:** 에이전트 도구 연결의 사실상 글로벌 표준
- **월간 SDK 다운로드:** 97M (Python+TS)
- **활성 MCP 서버:** 10,000+개
- **MCP 클라이언트:** 300+개
- **보안 취약 서버 비율:** 43% (명령 인젝션)
- **강점:**
  - 1년 만에 압도적 채택률
  - 경쟁사 포함 전면 채택: ChatGPT, Gemini, Cursor, VS Code, Microsoft Copilot
  - 2025.12 Linux Foundation AAIF에 기부 — Anthropic·OpenAI·Block 공동 설립으로 중립성 확보
- **약점:**
  - 보안이 아킬레스건: CVE-2025-6514(CVSS 9.6)로 437K+ 환경 영향
  - Tool Poisoning Attack 발견

---

## 에이전트 제품 & 플랫폼

### ChatGPT Agent Mode (OpenAI)
- **티어:** 에이전트를 수억 명에게 배포한 대중화의 선봉
- **사용자 기반:** 수억 ChatGPT 사용자
- **가격:** Plus $20/월 포함
- **강점:**
  - Operator(1월) → Agent Mode(7월): ChatGPT 핵심 기능으로 통합
  - 웹 브라우징, 파일 처리, 코드 실행, Deep Research를 단일 에이전트 인터페이스로 통합
- **약점:**
  - NNGroup: '성공적이되 불안정하고 느리다'
  - Understanding AI: '큰 발전이지만 중요한 작업에는 아직 신뢰 불가'

### Claude Computer Use (Anthropic)
- **티어:** 컴퓨터 사용 AI의 선구자, 벤치마크 리더
- **OSWorld (Sonnet 4.6):** 72.5% (2024.10 대비 5배)
- **OSWorld (Opus 4.6):** 72.7% (SOTA)
- **자율 운영 시간:** 최대 7시간 (Opus 4)
- **초기 사용자 선호도:** 70%가 이전 모델보다 선호
- **강점:**
  - 데스크톱 네이티브: 마우스/키보드/스크린샷으로 GUI 직접 조작
  - Claude for Chrome(Max 사용자) 브라우저 탭 제어

### Cognition (Devin)
- **티어:** 첫 자율 코딩 에이전트, 현실은 '감독된 주니어'
- **가격:** ~$500/석/월
- **밸류에이션:** $4B (2025)
- **강점:**
  - Goldman Sachs, Santander, Citi 등 대기업 도입
  - 주니어급 반복 작업(보안 수정, 마이그레이션)에서 효과적
- **약점:**
  - Reddit/HN: '비싸고 CI 체크 실패 반복', 'hype >>> 실제'
  - 2026.1 PR 코드 리뷰로 피벗 — 자율 코딩보다 코드 리뷰에 재포지셔닝

### Salesforce Agentforce
- **티어:** 엔터프라이즈 에이전트의 최전선, 그러나 채택은 느린
- **Agentforce ARR (FY26 Q3):** $5억+ (YoY 330%↑)
- **Agentforce 딜 수:** ~8,000건 (2026.2 추정)
- **AI 기여 매출:** $670억 (글로벌)
- **FY26 매출 가이던스:** $415억
- **강점:**
  - 42억 고객 서비스 상호작용 처리 (2025.12 기준)
  - $60B 매출 목표(FY30)를 Agentforce + Data Cloud에 베팅
- **약점:**
  - 초기 채택 속도 실망적(5,000 딜 중 유료 3,000)
  - 구현 복잡성과 기존 Salesforce 인프라 의존이 장벽

---

## 프레임워크 & SDK

### OpenAI Agents SDK
- **티어:** OpenAI의 에이전트 인프라 오픈소스 카드
- **호환 LLM:** 100+개
- **지원 언어:** Python + TypeScript
- **핵심 기능:** 핸드오프, 가드레일, 트레이싱
- **라이선스:** 오픈소스
- **강점:**
  - Swarm 후속, 2025.3 오픈소스. 프로바이더 불가지론적
  - 멀티에이전트 오케스트레이션 진입장벽 하락
- **약점:**
  - OpenAI 생태계 종속 우려
  - 병렬 실행 등 고급 기능 제한적

### CrewAI
- **티어:** 멀티에이전트 팀 오케스트레이션의 실용 강자
- **GitHub Stars:** 39,000+
- **월간 다운로드:** 1M+
- **에이전틱 오토메이션:** 1.4B건 처리
- **매출 (2025):** ~$3.2M (29인 팀)
- **강점:**
  - v1.0 정식 출시. Andrew Ng, HubSpot CTO 투자
  - 역할 기반 에이전트 팀(Researcher→Analyst→Writer) 패턴
  - 설문: 기업 65%가 AI 에이전트 실사용 중, 100%가 2026년 확대 계획
  - IA Enablers 리스트 #7 선정

---

## 브라우저 에이전트

### Browser Use
- **티어:** 오픈소스 브라우저 에이전트의 다크호스
- **GitHub Stars:** 50,000+ (3개월)
- **시드 펀딩:** $17M
- **WebVoyager 성공률:** 89.1% (SOTA)
- **활성 기여 개발자:** 15,000+
- **강점:**
  - YC W25 배치, 출시 3개월 만에 역대 가장 빠른 오픈소스 성장 중 하나
  - CAPTCHA 자동 우회, 서브초 초기화
  - 커스텀 LLM 학습 완료 — 브라우저 특화 성능 극대화

---

## 퍼스널 에이전트

### OpenClaw
- **티어:** 로컬-퍼스트 퍼스널 에이전트의 새 패러다임
- **GitHub Stars:** 180K+ (Lex Fridman 인터뷰 시점)
- **초기 릴리스:** 2025.11, MIT 라이선스
- **주간 방문자 피크:** 200만
- **Moltbook 등록 에이전트:** 250만+
- **강점:**
  - 2개월 만에 GitHub 100K+ 스타 — 역대 최빠른 성장
  - 로컬 디바이스 실행: 프라이버시와 커스터마이징 근본적 이점
  - 서브에이전트 패턴: 메인→서브에이전트 동적 생성/파기
- **약점:**
  - 보안 논쟁 중심
  - 2026.2 재단 이관, 창시자 OpenAI 합류

---

## 엔터프라이즈 플랫폼

### Microsoft Copilot Studio
- **티어:** 엔터프라이즈 에이전트 빌더의 조용한 강자
- **플랫폼:** Agent 365 + Copilot Studio
- **파트너:** Adobe, Manus, SAP, ServiceNow, Workday 등
- **과금:** ACU(Agent Commit Units) 기반
- **강점:**
  - No-code 에이전트 빌더
  - Microsoft Foundry 통합
  - 엔터프라이즈 보안·컴플라이언스·거버넌스 최적화

### Google (Mariner / A2A / ADK)
- **티어:** 기술은 탄탄하나 채택은 프리미엄 장벽에 막힌
- **AI Ultra 가격:** $249.99/월
- **A2A 런치 파트너:** 50+개사
- **Mariner 동시 창:** 최대 10개
- **A2A 상태:** Linux Foundation 이관 완료
- **강점:**
  - Gemini 2.5 기반 브라우저 에이전트, teach-and-repeat 자동화
  - A2A 에이전트 간 통신 프로토콜 출시
  - ADK: Vertex AI 통합 에이전트 개발 키트
- **약점:**
  - AI Ultra $249.99/월 가격이 대중화 장벽
  - A2A는 MCP 대비 채택 저조
