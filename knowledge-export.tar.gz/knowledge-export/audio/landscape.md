# 🔊 AI 음성/음악 지형도 2025-2026

## 👑 절대 강자

### ElevenLabs
- **밸류에이션:** $110억 (2026.02 시리즈 D)
- **ARR:** $330M+ (2025 말)
- **총 펀딩:** ~$800M
- **핵심 모델:** Eleven v3, Music, Scribe v2, Agents
- **강점:**
  - Eleven v3 — 오디오 태그로 감정/속삭임/웃음 제어, 50개 언어. 사람과 '구별 불가능' 수준
  - 풀스택 음성 AI: TTS(v3) + STT(Scribe v2) + 음악(Eleven Music) + 더빙 + 음성 에이전트 + 사운드 효과
  - 3년 만에 창업 → 데카콘. Sequoia 리드, a16z 4배 증액
  - Deutsche Telekom, Square, Revolut, 우크라이나 정부 등 엔터프라이즈 고객
- **차별화:** 라이선스 데이터 기반 음악 생성 → Suno/Udio 대비 '합법적 AI 음악'

---

## 💪 강자

### Suno
- **밸류에이션:** $24.5억 (2025.11)
- **ARR:** $140M~$200M
- **일일 생성:** 700만 곡
- **소송 상태:** WMG 합의, UMG/Sony 소송 중
- **강점:**
  - 가장 대중적 AI 음악 도구. v4 → v4.5 진화
  - Personas, Stems 추출, 보컬 추가 등 기능 확대
  - $250M 시리즈 C, NVIDIA NVentures 참여
  - 텍스트 프롬프트만으로 풀 곡 생성 — 진입장벽 제로, '음악의 ChatGPT'
- **약점:**
  - 프로 음악가의 도구라기보다 '소비자 놀이터'
  - 인디 아티스트 집단소송 별도 진행 중

### OpenAI Voice/Audio
- **핵심 모델:** gpt-realtime (2025.08)
- **함수 호출:** 66.5% 정확도
- **비용 절감:** 입력 토큰 60% 인하
- **파트너:** LiveKit 공식 파트너십
- **강점:**
  - GPT-4o Advanced Voice — 실시간 음성 대화, 감정/유머/멀티모달 이해
  - Realtime API — 저지연 speech-to-speech
  - '대화형 AI의 일부로서의 음성'이라는 독자적 포지셔닝
- **약점:**
  - TTS 전문 기업 아님
  - Advanced Voice 모드에서 '혼란스러워하는' 문제 보고됨

### Google (NotebookLM + Gemini TTS)
- **NotebookLM:** Audio Overview 포맷 5종+
- **Gemini TTS:** Flash + Pro 이중 구조 (2025.12)
- **통합:** Gemini Live, Search Live, AI Studio
- **강점:**
  - NotebookLM Audio Overview — 문서→팟캐스트 변환. '2024 AI 도구 올해의 도구'
  - 톤 커스터마이징, 포맷 다양화(딥다이브/토론/요약/소개), 단일 화자 모드
  - Gemini 2.5 Flash Native Audio → Search Live 통합
- **약점:**
  - 독립 TTS 제품이 아닌 거대 생태계의 일부
  - 개별 품질보다 '어디에나 있는' 통합이 강점

---

## ⚠️ 기대주 / 주의

### Udio
- **합의 상태:** UMG (2025.10), WMG (2025.11)
- **소송 중:** Sony, 인디 아티스트 집단소송
- **출시 예정:** 2026년 라이선스 기반 플랫폼
- **강점:**
  - Google DeepMind 출신 팀
  - UMG + WMG 합의+라이선싱 딜 확보
- **약점:**
  - 새 플랫폼 미출시 — '합의'가 제품 자유도를 어떻게 제약할지 미지수
  - Suno 대비 인지도·사용자 기반 뒤처짐
  - 펀딩 규모·ARR 데이터 비공개

---

## 💎 숨은 보석

### 오픈소스 TTS (Kokoro, Orpheus, Dia, Chatterbox)
- **Kokoro:** 82M params, Apache 2.0
- **Chatterbox:** 0.5B, HuggingFace #1 트렌딩, 감정 조절 (업계 최초 오픈소스)
- **Dia:** 1.6B, Apache 2.0, 대화 특화
- **F5-TTS:** GitHub 14k+ stars
- **강점:**
  - 2025년은 오픈소스 TTS의 해 — Kokoro, Orpheus(Llama 기반), Dia, Chatterbox 줄줄이 등장
  - Chatterbox: 제로샷 음성 클론, 감정 과장/절제 조절, 내장 워터마킹
  - VibeVoice(다중 화자), MegaTTS3 등 생태계 폭발적 확장
  - GPU 하나면 ElevenLabs 80%+ 수준 로컬 구동 가능
  - 대부분 Apache 2.0 / MIT — 상업 사용 가능
- **적합 분야:** 프라이버시 민감 영역(의료, 금융), 비용 민감 스타트업
