# OpenClaw 커뮤니티 & 실사용 경험 수집

> 수집일: 2026-02-21 | 출처: 공식 문서, Simon Willison TIL, Reddit r/openclaw, 공식 Showcase, FAQ

---

## 1. 설치 난이도에 대한 실사용자 평가

### 공식 가이드의 자기 평가
- **"5분이면 된다"**: Node 22+, API 키 하나, 5분 (공식 docs 메인 페이지)
- **설치 방법**: `curl -fsSL https://openclaw.ai/install.sh | bash` → `openclaw onboard --install-daemon`
- **Windows**: PowerShell `iwr -useb https://openclaw.ai/install.ps1 | iex`
- **FAQ에 "설치+온보딩 시간" 항목이 별도로 있음** → 자주 물어본다는 뜻

### Simon Willison의 Docker 설치 경험 (2026-02-01)
- **"처음 시도에서 두 번 실패하고 세 번째에 성공"**
- 까다로웠던 부분:
  - Onboarding mode 선택: `manual` 선택이 안전
  - Model provider 선택: **OpenAI Codex + ChatGPT OAuth** 선택 (비용 상한 때문에)
    - OAuth 리다이렉트가 localhost로 가는데, 실제로는 서비스가 안 돌아가서 에러 페이지가 뜸 → 그 URL을 복사해서 OpenClaw에 붙여넣어야 함
  - **Tailscale 설정을 처음에 시도했다가 기기를 못 쓰게 됨** → 두 번째에는 "no" 선택
- Docker CLI 컨테이너 이름: `openclaw-openclaw-gateway-1`
- 추가 패키지 설치 시 root로 접근 필요:
  ```bash
  docker compose exec -u root openclaw-gateway bash
  apt-get update && apt-get install -y ripgrep
  ```

### FAQ에서 드러나는 흔한 설치 문제들
- "wake up my friend" 화면에서 멈춤 → 온보딩이 해치(hatch)되지 않는 문제
- Windows에서 `git not found` 또는 `openclaw not recognized`
- 인스톨러가 멈추는 경우 → 디버깅 피드백 부족
- `gateway.mode=local` 설정 안 하면 게이트웨이 시작 차단됨

### 종합 평가
- **개발자/파워유저**: 비교적 순조로움 (5~30분)
- **Docker 사용자**: 첫 시도에서 실수할 여지가 많음 (Tailscale, OAuth 흐름)
- **초보자**: 채널 설정(WhatsApp/Telegram 페어링)에서 헤맬 수 있음

---

## 2. 흔한 함정/주의점

### 설치 시
| 함정 | 해결 |
|------|------|
| Tailscale 첫 설정에서 기기 사용 불가 | 초기에는 Tailscale 건너뛰기 |
| OAuth 리다이렉트가 localhost 에러 페이지로 감 | 에러 URL 전체를 복사해서 OpenClaw에 입력 |
| Docker에서 permission denied (EACCES) | host bind mount를 uid 1000으로 chown |
| `config.apply`가 설정을 날림 | 설정 백업 필수 |
| 서비스로 실행 시 env vars 사라짐 | 서비스에 env를 직접 설정해야 함 |

### 운영 시
| 함정 | 해결 |
|------|------|
| 그룹 메시지에 응답 안 함 | `requireMention` 설정 확인 → `@openclaw` 멘션 필요 |
| DM에 응답 안 함 | pairing 승인 필요 (`openclaw pairing approve`) |
| Dashboard 접속 `unauthorized` | `openclaw dashboard --no-open`으로 토큰 URL 재생성 |
| `disconnected (1008): pairing required` | device list 확인 후 approve |
| 하트비트 메시지가 30분마다 옴 | 의도된 동작, quiet-hours 설정으로 조절 |
| 컨텍스트가 너무 커서 에러 | `/new`로 세션 리셋 또는 compaction 설정 |
| `HTTP 429: rate_limit_error` | Anthropic API 속도제한 → 키 로테이션 또는 다른 프로바이더 |

### 보안 관련
- 에이전트가 **동의 없이 행동할 수 있음** (LinkedIn DM을 자동으로 보낸 Reddit 사례)
- Docker 에이전트는 sudo 없이 실행됨 (보안상 좋지만 제한적)
- `allowFrom` 설정으로 허용 사용자 제한 필수
- 그룹에서는 `requireMention: true` 권장

---

## 3. 추천 설정 조합

### 모델 프로바이더 선택
| 프로바이더 | 특징 | 추천 사용 |
|-----------|------|----------|
| **Anthropic Claude Opus 4.6** | 가장 강력, API 키 직접 | 코딩, 복잡한 작업 |
| **OpenAI Codex OAuth** | ChatGPT 구독으로 사용, 비용 상한 있음 | 비용 걱정되는 초보 |
| **OpenRouter** | 여러 모델 라우팅 | 다양한 모델 사용 시 |
| **Venice AI** | 프라이버시 중심 + Opus 옵션 | 프라이버시 중시 사용자 |
| **Ollama (로컬)** | 무료, 로컬 실행 | 캐주얼 챗 |
| **GitHub Copilot** | Copilot 구독 활용 | 이미 Copilot 있을 때 |

### 채널 조합 인기도 (Showcase/Reddit 기반)
1. **Telegram** — 설정 가장 쉬움 (BotFather로 봇 생성 → 토큰 입력)
   - Simon Willison도 "least hassle"로 선택
2. **WhatsApp** — 개인용으로 가장 편리 (QR 코드 스캔)
3. **Discord** — 커뮤니티/팀용, 봇 토큰 필요
4. **iMessage** — macOS 전용, Mac mini 필요
5. **Slack/Mattermost** — 팀/업무용

### 실행 환경 추천
| 환경 | 장점 | 단점 |
|------|------|------|
| **로컬 Mac** | 빠른 개발, iMessage 지원 | 노트북 닫으면 중단 |
| **Mac mini (전용)** | 24/7, iMessage, macOS 스킬 | 하드웨어 비용 |
| **VPS (Hetzner 등)** | 24/7, 저렴 | iMessage 불가, macOS 스킬 불가 |
| **Docker** | 격리, 이식성 | 설정 복잡도 ↑ |
| **Raspberry Pi** | 초저전력 | 성능 제한, FAQ에 별도 팁 항목 있음 |

### 최소 "제정신" 설정 (FAQ 기반)
```json5
{
  channels: {
    whatsapp: {
      allowFrom: ["+15555550123"],
      groups: { "*": { requireMention: true } },
    },
  },
  messages: { groupChat: { mentionPatterns: ["@openclaw"] } },
}
```

---

## 4. "이렇게 하면 안 된다" 사례

### ❌ 초기 설정에서 Tailscale 바로 켜기
- Simon Willison: "첫 번째에 Tailscale 설정을 시도했더니 사용할 수 없는 기기가 됐다"
- → **첫 설정에서는 건너뛰고, 기본 동작 확인 후 나중에 설정**

### ❌ 에이전트에 제한 없이 브라우저 접근 허용
- Reddit 사례: "LinkedIn DM을 동의 없이 보냄"
- → **브라우저 자동화 시 승인(approval) 정책 설정 필수**

### ❌ API 키 직접 사용 시 비용 상한 없이 방치
- Opus 모델은 토큰 소비가 많음
- → **Codex OAuth(ChatGPT 구독) 사용하면 월 $20 상한**, 또는 usage tracking으로 모니터링

### ❌ `gateway.bind: "lan"` 설정 후 auth 미설정
- 비-로컬 바인딩에는 반드시 token/password 필요
- → 에러: `refusing to bind gateway ... without auth`

### ❌ `config.apply`로 설정 덮어쓰기
- 기존 설정이 날아갈 수 있음
- → **설정 변경 전 반드시 백업** (`~/.openclaw/openclaw.json`)

### ❌ Docker에서 npx로 Playwright 설치
- npm override 충돌 가능
- → `node /app/node_modules/playwright-core/cli.js install chromium` 사용

---

## 5. 비용 (API 사용료 실제 경험)

### Reddit 사용자 실사례
- **구직 자동화 (3일간)**: ~$40/week
  - 모델: Claude 4.6 Opus via GitHub Copilot workaround
  - 100+ 지원서 제출, LinkedIn DM 자동 발송
  - "was using github copilot with a workaround"

### 비용 절감 전략 (문서/커뮤니티 기반)
1. **ChatGPT/Codex OAuth**: $20/month 구독으로 사용, 사용량 상한 있음
2. **Claude Max 구독**: API 키 없이 구독 인증 가능 (FAQ에 별도 항목)
3. **GitHub Copilot**: 기존 구독 활용
4. **Gemini CLI OAuth / Qwen Portal OAuth**: 무료 티어 존재
5. **Ollama (로컬)**: 완전 무료, 하드웨어만 필요
6. **Venice AI**: 프라이버시 + 비용 효율

### 사용량 모니터링
- `/status` 명령으로 세션 토큰 + 예상 비용 확인 (API 키 사용 시)
- `/usage off|tokens|full` 으로 응답별 사용량 표시 조절
- `/usage cost` 로 로컬 비용 요약
- CLI: `openclaw status --usage` 로 프로바이더별 분석

### 주의
- **하트비트가 ~30분마다 토큰을 소비함** → quiet-hours 설정 또는 비활성화 고려
- **Opus 모델은 특히 비쌈** → 코딩 작업에만 쓰고 캐주얼 챗은 Sonnet/로컬 모델

---

## 6. 커뮤니티 쇼케이스 프로젝트

### 공식 Showcase (docs.openclaw.ai/start/showcase)

| 프로젝트 | 제작자 | 카테고리 | 설명 |
|----------|--------|---------|------|
| **PR Review → Telegram** | @bangnokia | review, github, telegram | OpenCode PR → OpenClaw이 diff 리뷰 → Telegram에 머지 판정 |
| **Wine Cellar Skill** | @prades_maxime | skills, local, csv | CSV에서 962병 와인 데이터 → 맞춤 스킬 자동 생성 |
| **Tesco Shop Autopilot** | @marchattonhere | automation, browser | 주간 식단 → 장보기 → 배달 슬롯 예약, API 없이 브라우저 제어만 |
| **SNAG** | @am-will | devtools, screenshots | 화면 영역 캡처 → Gemini vision → 클립보드에 마크다운 |
| **Agents UI** | @kitze | ui, skills, sync | Agents/Claude/Codex/OpenClaw 스킬 통합 관리 데스크톱 앱 |
| **Telegram Voice Notes** | Community | voice, tts, telegram | papla.media TTS → Telegram 음성 메모 |
| **CodexMonitor** | @odrobnik | devtools, codex | Homebrew로 Codex 세션 관리/모니터링 (CLI + VS Code) |
| **Bambu 3D Printer** | @tobiasbischoff | hardware, 3d-printing | BambuLab 프린터 제어/진단 스킬 |

### Reddit 하이라이트
| 사례 | 상세 |
|------|------|
| **구직 자동화 → 연봉 2배** | 브라질 개발자, LinkedIn+기타 플랫폼 100+ 지원, 3일 만에 연봉 2배 제안, 비용 ~$40 |

### YouTube 가이드
| 영상 | 제작자 | 길이 |
|------|--------|------|
| **"OpenClaw: The self-hosted AI that Siri should have been"** | VelvetShark | 28분 풀 셋업 워크스루 |
| 쇼케이스 비디오 2편 | 공식 | - |

---

## 7. 성능/안정성 경험담

### Simon Willison 경험
- Docker에서 안정적으로 실행됨
- Web UI(대시보드)가 디버깅 도구 + 웹 채팅 인터페이스 제공
- Telegram 채널 연결 후 폰에서 직접 제어 가능
- **단점**: 에이전트가 sudo 없이 실행 → 시스템 패키지 설치 불편

### 트러블슈팅 체계
공식 문서에 **매우 상세한 트러블슈팅 트리**가 있음:
1. 응답 없음 → pairing/mention 확인
2. 대시보드 접속 불가 → 토큰/인증 확인
3. 게이트웨이 미시작 → mode/port 확인
4. 채널 연결됐는데 메시지 안 흐름 → 정책/권한 확인
5. 크론/하트비트 미동작 → 스케줄러/quiet-hours 확인
6. 노드 연결됐는데 도구 실패 → 포그라운드/권한/승인 확인
7. 브라우저 도구 실패 → CDP/프로필/확장 확인

### 진단 명령어 (순서대로)
```bash
openclaw status
openclaw status --all
openclaw gateway probe
openclaw gateway status
openclaw doctor
openclaw channels status --probe
openclaw logs --follow
```

### 업그레이드 후 문제
- 설정 드리프트 또는 더 엄격해진 기본값이 원인
- `gateway.auth.mode` 변경, 바인딩+인증 가드레일 강화, 페어링/디바이스 상태 변화
- 해결: `openclaw gateway install --force && openclaw gateway restart`

---

## 8. 지원되는 채널 전체 목록

공식 docs/llms.txt 기반:
- WhatsApp, Telegram, Discord, iMessage
- Slack, Mattermost, Signal
- IRC, LINE, Matrix
- Microsoft Teams, Google Chat, Feishu
- Zalo (개인용 포함)
- 커뮤니티 플러그인으로 확장 가능

---

## 9. 핵심 리소스 링크

| 리소스 | URL |
|--------|-----|
| 공식 문서 | https://docs.openclaw.ai |
| 문서 인덱스 (LLM용) | https://docs.openclaw.ai/llms.txt |
| Getting Started | https://docs.openclaw.ai/start/getting-started |
| FAQ (매우 방대) | https://docs.openclaw.ai/help/faq |
| 트러블슈팅 | https://docs.openclaw.ai/help/troubleshooting |
| Docker 가이드 | https://docs.openclaw.ai/install/docker |
| 모델 프로바이더 | https://docs.openclaw.ai/concepts/model-providers |
| Showcase | https://docs.openclaw.ai/start/showcase |
| Simon Willison TIL | https://til.simonwillison.net/llms/openclaw-docker |
| Reddit r/openclaw | https://www.reddit.com/r/openclaw |
| ClawHub (스킬 허브) | https://clawhub.ai |
| Discord 커뮤니티 | https://discord.gg/clawd |
| VelvetShark 셋업 영상 | https://www.youtube.com/watch?v=SaWSPZoPX34 |

---

## 10. 조사 한계 및 참고사항

- **Brave Search API 키 미설정**: 웹 검색 도구를 사용하지 못해 직접 URL 접근 방식으로 대체
- **Hacker News**: Algolia 검색 결과가 JavaScript 렌더링 필요로 내용 추출 실패
- **Reddit**: 로그인 없이 접근 가능한 콘텐츠 제한적 (상위 1개 포스트만 추출됨)
- **FAQ 본문**: 목차만 추출되고 실제 답변은 JavaScript 렌더링 필요로 전문 미확인
- **YouTube 영상**: 실제 시청 불가, 제목/설명만 확인
- 추가 커뮤니티 경험을 위해 Discord (#showcase, #help 채널) 직접 확인 권장
