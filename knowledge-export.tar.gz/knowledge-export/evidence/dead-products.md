# 2025-2026 AI 제품 사망/피봇/인수 증거 모음

> 수집일: 2026-02-20
> 원칙: 논리나 의견 금지. 오직 증거만.

---

## 1. Builder.ai — AI 워싱의 대가

- **이름:** Builder.ai
- **사망/피봇 시기:** 2025년 5월 파산 신청, 2025년 8월 완전 폐업
- **한 줄 설명:** "AI 비서 Natasha"로 코딩 없이 앱 개발 가능하다고 홍보한 노코드 플랫폼
- **사인:** AI 능력 과대광고. 실제로는 인도 오프쇼어 개발자들이 수작업 처리. 수익 부풀리기 의혹. 주요 대출기관이 현금 압류 → CEO 퇴출 → 자금 고갈
- **증거 (수치):** 누적 투자 ~$445M / 최고 밸류에이션 $1.5B / Microsoft, Qatar Investment Authority 등이 투자 / 수백 명 해고 후 파산
- **교훈:** AI 워싱(AI-washing)은 1~2분기는 속일 수 있어도, AI 분야에서는 결과를 쉽게 테스트할 수 있기 때문에 빠르게 들통남
- **출처 URL:** <https://techstartups.com/2025/12/09/top-ai-startups-that-shut-down-in-2025-what-founders-can-learn/>

---

## 2. Humane (AI Pin) — $230M 태우고 HP에 헐값 매각

- **이름:** Humane AI Pin
- **사망/피봇 시기:** 2025년 2월 셧다운, HP에 자산 매각
- **한 줄 설명:** 전 Apple 임원들이 만든 웨어러블 AI 디바이스. 옷에 클립으로 달아 음성+프로젝터로 스마트폰 대체 목표
- **사인:** 리뷰어 혹평 ("bad at almost everything it does"). 배터리/발열 문제. 반품률이 판매량 초과. 스마트폰 대비 가치 불분명
- **증거 (수치):** 투자 ~$241M / 밸류에이션 $850M / HP에 $116M에 매각 (투자금의 절반도 회수 못함) / 가격 $699 + 월 $24 구독 / 반품률 > 판매율
- **교훈:** 아무리 화려한 디자인 경력과 투자금이 있어도, 실제 사용 경험이 기존 제품(스마트폰)보다 나아야 함. 소비자 하드웨어에서 두 번째 기회는 없음
- **출처 URL:** <https://www.wired.com/story/the-humane-ai-pin-has-already-been-brought-back-to-life/>, <https://www.engadget.com/ai/the-humane-ai-pin-debacle-is-a-reminder-that-ai-alone-doesnt-make-a-compelling-product-190119112.html>

---

## 3. Rabbit R1 — 95% 사용자 이탈, 급여 미지급 위기

- **이름:** Rabbit R1
- **사망/피봇 시기:** 2024년 출시 → 2025년 사실상 실패 (회사 존속 중이나 위기)
- **한 줄 설명:** CES 2024에서 화제가 된 AI 하드웨어 기기. "Large Action Model"로 소프트웨어 작업 자동화 표방
- **사인:** 출시 후 극심한 실망. 95% 이탈률 (100K 판매 → DAU 5,000). 기능 미달. 보안 취약점 노출. 직원 급여 미지급 보도
- **증거 (수치):** 밸류에이션 $175M / CES에서 100K대 판매 / DAU 5,000으로 급감 (95% 이탈) / Jony Ive가 "very poor product"이라 공개 비판 / 2025년 하반기 급여 미지급 의혹 (Yahoo Finance 보도)
- **교훈:** 바이럴 론칭과 실제 제품 가치는 다름. 스마트폰이 이미 AI 기능을 갖추고 있을 때 별도 디바이스의 존재 이유를 증명하지 못하면 실패
- **출처 URL:** <https://finance.yahoo.com/news/next-rabbit-employees-haven-t-151201843.html>, <https://www.theverge.com/news/671955/jony-ive-rabbit-r1-humane-ai-pin>

---

## 4. Inflection AI → Microsoft 역인수합병 (Acqui-hire)

- **이름:** Inflection AI (Pi 챗봇)
- **사망/피봇 시기:** 2024년 3월 Microsoft에 사실상 인수
- **한 줄 설명:** DeepMind 공동창업자 Mustafa Suleyman이 만든 챗봇 Pi. "감정적으로 공감하는 AI" 표방
- **사인:** $1.5B 투자 유치했으나 매출 거의 없음. Microsoft가 $650M에 기술 라이선스 + 70명 직원 대부분 고용. 회사 껍데기만 남음
- **증거 (수치):** 총 투자 ~$1.5B / Microsoft 라이선스료 $620M + 법적합의 $30M / 투자자에게 $1.10~$1.50/dollar 반환 / 직원 70명 중 대부분 Microsoft 이동 / Suleyman이 Microsoft AI CEO로 취임
- **교훈:** 빅테크의 "역인수합병(reverse acqui-hire)" 패턴의 시초. 스타트업이 인재+기술로 가치가 있으나 독자 사업으로 수익화 못하면, 빅테크에 흡수됨
- **출처 URL:** <https://www.deeplearning.ai/the-batch/microsoft-pays-inflection-ai-650-million-hires-most-of-its-staff/>, <https://ff.co/ai-acquihires/>

---

## 5. Adept AI → Amazon 역인수합병

- **이름:** Adept AI
- **사망/피봇 시기:** 2024년 6월 Amazon에 사실상 인수
- **한 줄 설명:** AI 에이전트로 소프트웨어 작업 자동화. "Digital Agent" 개발
- **사인:** 독자 모델 개발에 추가 자금 필요 → Amazon이 CEO 및 핵심 인력 고용 + 기술 라이선스. 남은 직원 ~20명
- **증거 (수치):** 총 투자 ~$415M / Amazon이 CEO David Luan 및 핵심 팀 고용 / 기술+데이터 라이선스 / FTC 조사 착수 / LinkedIn 기준 잔여 직원 4명
- **교훈:** 인수합병 규제를 우회하는 "라이선스+고용" 패턴이 확산. 스타트업이 자체 수익모델 없이 기초모델만 훈련하면 빅테크의 인재 쇼핑 대상이 됨
- **출처 URL:** <https://techcrunch.com/2024/06/28/amazon-hires-founders-away-from-ai-startup-adept/>, <https://www.cnbc.com/2024/07/16/amazons-deal-with-ai-startup-adept-faces-ftc-scrutiny.html>

---

## 6. Windsurf (구 Codeium) — 3사에 걸친 해체

- **이름:** Windsurf (구 Codeium)
- **사망/피봇 시기:** 2025년 7월 (OpenAI $3B 인수 실패 → Google $2.4B 역인수합병 → Cognition이 잔여 인수)
- **한 줄 설명:** AI 코딩 IDE. 기업 350+개 고객, ARR $82M
- **사인:** OpenAI의 $3B 인수 제안 → Microsoft가 IP 접근 제한 거부 → 딜 붕괴 → Google DeepMind가 CEO+공동창업자+핵심 R&D 인력 $2.4B에 고용 → 나머지 250명은 Cognition(Devin)이 인수
- **증거 (수치):** ARR $82M / 350+ 고객 / 200+ 직원 / 밸류에이션 $1.25B (2024) → OpenAI 제안 $3B / Google 라이선스 $2.4B / 최근 1년 입사자는 Google 딜에서 정산 못 받음 (The Information 보도) / Cognition이 "100% 직원 참여" 보장하며 인수
- **교훈:** AI 스타트업이 빅테크의 인재 쟁탈전의 분쟁 대상이 됨. 회사가 아니라 인재와 IP가 거래 대상이 되는 "역인수합병" 시대
- **출처 URL:** <https://www.klover.ai/ai-strategy-windsurf-acquired-by-openai-then-google-then-cognition-ai/>, <https://techcrunch.com/2025/07/14/cognition-maker-of-the-ai-coding-agent-devin-acquires-windsurf/>

---

## 7. Character.AI → Google 역인수합병 + 안전 소송

- **이름:** Character.AI
- **사망/피봇 시기:** 2024년 8월 Google에 사실상 인수 (역인수합병)
- **한 줄 설명:** AI 챗봇 동반자 플랫폼. 월간 사용자 2,000만 이상. 사용자의 대부분이 청소년
- **사인:** Google이 $2.7B에 기술 라이선스 + 공동창업자 2명(Noam Shazeer, Daniel De Freitas) 및 30명 재고용. 14세 소년 자살 사건으로 소송 피소. 2026년 1월 소송 합의
- **증거 (수치):** Google 라이선스료 $2.7B / 월간 사용자 20M+ / 14세 Sewell Setzer III 자살 → 부모 소송 / 판사가 "챗봇 출력물은 언론자유 보호 대상 아님" 판결 (2025년 5월) / 18세 미만 자유대화 금지 조치
- **교훈:** AI 동반자 제품은 안전 문제가 존재적 위험. 청소년 사용자에 대한 안전장치 없이 출시하면 법적 책임과 규제 리스크에 직면
- **출처 URL:** <https://news.bloomberglaw.com/litigation/character-ai-google-agree-to-settle-teen-chatbot-harm-lawsuits>, <https://futurism.com/character-ai-google-test-ai-chatbots-kids>

---

## 8. Stability AI — 오픈소스의 대가, 경영난

- **이름:** Stability AI (Stable Diffusion)
- **사망/피봇 시기:** 2024년 3월 CEO 사임, 4월 10% 감원, 이후 구조조정 지속 (회사 존속 중)
- **한 줄 설명:** Stable Diffusion 이미지 생성 모델 개발. 오픈소스 AI의 상징적 기업
- **사인:** GPU 렌탈 비용 $99M vs 예상 매출 $11M. CEO Emad Mostaque 사임. AWS 결제 연체. 핵심 연구원 이탈
- **증거 (수치):** GPU 렌탈 비용 ~$99M (AWS, Google Cloud, CoreWeave) / 예상 매출 ~$11M / 직원 ~200명에서 10% 감원 / CEO 사임 후 COO+CTO가 공동 대표 대행 / 투자금 ~$100M+
- **교훈:** 오픈소스 모델은 채택에는 유리하지만 수익화는 별개. GPU 비용 대비 매출이 10:1 비율이면 지속 불가능
- **출처 URL:** <https://siliconangle.com/2024/04/18/stability-ai-lay-off-10-staff-wake-resignation-ceo/>, <https://www.theregister.com/2024/04/18/stability_ai_layoff_staff/>

---

## 9. Jasper AI — ChatGPT에 의한 매출 붕괴

- **이름:** Jasper AI
- **사망/피봇 시기:** 2023년 하반기부터 위기, 2024~2025년 매출 급감 (회사 존속 중)
- **한 줄 설명:** AI 마케팅 카피라이팅 도구. 초기 GenAI SaaS 선두주자
- **사인:** ChatGPT 출시로 핵심 기능이 무료로 대체됨. 고객이 "무료 ChatGPT로 충분" 판단. 내부 밸류에이션 20% 하향
- **증거 (수치):** 투자 $131M / 밸류에이션 $1.5B (2022) → 내부 ~$1.2B / 매출: 2023년 $120M → 2024년 $35~55M (53% 감소) / 고객수: 120K → 100K / 감원 실시 (투자 유치 9개월 후)
- **교훈:** 하이퍼스케일러(ChatGPT, Gemini 등)가 당신의 핵심 기능을 무료로 제공하면 끝. "AI 래퍼" 비즈니스의 한계를 보여주는 대표 사례
- **출처 URL:** <https://sqmagazine.co.uk/jasper-ai-statistics/>, <https://www.maginative.com/article/jasper-cuts-internal-valuation-as-ai-growth-slows/>

---

## 10. Chegg — "Killed by ChatGPT"의 교과서적 사례

- **이름:** Chegg
- **사망/피봇 시기:** 2023년~2025년 연속 하락, 2025년 10월 45% 감원 (회사 존속 중)
- **한 줄 설명:** 교육 기술 플랫폼 (숙제 도움, 교재 렌탈, 과외)
- **사인:** ChatGPT와 Google AI Overviews가 핵심 사업(숙제 답안)을 무료로 대체. Google 검색 트래픽 -49% (2025년 1월). Google을 상대로 소송 제기
- **증거 (수치):** 주가 99% 하락 / 직원 388명 해고 (전체의 45%) / 총 4차례 감원으로 1,396명 해고 / 매출: 2024 Q4 $72.7M (전년 대비 -49%) / 비구독자 트래픽: 2024 Q2 -8% → 2025년 1월 -49% / 시가총액 $0.61/주 (52주 최고 $1.84 대비 -67%)
- **교훈:** AI가 기존 산업을 파괴하는 가장 명확한 사례. "학생이 무료로 답을 얻을 수 있는데 왜 돈을 내나?" ChatGPT는 Chegg의 존재 이유를 제거
- **출처 URL:** <https://www.forbes.com/sites/petercohan/2025/10/29/chegg-stock-down-99-learn-whether-ai-45-layoffs-make-chgg-a-buy/>, <https://timesofindia.indiatimes.com/technology/tech-news/google-and-ai-are-to-blame-edutech-company-chegg-on-cutting-hundreds-of-jobs/articleshow/124875789.cms>

---

## 11. Olive AI — $4B 유니콘의 몰락

- **이름:** Olive AI
- **사망/피봇 시기:** 2023년 10월 31일 폐업 (영향은 2024-2025까지 지속)
- **한 줄 설명:** 헬스케어 자동화 AI. 900+ 병원에서 사용, 수익주기 관리(RCM) 자동화
- **사인:** 급속 확장 후 집중 실패. CEO가 "실수(missteps)"를 인정. 2022년 450명 해고 → 2023년 215명 추가 해고 → 자산 분매 후 폐업
- **증거 (수치):** 밸류에이션 $4B (2021) / 총 투자 $848M ($400M 라운드 포함) / 900+ 병원 고객 / 자산을 Waystar, Humata Health에 분매 / JobsOhio에 의해 고용 목표 미달로 소송
- **교훈:** "모든 것을 자동화"하려는 욕심은 집중력 부족으로 이어짐. 빠른 성장이 반드시 건전한 성장은 아님
- **출처 URL:** <https://www.healthcaredive.com/news/olive-ai-shuts-down/698455/>, <https://www.beckershospitalreview.com/healthcare-information-technology/digital-health/the-rise-and-fall-of-olive-ai-a-timeline/>

---

## 12. Noogata — 엔터프라이즈 파일럿 함정

- **이름:** Noogata
- **사망/피봇 시기:** 2025년 5월 폐업
- **한 줄 설명:** 이스라엘 기반 엔터프라이즈 AI 분석 플랫폼. PepsiCo, Colgate 등 대기업 파일럿
- **사인:** 파일럿에서 본계약으로 전환 실패. 대기업 로고만 확보하고 실질 매출 확대 못함. 클라우드 플랫폼의 AI 기능 내장으로 차별화 상실
- **증거 (수치):** 투자 $28M (Seed + Series A) / Team8 등 유명 VC 투자 / PepsiCo, Colgate 파일럿 / 신규 라운드 실패 → 기술 매각 시도
- **교훈:** "대기업 고객 확보"는 슬라이드덱용. 실질적 마일스톤은 "해당 기업 내부에 광범위하게 배포되고 확장 중인가"
- **출처 URL:** <https://techstartups.com/2025/12/09/top-ai-startups-that-shut-down-in-2025-what-founders-can-learn/>

---

## 13. Tune AI (구 Nimblebox) — 하이퍼스케일러에 밀린 범용 플랫폼

- **이름:** Tune AI (구 Nimblebox)
- **사망/피봇 시기:** 2025년 폐업
- **한 줄 설명:** GenAI 플랫폼 (Tune Chat + Tune Studio). LLM 파인튜닝 및 배포 도구
- **사인:** 주요 클라우드 제공업체(AWS, Azure, GCP)가 동일 기능을 더 저렴하거나 번들로 제공. 무료 개발자 대거 유입되었으나 유료 전환 실패. 인프라 비용 > 마진
- **증거 (수치):** Accel, Flipkart Seed 투자 / "수십만 사용자" 주장했으나 유료 전환 부진 / Nimblebox → Tune AI 피봇
- **교훈:** 하이퍼스케일러가 당신의 핵심 기능을 체크박스로 제공하면 게임 오버. 빅테크가 할 수 없는/안 하는 특정 워크플로우에 집중해야 함
- **출처 URL:** <https://techstartups.com/2025/12/09/top-ai-startups-that-shut-down-in-2025-what-founders-can-learn/>

---

## 14. CodeParrot — AI 코드 생성의 "피봇 지옥"

- **이름:** CodeParrot
- **사망/피봇 시기:** 2025년 7월 폐업
- **한 줄 설명:** Figma 디자인을 프로덕션 프론트엔드 코드로 변환하는 AI 도구 (YC W23)
- **사인:** 생성 코드 품질이 프로덕션 수준 미달 → 개발자가 수정하는 데 드는 시간이 절약 시간과 비등. GitHub Copilot, Replit 등 거대 경쟁자. 반복 피봇으로 집중력 상실
- **증거 (수치):** 투자 $500K (YC W23) / MRR 최고 ~$1.5K / 신규 투자 실패
- **교훈:** 개발자는 새 도구를 시도하지만, 정리 비용이 절약 비용과 같으면 남지 않음. 특정 업무에서 확실히 우위가 있어야 함
- **출처 URL:** <https://techstartups.com/2025/12/09/top-ai-startups-that-shut-down-in-2025-what-founders-can-learn/>

---

## 15. InsurStaq.ai — 16개월 만의 폐업

- **이름:** InsurStaq.ai
- **사망/피봇 시기:** 2024년 9월 폐업
- **한 줄 설명:** 인도 기반 보험 산업용 GenAI 스타트업. "InsurGPT" 개발
- **사인:** 불분명한 수익화 경로. 높은 고객 확보 비용. 보험사의 AI 도입 속도가 기대보다 느림
- **증거 (수치):** Faad Network 초기 투자 / 2022년 설립 / 16개월 운영 후 폐업 / "enterprise-ready compliance" 달성 주장에도 스케일 실패
- **교훈:** 규제 산업(보험, 금융)에서 GenAI 수익화는 기술만으로는 부족. 고객의 구매 사이클이 스타트업의 런웨이보다 길면 죽음
- **출처 URL:** <https://www.entrepreneur.com/en-in/news-and-trends/genai-startup-insurstaqai-shuts-shop-in-16-months/479627>

---

## 16. Friend AI Pendant — $1.8M을 도메인에 쓴 스타트업

- **이름:** Friend AI Pendant
- **사망/피봇 시기:** 2025년 출시 후 사실상 실패 (극소량 판매)
- **한 줄 설명:** 22세 창업자 Avi Schiffmann이 만든 목걸이형 AI 동반자 기기. 하루 종일 대화를 듣고 알림 전송
- **사인:** 총 $2.5M 투자 중 $1.8M을 "friend.com" 도메인 구매에 사용. 출시 지연 (2025년 1월 → "여름"). 인터넷 검색 불가, 작업 지원 불가. NYC 지하철 광고 → 즉시 반달리즘
- **증거 (수치):** 투자 $2.5M (Perplexity CEO, Solana 창업자 등) / $1.8M 도메인 비용 / 수천 대 판매에 그침 / 스마트폰보다 기능 제한적 / NYC 지하철 광고에 $1M+
- **교훈:** 도메인에 투자금의 72%를 쓰는 것은 마케팅이 아닌 낭비. AI 하드웨어는 스마트폰이 할 수 없는 것을 해야 생존 가능
- **출처 URL:** <https://medium.com/utopian/why-ai-companions-are-a-fad-not-the-future-803336ff39ef>, <https://nypost.com/2025/10/02/tech/artificial-intelligence-friend-necklace-causes-uproar-ai-wouldnt-care-if-you-lived-or-died/>

---

## 17. Meta Reality Labs — $70B+ 손실 후 AI로 피봇

- **이름:** Meta Reality Labs (메타버스 사업부)
- **사망/피봇 시기:** 2026년 1월 10~15% 감원, AI로 피봇
- **한 줄 설명:** Meta의 메타버스/VR 사업부. Quest 헤드셋, Horizon Worlds 등 개발
- **사인:** 2020년 이후 $70B+ 누적 손실. 소비자 VR 헤드셋 수요 부진. Zuckerberg가 AI 연구에 예산 재배치 지시. "개인 초지능(personal super intelligence)" 목표로 전환
- **증거 (수치):** 15,000명 직원 중 10~15% (~1,500명) 해고 / 2020년 이후 누적 손실 $70B+ / Ray-Ban 스마트안경만 200만대+ 판매 (유일한 성공) / CTO Bosworth가 "올해 가장 중요한 미팅"으로 해고 공지 / NYT, LinkedIn 복수 보도
- **교훈:** $70B을 써도 소비자 수요가 없으면 피봇해야 함. 하드웨어는 소비자가 원해야 성공. 메타버스→AI 전환은 역대 최대 규모의 기업 피봇 사례
- **출처 URL:** <https://www.nytimes.com/2026/01/12/technology/meta-layoffs-reality-labs.html>, <https://programs.com/resources/ai-layoffs/>

---

## 18. 엔코드 (Encode/디코드) — 한국 명품 플랫폼의 몰락

- **이름:** 엔코드 (디코드 플랫폼 운영)
- **사망/피봇 시기:** 2025년 3월 폐업
- **한 줄 설명:** 한국 패션/명품 프리오더 플랫폼. 해외 직구 플랫폼 '나우인파리' 인수 후 공격적 확장
- **사인:** 글로벌 명품 불황 + 플랫폼 경쟁 격화. 영업손실 2022년 57억원 → 2023년 121억원으로 2배 이상 증가. 자금 소진
- **증거 (수치):** 누적 투자 235억원 / 나우인파리 인수 / 영업손실 2023년 ~121억원 / 같은 달 경쟁사 발란도 기업회생절차 신청
- **교훈:** 투자금으로 인수합병 + 인건비/마케팅에만 의존하는 구조는 지속 불가능. 수익성 없는 확장은 시장 악화 시 즉시 붕괴
- **출처 URL:** <https://thevc.kr/discussions/korea_startup_close_2025_q2>

---

## 19. 루이다글로벌 — 한국 AI 에듀테크의 좌절

- **이름:** 루이다글로벌
- **사망/피봇 시기:** 2025년 4월 폐업
- **한 줄 설명:** AI 기반 이빔 스마트마커 개발 에듀테크 기업
- **사인:** 누적 120억원 투자에도 시장 진입 실패. 에듀테크 업계 전반 불황 (AI 교과서 도입 무산 논란)
- **증거 (수치):** 누적 투자 120억원 (일본 에스비아이인베스트먼트, 에스비브이에이(구 소프트뱅크벤처스) 등) / TIPS 선정 기업이었으나 폐업
- **교훈:** 정부 지원+기술 인증도 생존을 보장하지 못함. 한국 스타트업 폐업률 증가 추세 (2022년 101건 → 2023년 125건 → 2024년 191건)
- **출처 URL:** <https://thevc.kr/discussions/korea_startup_close_2025_q2>, <http://ceoinpremium.com/news/view.php?idx=2486>

---

## 20. Locale.ai — 번아웃과 윤리적 폐업

- **이름:** Locale.ai
- **사망/피봇 시기:** 2025년 초 폐업
- **한 줄 설명:** 인도 기반 지리공간 분석 AI. 물류/배달/모빌리티 기업용
- **사인:** 6년간 운영 후 스케일링 한계. 엔터프라이즈 세일즈가 창업자 의존적. 번아웃. 남은 자금을 투자자에 반환하며 책임감 있게 폐업
- **증거 (수치):** 투자 ~$5M / 글로벌 유료 고객 보유 / 6년 운영 / 고객에게 1.5개월 사전 통보 + 마이그레이션 지원 / 투자자 자금 반환
- **교훈:** 모든 셧다운이 폭발은 아님. 스케일 불가능한 비즈니스를 인정하고 윤리적으로 마무리하는 것도 선택지. 창업자의 지속가능성도 비즈니스의 지속가능성만큼 중요
- **출처 URL:** <https://techstartups.com/2025/12/09/top-ai-startups-that-shut-down-in-2025-what-founders-can-learn/>

---

## 매크로 통계 (배경 증거)

### SimpleClosure 2025 보고서
- **Series A 셧다운 2.5배 증가** (전년 대비)
- 폐업 기업 중 다수가 7~10년 된 기업 (핀테크, 인슈어테크, 마켓플레이스 시대 창업)
- AI 폐업이 초기 기업에만 국한되지 않음
- **출처:** <https://simpleclosure.com/blog/posts/state-of-startup-shutdowns-2025/>

### MIT 2025 AI 보고서
- 기업 AI 파일럿 **95% 실패**
- 60%가 AI 도구를 평가했으나, 20%만 파일럿 도달, **5%만 프로덕션**
- 실패 원인: 취약한 워크플로우, 맥락 학습 부재, 일상 업무와의 부정합
- **출처:** <https://mashable.com/article/ai-fails-2025>

### 한국 스타트업 폐업 동향 (THE VC 2025)
- 2025년 상반기 기준 88개 투자유치 기업 폐업 (전년 전체 191건의 절반)
- 폐업 기업의 **92%가 초기 투자(Seed) 기업**
- Seed 투자 후 **69%가 3년 내 폐업**
- TIPS 선정 기업 23개도 폐업
- **출처:** <http://ceoinpremium.com/news/view.php?idx=2486>

### AI 스타트업 실패 패턴 (2025)
- 2025년에 **227개 AI 도구/서비스가 폐업**
- 실패 원인: AI 과대홍보 (42%), 제품-시장 부적합 (42%), 재정/팀 문제 (23%)
- S&P Global: AI 이니셔티브 **42%가 2025년에 중단** (전년 17% 대비 급증)
- **출처:** <https://welaunch.kr/post/welaunch/2025년-스타트업-실패-사례-TOP-10-빛나던-혁신의-이면>

---

*이 문서는 지속적으로 업데이트됩니다.*
