# OpenClaw + Linux (Amazon EC2 등) 설치·운영 가이드

> 조사일: 2026-02-21  
> 출처: docs.openclaw.ai 공식 문서 (Getting Started, Install, Docker, Hetzner, GCP, Fly.io, Ansible, Remote Access, Security, Logging, Health, Configuration)

---

## 1. 시스템 요구사항

| 항목 | 최소 | 권장 |
|------|------|------|
| **Node.js** | 22+ (필수) | 22 LTS |
| **OS** | macOS, Linux, Windows(WSL2) | Ubuntu 22.04/24.04 LTS, Debian 12 |
| **RAM** | 1 GB (OOM 위험) | **2 GB 이상** |
| **CPU** | 1 vCPU | 2 vCPU |
| **디스크** | 10 GB | 20 GB (Docker 이미지 + 로그 포함) |
| **기타** | Docker Engine + Compose v2 (Docker 방식 시) | — |

> **공식 문서 인용**: "512MB is too small. 1GB may work but can OOM under load or with verbose logging. **2GB is recommended.**" (Fly.io 가이드)

---

## 2. 추천 EC2 인스턴스 타입

| 인스턴스 타입 | vCPU | RAM | 네트워크 | 월 비용 (us-east-1, On-Demand) | 비고 |
|--------------|------|-----|---------|-------------------------------|------|
| **t3.small** | 2 | 2 GB | Up to 5 Gbps | ~$15/mo | ✅ **권장 (최소)** |
| **t3.medium** | 2 | 4 GB | Up to 5 Gbps | ~$30/mo | 여유 있는 운영 |
| **t3.micro** | 2 | 1 GB | Up to 5 Gbps | ~$8/mo (Free Tier 대상) | OOM 위험, 테스트용 |
| **t4g.small** (ARM) | 2 | 2 GB | Up to 5 Gbps | ~$12/mo | ARM 비용 절약 (Docker 이미지 ARM 빌드 필요) |

**비교 참고 (타 클라우드)**:
- GCP: e2-small (2 vCPU, 2 GB) ~$12/mo
- Hetzner: CX22 (2 vCPU, 4 GB) ~€4/mo (~$5)
- Fly.io: shared-cpu-2x, 2048MB ~$10-15/mo

**스토리지**: 20 GB gp3 EBS (~$1.60/mo). Docker 이미지가 ~2-4GB 차지.

---

## 3. Linux 배포판 호환성

| 배포판 | 지원 상태 | 비고 |
|--------|----------|------|
| **Ubuntu 22.04/24.04 LTS** | ✅ 공식 지원 + 가이드 존재 | Hetzner/GCP 가이드 모두 Ubuntu/Debian 기반 |
| **Debian 11+ (Bookworm)** | ✅ 공식 지원 | Docker 이미지가 `node:22-bookworm` 기반 |
| **Amazon Linux 2023** | ⚠️ 가능하나 공식 가이드 없음 | Node 22 설치, Docker 설정 수동 필요 |
| **RHEL/CentOS Stream** | ⚠️ 비공식 | 패키지 매핑 필요 |
| **Alpine** | ⚠️ 제한적 | sharp 등 native addon 빌드 이슈 가능 |

> **권장: Ubuntu 22.04 LTS** — 공식 문서가 가장 잘 정비되어 있고, 커뮤니티 지원 최대.

---

## 4. 설치 방식 비교: Bare Metal vs Docker

### 4.1 Bare Metal (직접 설치)

```bash
# 설치 스크립트 (Node 22 자동 감지/설치 포함)
curl -fsSL https://openclaw.ai/install.sh | bash

# 또는 npm으로 직접
npm install -g openclaw@latest
openclaw onboard --install-daemon
```

**장점**:
- 단순한 프로세스 구조
- systemd로 직접 관리 가능
- 디버깅 용이
- 리소스 오버헤드 적음

**단점**:
- 호스트 환경에 직접 의존
- 바이너리/패키지 관리가 직접적

**Ansible 자동화**: `openclaw-ansible` 프로젝트로 원커맨드 배포 가능:
```bash
curl -fsSL https://raw.githubusercontent.com/openclaw/openclaw-ansible/main/install.sh | bash
```
설치되는 것: Tailscale + UFW + Docker(sandbox용) + Node 22 + pnpm + OpenClaw + systemd 서비스

### 4.2 Docker (컨테이너)

```bash
git clone https://github.com/openclaw/openclaw.git
cd openclaw
./docker-setup.sh
```

**장점**:
- 격리된 환경, 재현성 높음
- 바이너리를 이미지에 베이크하여 영속성 보장
- `docker compose up -d` 한 줄로 시작/재시작
- 클린 롤백 가능

**단점**:
- Docker 오버헤드 (~200-300MB 추가 RAM)
- 이미지 빌드 시간 (~2-3분)
- 런타임 패키지 설치 불가 (반드시 Dockerfile에서 빌드타임에 설치)
- uid 1000 퍼미션 매핑 필요

**핵심 주의**: Docker 컨테이너 안에서 런타임에 설치한 바이너리는 재시작 시 소실됨. 반드시 Dockerfile에서 베이크해야 함.

### 4.3 권장

| 상황 | 권장 방식 |
|------|----------|
| 빠른 테스트/개발 | Bare Metal (install script) |
| 프로덕션 VPS 운영 | **Docker** (Hetzner/GCP 가이드 패턴) |
| 팀 배포/자동화 | **Ansible** (bare metal + systemd + sandbox Docker) |
| PaaS 환경 (Fly.io) | Docker (내장) |

---

## 5. AWS EC2 설치 단계 (Docker 방식)

### 5.1 EC2 인스턴스 생성

```bash
# AWS CLI 예시
aws ec2 run-instances \
  --image-id ami-0c7217cdde317cfec \  # Ubuntu 22.04 LTS (us-east-1)
  --instance-type t3.small \
  --key-name my-key \
  --security-group-ids sg-xxxxxxxx \
  --block-device-mappings '[{"DeviceName":"/dev/sda1","Ebs":{"VolumeSize":20,"VolumeType":"gp3"}}]' \
  --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=openclaw-gateway}]'
```

### 5.2 서버 접속 후 Docker 설치

```bash
ssh -i my-key.pem ubuntu@YOUR_EC2_IP

sudo apt-get update
sudo apt-get install -y git curl ca-certificates
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker $USER
# 재접속 필요
exit
ssh -i my-key.pem ubuntu@YOUR_EC2_IP
docker --version
docker compose version
```

### 5.3 OpenClaw 클론 및 디렉토리 준비

```bash
git clone https://github.com/openclaw/openclaw.git
cd openclaw

# 영속 디렉토리 생성
mkdir -p ~/.openclaw/workspace
```

### 5.4 환경 변수 설정

```bash
cat > .env << 'EOF'
OPENCLAW_IMAGE=openclaw:latest
OPENCLAW_GATEWAY_TOKEN=$(openssl rand -hex 32)
OPENCLAW_GATEWAY_BIND=lan
OPENCLAW_GATEWAY_PORT=18789

OPENCLAW_CONFIG_DIR=/home/ubuntu/.openclaw
OPENCLAW_WORKSPACE_DIR=/home/ubuntu/.openclaw/workspace

GOG_KEYRING_PASSWORD=$(openssl rand -hex 32)
XDG_CONFIG_HOME=/home/node/.openclaw
EOF
```

> **주의**: `.env` 파일에 실제 시크릿을 기록하되, 절대 git commit하지 말 것.

### 5.5 Docker Compose 설정

```yaml
# docker-compose.yml
services:
  openclaw-gateway:
    image: ${OPENCLAW_IMAGE}
    build: .
    restart: unless-stopped
    env_file:
      - .env
    environment:
      - HOME=/home/node
      - NODE_ENV=production
      - TERM=xterm-256color
      - OPENCLAW_GATEWAY_BIND=${OPENCLAW_GATEWAY_BIND}
      - OPENCLAW_GATEWAY_PORT=${OPENCLAW_GATEWAY_PORT}
      - OPENCLAW_GATEWAY_TOKEN=${OPENCLAW_GATEWAY_TOKEN}
      - GOG_KEYRING_PASSWORD=${GOG_KEYRING_PASSWORD}
      - XDG_CONFIG_HOME=${XDG_CONFIG_HOME}
    volumes:
      - ${OPENCLAW_CONFIG_DIR}:/home/node/.openclaw
      - ${OPENCLAW_WORKSPACE_DIR}:/home/node/.openclaw/workspace
    ports:
      # loopback만 — SSH 터널로 접근
      - "127.0.0.1:${OPENCLAW_GATEWAY_PORT}:18789"
    command:
      [
        "node", "dist/index.js", "gateway",
        "--bind", "${OPENCLAW_GATEWAY_BIND}",
        "--port", "${OPENCLAW_GATEWAY_PORT}",
        "--allow-unconfigured",
      ]
```

### 5.6 빌드 및 실행

```bash
docker compose build   # ~2-3분
docker compose up -d openclaw-gateway

# 확인
docker compose logs -f openclaw-gateway
# → [gateway] listening on ws://0.0.0.0:18789
```

### 5.7 Control UI 접속 (SSH 터널)

```bash
# 로컬 PC에서
ssh -N -L 18789:127.0.0.1:18789 -i my-key.pem ubuntu@YOUR_EC2_IP
```

브라우저에서 `http://127.0.0.1:18789/` 열기 → Gateway 토큰 입력.

---

## 6. Bare Metal 설치 (Ansible 방식 — 프로덕션 권장)

```bash
# EC2 Ubuntu 22.04에서
curl -fsSL https://raw.githubusercontent.com/openclaw/openclaw-ansible/main/install.sh | bash
```

설치 후:
```bash
sudo -i -u openclaw
openclaw onboard --install-daemon

# 서비스 관리
sudo systemctl status openclaw
sudo systemctl restart openclaw
sudo journalctl -u openclaw -f
```

Ansible이 자동으로 설정하는 것:
- **UFW 방화벽**: SSH(22) + Tailscale(41641/udp)만 개방
- **Tailscale VPN**: Gateway는 VPN 메시를 통해서만 접근
- **Docker**: 에이전트 샌드박스용 (Gateway 자체는 호스트에서 실행)
- **systemd**: 부팅 시 자동 시작 + 보안 하드닝 (NoNewPrivileges, PrivateTmp)
- **전용 사용자**: `openclaw` 사용자로 실행

---

## 7. 보안 설정

### 7.1 EC2 Security Group

| 포트 | 프로토콜 | 소스 | 용도 |
|------|---------|------|------|
| 22 | TCP | My IP | SSH 접속 |
| 41641 | UDP | 0.0.0.0/0 | Tailscale (선택) |

> **18789 포트는 공개하지 않음**. SSH 터널 또는 Tailscale을 통해 접근.

### 7.2 Gateway 보안 설정

```json5
// ~/.openclaw/openclaw.json
{
  gateway: {
    mode: "local",
    bind: "loopback",  // 가장 안전
    auth: {
      mode: "token",
      token: "replace-with-long-random-token"  // openssl rand -hex 32
    },
  },
  tools: {
    profile: "messaging",  // 최소 권한
    deny: ["group:automation", "group:runtime", "group:fs"],
    exec: { security: "deny", ask: "always" },
    elevated: { enabled: false },
  },
}
```

### 7.3 보안 감사

```bash
openclaw security audit          # 기본 감사
openclaw security audit --deep   # Gateway 라이브 프로브 포함
openclaw security audit --fix    # 자동 수정 가능한 항목 수정
```

주요 체크 항목:
- Gateway auth 노출 여부
- 파일 퍼미션 (world-readable/writable 아닌지)
- 브라우저 제어 노출
- 플러그인 허용 범위
- 샌드박스 설정 일관성

### 7.4 퍼미션

```bash
# Docker 볼륨 마운트 시 uid 1000으로 맞춰야 함
sudo chown -R 1000:1000 ~/.openclaw

# Bare metal 시
chmod 700 ~/.openclaw
chmod 600 ~/.openclaw/openclaw.json
```

### 7.5 SSH 하드닝 (기본)

```bash
# /etc/ssh/sshd_config
PasswordAuthentication no
PermitRootLogin no
```

---

## 8. 프로세스 관리

### 8.1 systemd (Bare Metal — 권장)

Ansible 설치 시 자동 생성됨. 수동 생성 시:

```ini
# /etc/systemd/system/openclaw.service
[Unit]
Description=OpenClaw Gateway
After=network.target

[Service]
Type=simple
User=openclaw
WorkingDirectory=/home/openclaw
ExecStart=/usr/bin/openclaw gateway --port 18789
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable openclaw
sudo systemctl start openclaw
```

### 8.2 Docker Compose (컨테이너)

```bash
docker compose up -d        # 시작
docker compose down          # 중지
docker compose restart       # 재시작
docker compose logs -f       # 로그
```

`restart: unless-stopped` 설정으로 서버 재부팅 시 자동 시작.

### 8.3 OpenClaw CLI (데몬 서비스)

```bash
openclaw gateway status      # 상태 확인
openclaw gateway start       # 시작
openclaw gateway stop        # 중지
openclaw gateway restart     # 재시작
```

`openclaw onboard --install-daemon`으로 OS별 서비스 자동 등록.

---

## 9. SSL/도메인 설정

### 9.1 Tailscale Serve (가장 쉬움 — 권장)

```bash
tailscale serve https / http://127.0.0.1:18789
```
- 자동 HTTPS 인증서 (Let's Encrypt via Tailscale)
- VPN 메시 내에서만 접근 가능
- `gateway.auth.allowTailscale: true`로 토큰 없이 인증 가능

### 9.2 Reverse Proxy (Caddy/nginx)

```nginx
# /etc/nginx/sites-available/openclaw
server {
    listen 443 ssl;
    server_name openclaw.example.com;

    ssl_certificate /etc/letsencrypt/live/openclaw.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/openclaw.example.com/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:18789;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header X-Forwarded-For $remote_addr;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

Gateway 설정에 trustedProxies 추가:
```json5
{
  gateway: {
    trustedProxies: ["127.0.0.1"],
    auth: { mode: "token", token: "..." },
  }
}
```

### 9.3 SSH 터널만 사용 (가장 단순)

SSL 불필요. 로컬에서:
```bash
ssh -N -L 18789:127.0.0.1:18789 ubuntu@YOUR_EC2_IP
```
브라우저에서 `http://127.0.0.1:18789/` 접속.

---

## 10. 비용 추정 (AWS EC2 월간)

| 항목 | 사양 | 월 비용 (USD) |
|------|------|--------------|
| EC2 t3.small (On-Demand) | 2 vCPU, 2 GB | ~$15.00 |
| EBS gp3 20GB | 스토리지 | ~$1.60 |
| 데이터 전송 | ~10 GB out | ~$0.90 |
| **합계 (최소)** | | **~$17.50/mo** |

**절약 옵션**:
| 방법 | 예상 비용 |
|------|----------|
| Reserved Instance (1년) | ~$10/mo |
| Spot Instance (개발/테스트) | ~$5/mo (중단 위험) |
| t4g.small (ARM Graviton) | ~$12/mo |
| Savings Plan | ~$10-12/mo |

**타 클라우드 비교**:
| 제공자 | 사양 | 월 비용 |
|--------|------|---------|
| Hetzner CX22 | 2 vCPU, 4 GB | ~$5/mo |
| GCP e2-small | 2 vCPU, 2 GB | ~$12/mo |
| Fly.io shared-cpu-2x | 2x shared, 2 GB | ~$10-15/mo |
| DigitalOcean Basic | 2 vCPU, 2 GB | ~$12/mo |

---

## 11. 모니터링/로그

### 11.1 로그

**파일 로그** (JSON lines):
- 위치: `/tmp/openclaw/openclaw-YYYY-MM-DD.log`
- 날짜별 롤링

**설정**:
```json5
{
  logging: {
    level: "info",          // trace, debug, info, warn, error
    file: "/var/log/openclaw/openclaw.log",  // 커스텀 경로
    consoleLevel: "info",
    consoleStyle: "pretty",  // pretty | compact | json
    redactSensitive: "tools",
  }
}
```

**CLI로 로그 확인**:
```bash
openclaw logs --follow       # 실시간 tail
```

**Docker 로그**:
```bash
docker compose logs -f openclaw-gateway
```

**systemd 로그 (Bare Metal)**:
```bash
sudo journalctl -u openclaw -f
sudo journalctl -u openclaw -n 100
```

### 11.2 Health Check

```bash
openclaw health --json       # Gateway 헬스 스냅샷
openclaw status              # 로컬 요약
openclaw status --deep       # 채널별 프로브 포함
openclaw doctor              # 설정 문제 진단
```

**Docker 헬스 체크**:
```bash
docker compose exec openclaw-gateway node dist/index.js health --token "$OPENCLAW_GATEWAY_TOKEN"
```

### 11.3 CloudWatch (AWS)

```bash
# CloudWatch Agent로 로그 수집
sudo yum install -y amazon-cloudwatch-agent  # Amazon Linux
# /tmp/openclaw/ 디렉토리를 CloudWatch Logs 그룹으로 전송 설정
```

---

## 12. 백업/복원

### 12.1 백업 대상

| 컴포넌트 | 경로 | 중요도 |
|---------|------|--------|
| Gateway 설정 | `~/.openclaw/openclaw.json` | 🔴 필수 |
| 인증 정보 | `~/.openclaw/credentials/` | 🔴 필수 |
| 모델 인증 프로필 | `~/.openclaw/agents/*/agent/auth-profiles.json` | 🔴 필수 |
| 에이전트 워크스페이스 | `~/.openclaw/workspace/` | 🟡 중요 |
| 세션 로그 | `~/.openclaw/agents/*/sessions/*.jsonl` | 🟢 선택 |
| 스킬 설정 | `~/.openclaw/skills/` | 🟡 중요 |

### 12.2 백업 스크립트

```bash
#!/bin/bash
# /opt/openclaw-backup.sh
BACKUP_DIR="/backup/openclaw"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

mkdir -p "$BACKUP_DIR"
tar czf "$BACKUP_DIR/openclaw-$TIMESTAMP.tar.gz" \
  -C /home/ubuntu \
  .openclaw/openclaw.json \
  .openclaw/credentials \
  .openclaw/workspace \
  .openclaw/skills \
  .openclaw/agents

# 7일 이상 된 백업 삭제
find "$BACKUP_DIR" -name "*.tar.gz" -mtime +7 -delete

# S3로 업로드 (선택)
aws s3 cp "$BACKUP_DIR/openclaw-$TIMESTAMP.tar.gz" \
  s3://my-backups/openclaw/
```

cron 등록:
```bash
0 3 * * * /opt/openclaw-backup.sh
```

### 12.3 복원

```bash
# 서비스 중지
sudo systemctl stop openclaw  # 또는 docker compose down

# 백업 복원
tar xzf /backup/openclaw/openclaw-YYYYMMDD_HHMMSS.tar.gz -C /home/ubuntu/

# 퍼미션 복구 (Docker 사용 시)
sudo chown -R 1000:1000 /home/ubuntu/.openclaw

# 서비스 재시작
sudo systemctl start openclaw  # 또는 docker compose up -d
```

---

## 13. 영속성 맵 (Docker 환경)

| 컴포넌트 | 컨테이너 내 경로 | 영속성 방법 | 비고 |
|---------|----------------|------------|------|
| Gateway 설정 | `/home/node/.openclaw/` | 호스트 볼륨 마운트 | openclaw.json, 토큰 포함 |
| 모델 인증 | `/home/node/.openclaw/` | 호스트 볼륨 마운트 | OAuth, API 키 |
| 스킬 설정 | `/home/node/.openclaw/skills/` | 호스트 볼륨 마운트 | 스킬별 상태 |
| 워크스페이스 | `/home/node/.openclaw/workspace/` | 호스트 볼륨 마운트 | 코드, 에이전트 아티팩트 |
| WhatsApp 세션 | `/home/node/.openclaw/` | 호스트 볼륨 마운트 | QR 로그인 보존 |
| 외부 바이너리 | `/usr/local/bin/` | **Docker 이미지** | 빌드 시 베이크 필수 |
| Node 런타임 | 컨테이너 FS | Docker 이미지 | 매 빌드마다 재생성 |
| OS 패키지 | 컨테이너 FS | Docker 이미지 | 런타임 설치 ❌ |

---

## 14. 환경 변수 참조

| 변수 | 설명 | 기본값 |
|------|------|--------|
| `OPENCLAW_HOME` | 홈 디렉토리 (내부 경로 기준) | `~` |
| `OPENCLAW_STATE_DIR` | 상태 디렉토리 오버라이드 | `~/.openclaw` |
| `OPENCLAW_CONFIG_PATH` | 설정 파일 경로 오버라이드 | `~/.openclaw/openclaw.json` |
| `OPENCLAW_GATEWAY_TOKEN` | Gateway 인증 토큰 | — |
| `OPENCLAW_GATEWAY_PORT` | Gateway 포트 | `18789` |
| `OPENCLAW_GATEWAY_BIND` | 바인드 주소 | `loopback` |
| `OPENCLAW_DOCKER_APT_PACKAGES` | Docker 빌드 시 설치할 apt 패키지 | — |
| `OPENCLAW_EXTRA_MOUNTS` | 추가 호스트 바인드 마운트 | — |
| `OPENCLAW_HOME_VOLUME` | `/home/node` 영속 볼륨 이름 | — |

---

## 15. 유용한 명령어 요약

```bash
# 설치
curl -fsSL https://openclaw.ai/install.sh | bash
openclaw onboard --install-daemon

# Gateway 관리
openclaw gateway status
openclaw gateway start
openclaw gateway stop
openclaw gateway restart

# 진단
openclaw doctor
openclaw doctor --fix
openclaw status --deep
openclaw health --json
openclaw security audit --deep

# 채널 설정
openclaw channels login          # WhatsApp QR
openclaw channels add --channel telegram --token "BOT_TOKEN"
openclaw channels add --channel discord --token "BOT_TOKEN"

# 로그
openclaw logs --follow

# 설정
openclaw configure
openclaw config get agents.defaults.workspace
openclaw config set agents.defaults.heartbeat.every "2h"

# 업데이트
openclaw update                 # npm install -g openclaw@latest
```

---

## 16. 관련 공식 문서 링크

| 주제 | URL |
|------|-----|
| Getting Started | https://docs.openclaw.ai/start/getting-started |
| Install | https://docs.openclaw.ai/install |
| Docker | https://docs.openclaw.ai/install/docker |
| Hetzner VPS | https://docs.openclaw.ai/install/hetzner |
| GCP | https://docs.openclaw.ai/install/gcp |
| Fly.io | https://docs.openclaw.ai/install/fly |
| Ansible | https://docs.openclaw.ai/install/ansible |
| Remote Access | https://docs.openclaw.ai/gateway/remote |
| Security | https://docs.openclaw.ai/gateway/security |
| Configuration | https://docs.openclaw.ai/gateway/configuration |
| Configuration Reference | https://docs.openclaw.ai/gateway/configuration-reference |
| Logging | https://docs.openclaw.ai/gateway/logging |
| Health Checks | https://docs.openclaw.ai/gateway/health |
| Sandboxing | https://docs.openclaw.ai/gateway/sandboxing |
| Tailscale | https://docs.openclaw.ai/gateway/tailscale |
| Environment Variables | https://docs.openclaw.ai/help/environment |

---

## 17. EC2 전용 참고 사항

1. **AWS에 대한 공식 전용 가이드는 없음** — Hetzner/GCP 가이드를 EC2에 적용하면 됨 (동일 패턴: Ubuntu + Docker + SSH 터널)
2. **Security Group**: 18789 포트를 외부에 노출하지 말고, SSH 터널 또는 Tailscale 사용
3. **EBS 스냅샷**: 정기적 EBS 스냅샷으로 전체 디스크 백업 가능 (가장 간단한 DR)
4. **IAM Role**: S3 백업 시 EC2에 IAM Role 부여 권장 (액세스 키 대신)
5. **Elastic IP**: 고정 IP 할당 권장 (SSH 접속, Tailscale 안정성)
6. **Amazon Linux 사용 시**: Node 22 직접 설치 필요 (`nvm` 또는 NodeSource)
7. **ARM (t4g)**: Docker 이미지를 ARM으로 빌드하거나 multi-arch 빌드 설정 필요
8. **Terraform**: Hetzner용 커뮤니티 Terraform 모듈 존재 (`openclaw-terraform-hetzner`), AWS용은 동일 패턴으로 작성 가능

---

*이 문서는 docs.openclaw.ai의 공식 문서를 기반으로 조사·정리되었습니다.*
