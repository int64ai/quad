# OpenClaw + Docker + Windows 11 설치 가이드

> 조사일: 2026-02-21  
> 출처: 공식 문서 (docs.openclaw.ai), GitHub 레포 (openclaw/openclaw), Dockerfile, docker-compose.yml

---

## 1. 개요

OpenClaw에서 Docker는 **선택 사항**이다. 두 가지 Docker 활용 방식이 있다:

| 방식 | 설명 |
|------|------|
| **Containerized Gateway** | OpenClaw Gateway 전체를 Docker 컨테이너 안에서 실행 |
| **Agent Sandbox** | Gateway는 호스트에서 실행하되, 에이전트 도구(exec, read, write 등)만 Docker 컨테이너에서 격리 실행 |

Windows 11 사용자에게 공식 문서가 **WSL2에서 실행하는 것을 강력히 권장**한다:
> "On Windows, we strongly recommend running OpenClaw under WSL2."

---

## 2. Windows 11 사전 요구사항

### 2.1 시스템 요구사항
- **Windows 11** (WSL2 지원 필수)
- **WSL2** 활성화 (Microsoft 공식 가이드: `wsl --install`)
- **Docker Desktop for Windows** (WSL2 백엔드 활성화)
  - Docker Desktop 설정에서 "Use the WSL 2 based engine" 켜기
  - Docker Compose v2 포함됨 (Docker Desktop에 내장)
- **Node.js 22+** (WSL2 내부 또는 Docker 이미지 내장)
- 충분한 디스크 공간 (이미지 + 로그용)

### 2.2 WSL2 설정
```powershell
# PowerShell (관리자 권한)
wsl --install
wsl --set-default-version 2
```

### 2.3 WSL2 메모리 제한 (권장)
`%UserProfile%\.wslconfig` 파일 생성/편집:
```ini
[wsl2]
memory=8GB          # 전체 RAM의 절반 정도 권장
swap=4GB
localhostForwarding=true
```
변경 후 WSL 재시작: `wsl --shutdown`

### 2.4 Docker Desktop 설치
1. [Docker Desktop for Windows](https://www.docker.com/products/docker-desktop/) 다운로드
2. 설치 시 "Use WSL 2 instead of Hyper-V" 선택
3. 설치 완료 후 Settings → Resources → WSL Integration → 사용할 WSL 배포판 활성화

---

## 3. 설치 방법

### 3.1 방법 A: WSL2에서 직접 설치 (Docker 없이, 가장 빠름)

Docker 없이 WSL2 내부에서 직접 실행하는 게 가장 빠른 개발 루프:

```bash
# WSL2 터미널에서
curl -fsSL https://openclaw.ai/install.sh | bash
```

이 스크립트가 Node 감지, 설치, 온보딩 위자드까지 자동 처리한다.

### 3.2 방법 B: Docker Compose로 컨테이너화된 Gateway 실행

#### Quick Start (권장)
```bash
# WSL2 터미널에서
git clone https://github.com/openclaw/openclaw.git
cd openclaw
./docker-setup.sh
```

`docker-setup.sh`가 수행하는 작업:
1. Gateway 이미지 빌드
2. 온보딩 위자드 실행
3. 선택적 프로바이더 설정 힌트 출력
4. Docker Compose로 Gateway 시작
5. Gateway 토큰 생성 → `.env`에 기록

#### Manual 방법
```bash
docker build -t openclaw:local -f Dockerfile .
docker compose run --rm openclaw-cli onboard
docker compose up -d openclaw-gateway
```

---

## 4. Docker Compose 설정 상세

### 4.1 docker-compose.yml (실제 파일)

```yaml
services:
  openclaw-gateway:
    image: ${OPENCLAW_IMAGE:-openclaw:local}
    environment:
      HOME: /home/node
      TERM: xterm-256color
      OPENCLAW_GATEWAY_TOKEN: ${OPENCLAW_GATEWAY_TOKEN}
      CLAUDE_AI_SESSION_KEY: ${CLAUDE_AI_SESSION_KEY}
      CLAUDE_WEB_SESSION_KEY: ${CLAUDE_WEB_SESSION_KEY}
      CLAUDE_WEB_COOKIE: ${CLAUDE_WEB_COOKIE}
    volumes:
      - ${OPENCLAW_CONFIG_DIR}:/home/node/.openclaw
      - ${OPENCLAW_WORKSPACE_DIR}:/home/node/.openclaw/workspace
    ports:
      - "${OPENCLAW_GATEWAY_PORT:-18789}:18789"   # Control UI / API
      - "${OPENCLAW_BRIDGE_PORT:-18790}:18790"     # Bridge 포트
    init: true
    restart: unless-stopped
    command:
      [
        "node", "dist/index.js", "gateway",
        "--bind", "${OPENCLAW_GATEWAY_BIND:-lan}",
        "--port", "18789",
      ]

  openclaw-cli:
    image: ${OPENCLAW_IMAGE:-openclaw:local}
    environment:
      HOME: /home/node
      TERM: xterm-256color
      OPENCLAW_GATEWAY_TOKEN: ${OPENCLAW_GATEWAY_TOKEN}
      BROWSER: echo
    volumes:
      - ${OPENCLAW_CONFIG_DIR}:/home/node/.openclaw
      - ${OPENCLAW_WORKSPACE_DIR}:/home/node/.openclaw/workspace
    stdin_open: true
    tty: true
    init: true
    entrypoint: ["node", "dist/index.js"]
```

### 4.2 주요 포트
| 포트 | 용도 | 환경변수 |
|------|------|----------|
| **18789** | Gateway (Control UI, API, WebSocket) | `OPENCLAW_GATEWAY_PORT` |
| **18790** | Bridge | `OPENCLAW_BRIDGE_PORT` |

### 4.3 주요 환경변수
| 변수 | 설명 |
|------|------|
| `OPENCLAW_GATEWAY_TOKEN` | Gateway 인증 토큰 (docker-setup.sh가 자동 생성) |
| `OPENCLAW_IMAGE` | Docker 이미지 이름 (기본: `openclaw:local`) |
| `OPENCLAW_CONFIG_DIR` | 호스트의 설정 디렉토리 (→ 컨테이너 `/home/node/.openclaw`) |
| `OPENCLAW_WORKSPACE_DIR` | 호스트의 워크스페이스 디렉토리 (→ 컨테이너 `/home/node/.openclaw/workspace`) |
| `OPENCLAW_GATEWAY_BIND` | 바인드 모드 (기본: `lan`) |
| `OPENCLAW_DOCKER_APT_PACKAGES` | 빌드 시 추가 apt 패키지 설치 |
| `OPENCLAW_EXTRA_MOUNTS` | 추가 호스트 디렉토리 바인드 마운트 (쉼표 구분) |
| `OPENCLAW_HOME_VOLUME` | `/home/node` 영속화용 Named Volume |

### 4.4 볼륨 매핑
- `${OPENCLAW_CONFIG_DIR}` → `/home/node/.openclaw` (설정)
- `${OPENCLAW_WORKSPACE_DIR}` → `/home/node/.openclaw/workspace` (작업 공간)

호스트에 기록되는 경로:
- `~/.openclaw/`
- `~/.openclaw/workspace`

---

## 5. Dockerfile 상세

```dockerfile
FROM node:22-bookworm

# Bun 설치 (빌드 스크립트용)
RUN curl -fsSL https://bun.sh/install | bash
ENV PATH="/root/.bun/bin:${PATH}"

RUN corepack enable
WORKDIR /app
RUN chown node:node /app

# 선택적 apt 패키지 설치
ARG OPENCLAW_DOCKER_APT_PACKAGES=""
RUN if [ -n "$OPENCLAW_DOCKER_APT_PACKAGES" ]; then ...

# 의존성 설치 (캐시 최적화)
COPY --chown=node:node package.json pnpm-lock.yaml ...
USER node
RUN pnpm install --frozen-lockfile

# 선택적 Chromium + Xvfb 설치 (브라우저 자동화용)
# docker build --build-arg OPENCLAW_INSTALL_BROWSER=1 ...
# ~300MB 추가, 매 컨테이너 시작마다 60-90초 Playwright 설치 생략

USER node
COPY --chown=node:node . .
RUN pnpm build
RUN pnpm ui:build

ENV NODE_ENV=production
USER node  # 보안: non-root 실행

CMD ["node", "openclaw.mjs", "gateway", "--allow-unconfigured"]
```

### 핵심 포인트:
- **베이스 이미지**: `node:22-bookworm`
- **보안**: `node` 사용자(uid 1000)로 실행 (non-root)
- **브라우저 옵션**: `--build-arg OPENCLAW_INSTALL_BROWSER=1`로 Chromium 내장 가능

---

## 6. GUI 브라우저 사용

### 6.1 컨테이너 내 브라우저

기본 Docker 이미지에는 Chromium/Playwright 미포함. 활성화 방법:

**방법 1: 빌드 시 포함 (~300MB 추가)**
```bash
docker build --build-arg OPENCLAW_INSTALL_BROWSER=1 -t openclaw:local -f Dockerfile .
```

**방법 2: 런타임에 설치**
```bash
docker compose run --rm openclaw-cli \
  node /app/node_modules/playwright-core/cli.js install chromium
```

**방법 3: Playwright 브라우저 영속화**
- `PLAYWRIGHT_BROWSERS_PATH=/home/node/.cache/ms-playwright` 환경변수 설정
- `OPENCLAW_HOME_VOLUME`로 `/home/node` 영속화 또는
- `OPENCLAW_EXTRA_MOUNTS`로 해당 경로 마운트

### 6.2 샌드박스 브라우저
에이전트 샌드박싱 활성화 시 별도 브라우저 컨테이너 사용 가능:
```bash
scripts/sandbox-browser-setup.sh
```
- noVNC 옵저버 접근 지원 (비밀번호 보호)
- 전용 Docker 네트워크 (`openclaw-sandbox-browser`)

---

## 7. 흔한 에러와 해결법

### 7.1 권한 에러 (EACCES)
**증상**: `/home/node/.openclaw` 접근 시 permission denied  
**원인**: 컨테이너가 uid 1000 (`node`)으로 실행되는데 호스트 바인드 마운트 소유자가 다름  
**해결**:
```bash
# WSL2에서
sudo chown -R 1000:1000 ~/.openclaw ~/.openclaw/workspace
```

### 7.2 "unauthorized" 또는 "disconnected (1008): pairing required"
**해결**:
```bash
docker compose run --rm openclaw-cli dashboard --no-open
docker compose run --rm openclaw-cli devices list
docker compose run --rm openclaw-cli devices approve <requestId>
```

### 7.3 "refusing to bind gateway ... without auth"
**원인**: loopback 외 바인드 시 인증 미설정  
**해결**: `OPENCLAW_GATEWAY_TOKEN` 환경변수 설정 또는 `gateway.auth.token` 설정

### 7.4 "EADDRINUSE" / 포트 충돌
**원인**: 18789 포트가 이미 사용 중  
**해결**: `.env`에서 `OPENCLAW_GATEWAY_PORT=18791` 등으로 변경

### 7.5 Gateway start blocked: `set gateway.mode=local`
**해결**: config에 `gateway.mode="local"` 설정 또는 `openclaw configure` 실행

### 7.6 Docker Desktop + WSL2 통합 문제
- Docker Desktop Settings → Resources → WSL Integration 확인
- WSL2 배포판이 활성화되어 있는지 확인
- `docker` 명령이 WSL2 안에서 동작하는지 확인: `docker --version`

### 7.7 브라우저 도구 실패
```bash
# 브라우저 상태 확인
docker compose run --rm openclaw-cli browser status
docker compose run --rm openclaw-cli browser start --browser-profile openclaw
```
- `Failed to start Chrome CDP on port` → 브라우저 실행 파일 경로 확인
- 빌드 시 `OPENCLAW_INSTALL_BROWSER=1` 사용했는지 확인

---

## 8. 성능 관련 팁

### 8.1 WSL2 메모리 제한
`%UserProfile%\.wslconfig`:
```ini
[wsl2]
memory=8GB
swap=4GB
processors=4
```
- 호스트 RAM의 50% 이하로 설정 권장
- 변경 후 `wsl --shutdown` 필요

### 8.2 Docker Desktop 리소스
- Docker Desktop → Settings → Resources 에서 CPU/메모리 제한 설정
- WSL2 백엔드 사용 시 `.wslconfig`이 우선

### 8.3 빌드 속도 최적화
- Dockerfile의 의존성 레이어 캐싱 활용 (lockfile 변경 시만 재설치)
- `OPENCLAW_DOCKER_APT_PACKAGES`는 이미지 빌드 시 설치되므로 컨테이너 삭제해도 유지

### 8.4 Named Volume으로 `/home/node` 영속화
```bash
export OPENCLAW_HOME_VOLUME="openclaw_home"
./docker-setup.sh
```
- 브라우저 다운로드, 도구 캐시 등이 컨테이너 재생성 시에도 유지
- `docker volume rm <name>`으로 제거 가능

### 8.5 Extra Mounts 성능
- Windows 경로를 Docker Desktop과 공유 설정 필요
- WSL2 파일시스템 (`/home/...`) 내 경로가 Windows 경로 (`/mnt/c/...`)보다 I/O 성능이 훨씬 좋음

---

## 9. 업데이트 방법

### 9.1 Docker 환경 업데이트
```bash
cd openclaw   # 레포 디렉토리
git pull
docker build -t openclaw:local -f Dockerfile .
docker compose down
docker compose up -d openclaw-gateway
```

또는 `docker-setup.sh` 다시 실행:
```bash
./docker-setup.sh
```

### 9.2 일반 업데이트 (WSL2 직접 설치 시)
```bash
# 인스톨러 스크립트 재실행 (권장)
curl -fsSL https://openclaw.ai/install.sh | bash

# 또는 npm
npm i -g openclaw@latest
openclaw doctor
openclaw gateway restart

# 또는 소스에서
openclaw update
```

### 9.3 롤백
```bash
# 특정 버전으로 고정
npm i -g openclaw@<version>
openclaw doctor
openclaw gateway restart

# 소스에서 날짜별 롤백
git checkout "$(git rev-list -n 1 --before=\"2026-01-01\" origin/main)"
pnpm install && pnpm build
openclaw gateway restart
```

### 9.4 업데이트 채널
```bash
openclaw update --channel beta
openclaw update --channel dev
openclaw update --channel stable
```

---

## 10. 채널 설정 (Docker)

### WhatsApp (QR 코드)
```bash
docker compose run --rm openclaw-cli channels login
```

### Telegram (봇 토큰)
```bash
docker compose run --rm openclaw-cli channels login --channel telegram
```

### Discord
```bash
docker compose run --rm openclaw-cli channels login --channel discord
```

---

## 11. Shell Helpers (ClawDock)

Docker 일상 관리를 편리하게:
```bash
mkdir -p ~/.clawdock && curl -sL https://raw.githubusercontent.com/openclaw/openclaw/main/scripts/shell-helpers/clawdock-helpers.sh -o ~/.clawdock/clawdock-helpers.sh
echo 'source ~/.clawdock/clawdock-helpers.sh' >> ~/.zshrc && source ~/.zshrc
```

사용 가능 명령:
- `clawdock-start` / `clawdock-stop`
- `clawdock-dashboard`
- `clawdock-help`

---

## 12. 보안 참고사항

- 컨테이너는 **non-root** `node` 사용자(uid 1000)로 실행
- Control UI는 **관리 표면** → 공개 노출 금지
- localhost, Tailscale Serve, 또는 SSH 터널 사용 권장
- 에이전트 샌드박싱은 완벽한 보안 경계가 아닌 "blast radius 감소" 용도
- `tools.elevated`는 호스트에서 직접 실행되며 샌드박싱 우회

---

## 13. 유용한 진단 명령

```bash
# 컨테이너 내에서 (docker compose run --rm openclaw-cli ...)
openclaw doctor          # 설정 문제 체크
openclaw status          # Gateway 상태
openclaw gateway status  # 상세 Gateway 상태
openclaw logs --follow   # 실시간 로그
openclaw channels status --probe  # 채널 연결 확인
openclaw dashboard       # Control UI 열기
```

---

## 14. 추가 설치 방법 (참고)

| 방법 | 설명 | 문서 |
|------|------|------|
| Podman | Rootless 컨테이너 | `/install/podman` |
| Nix | 선언적 설치 | `/install/nix` |
| Ansible | 자동 플릿 프로비저닝 | `/install/ansible` |
| Bun | CLI 전용 (Gateway 비권장) | `/install/bun` |

---

## 15. 참고 링크

- 공식 Docker 문서: <https://docs.openclaw.ai/install/docker>
- 설치 개요: <https://docs.openclaw.ai/install>
- 시작하기: <https://docs.openclaw.ai/start/getting-started>
- 샌드박싱: <https://docs.openclaw.ai/gateway/sandboxing>
- 트러블슈팅: <https://docs.openclaw.ai/gateway/troubleshooting>
- 업데이트: <https://docs.openclaw.ai/install/updating>
- 환경변수: <https://docs.openclaw.ai/help/environment>
- GitHub 레포: <https://github.com/openclaw/openclaw>
- Discord: <https://discord.gg/clawd>
