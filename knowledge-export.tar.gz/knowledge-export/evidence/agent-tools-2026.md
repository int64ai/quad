# AI 에이전트/코딩 도구 동향: 2026년 1-2월

> 수집일: 2026-02-20 | 대상 기간: 2026-01-01 ~ 2026-02-20
> 주의: 2025년 사건은 배경 맥락으로만 언급. 모든 핵심 항목은 2026년 1-2월.

---

## 목차
1. [도구별 2026년 1-2월 주요 업데이트](#1-도구별-2026년-1-2월-주요-업데이트)
2. [벤치마크 및 핵심 수치](#2-벤치마크-및-핵심-수치)
3. [에이전트 팀/서브에이전트 개념의 구현](#3-에이전트-팀서브에이전트-개념의-구현)
4. [동시 등장의 구조적 이유](#4-동시-등장의-구조적-이유)
5. [각 도구가 바라보는 지점의 차이](#5-각-도구가-바라보는-지점의-차이)
6. [출처 URL 목록](#6-출처-url-목록)

---

## 1. 도구별 2026년 1-2월 주요 업데이트

### 1.1 Claude Code + Opus 4.6 (Anthropic)

**발표일: 2026-02-05**

- **Claude Opus 4.6 출시**: Anthropic의 최신 플래그십 모델. 1M 토큰 컨텍스트 윈도우(베타), SOTA 수준의 에이전틱 코딩 성능.
- **Agent Teams (에이전트 팀)**: Claude Code에서 여러 세션을 팀으로 조율하는 기능. 실험적(experimental) 상태.
  - 팀 리드 세션이 작업 분배, 팀원(teammate)이 독립적으로 작업 후 직접 소통
  - 서브에이전트와 달리, 팀원 간 **직접 메시징** 가능
  - 공유 태스크 리스트, 셀프 클레임(self-claim), 종속성 관리
  - tmux/iTerm2 split pane 또는 in-process 모드 지원
- **Compaction**: 모델이 자체 컨텍스트를 요약하여 장기 실행 작업 수행
- **Adaptive Thinking**: 맥락에 따라 자동으로 사고 깊이 조절
- **Effort 제어**: 개발자가 지능/속도/비용 균형을 직접 조절
- **Claude in Excel 업그레이드 + Claude in PowerPoint** (리서치 프리뷰)
- **가격**: $5/$25 per M tokens (변경 없음)

**발표일: 2026-02-12**

- **Anthropic Series G 펀딩**: $30B 조달, $380B 포스트머니 밸류에이션
- **연 매출 런레이트 $14B**, 3년 연속 10배 이상 성장

**핵심 인용 (얼리 액세스 파트너들)**:
- Cognition(Devin): "Opus 4.6는 Devin Review에서 버그 탐지율을 높였다"
- Windsurf: "디버깅, 낯선 코드베이스 탐색에서 특히 Opus 4.5 대비 눈에 띄게 개선"
- Lovable: "디자인 품질 향상, 더 자율적"
- Cursor: "몇 달 내 가장 큰 도약. 서브에이전트를 알아서 활용"

**출처**: 
- https://www.anthropic.com/news/claude-opus-4-6
- https://www.anthropic.com/news
- https://code.claude.com/docs/en/agent-teams

---

### 1.2 OpenAI Codex

**2026년 1-2월 직접 발표**: OpenAI 뉴스 페이지에서 2026년 1-2월 특정 Codex 업데이트 확인 불가 (페이지 렌더링 제한).

**간접 확인 (2026-02-04, GitHub Agent HQ 통해)**:
- **Codex가 GitHub Agent HQ에 통합** (퍼블릭 프리뷰). Copilot Pro+ 및 Enterprise 구독자 대상.
- GitHub와 VS Code 내에서 직접 Codex 에이전트 실행 가능
- Claude, Copilot과 함께 같은 태스크에 여러 에이전트를 병렬 실행 가능

**간접 확인 (Terminal-Bench 2.0, 2026-02-06)**:
- **GPT-5.3-Codex** 모델 등장 → Simple Codex 에이전트로 Terminal-Bench 2.0 **1위 (75.1%)** 달성
- 이전 GPT-5.2-Codex 대비 상당한 성능 향상

**배경 (2025년 중 출시)**: Codex는 2025년 5월 리서치 프리뷰로 출시. codex-1 (o3 기반), 클라우드 샌드박스에서 병렬 태스크 수행, AGENTS.md 파일로 안내.

**출처**:
- https://openai.com/index/introducing-codex/
- https://github.blog/news-insights/company-news/pick-your-agent-use-claude-and-codex-on-agent-hq/
- https://www.tbench.ai/leaderboard/terminal-bench/2.0

---

### 1.3 Cursor

Cursor는 2026년 1-2월에 **가장 밀도 높은 업데이트**를 쏟아냈다.

| 날짜 | 발표 | 핵심 내용 |
|------|------|----------|
| Jan 27 | **Secure Codebase Indexing** | 팀원의 기존 인덱스를 재사용하여 대규모 레포에서 첫 쿼리 시간 수시간→수초 |
| Feb 5 | **"Towards Self-Driving Codebases"** | 멀티에이전트 연구 하네스 공개. ~1,000 commits/hour, 10M tool calls/week, 수천 개 에이전트 동시 운용 |
| Feb 6 | **NVIDIA 사례** | 30,000명 개발자 일일 사용, 코드 커밋 3배 증가, 버그율 유지 |
| Feb 9 | **Composer 1.5** | Cursor 자체 코딩 모델. RL을 20배 확장하여 훈련. 자체 요약(self-summarization) 기능으로 컨텍스트 한계 극복. Terminal-Bench 2.0에서 Sonnet 4.5 이상 |
| Feb 11 | **에이전트 사용량 증가** | Auto + Composer 풀 도입, Composer 1.5에 기존 대비 3-6배 사용량 한도 |
| Feb 12 | **Long-Running Agents 확대** | 클라우드 기반 장시간 에이전트. Ultra/Teams/Enterprise 사용자에게 확대. 36시간, 30시간, 25시간 실행 사례 |
| Feb 13 | **Box 사례** | 엔지니어 85% 이상 일일 사용, 로드맵 처리량 30-50% 증가, 마이그레이션 노력 80-90% 감소 |
| Feb 17 | **Cursor Marketplace (Plugins)** | MCP 서버, 스킬, 서브에이전트, 룰, 훅을 번들링하는 플러그인 시스템. Stripe, AWS, Figma, Linear, Amplitude 등 파트너 |
| Feb 17 | **Stripe 사례** | 3,000명 엔지니어에 Cursor 기본 설치, 첫날부터 PR 가능 |
| Feb 18 | **Agent Sandboxing** | macOS(Seatbelt), Linux(Landlock+seccomp), Windows(WSL2) 기반 샌드박싱. 중단 40% 감소 |

**"Self-Driving Codebases" 아키텍처 상세**:
- 최종 설계: **Root Planner → Subplanners → Workers** 재귀적 구조
- Planner: 전체 범위 소유, 코딩 안 함, 태스크 분배만
- Subplanners: 위임받은 좁은 범위의 완전한 소유권
- Workers: 독립적으로 태스크 수행, 다른 플래너/워커와 소통 안 함, 자체 레포 복사본에서 작업
- Handoff: 수행 내용 + 메모/우려/피드백을 포함한 보고서 → 플래너에게 전달
- 피크 시 ~1,000 commits/hour, 인간 개입 없이 1주일 연속 실행

**출처**:
- https://cursor.com/blog/self-driving-codebases
- https://cursor.com/blog/composer-1-5
- https://cursor.com/blog/long-running-agents
- https://cursor.com/blog/agent-sandboxing
- https://cursor.com/blog/marketplace
- https://cursor.com/blog/stripe
- https://cursor.com/blog/nvidia
- https://cursor.com/blog/increased-agent-usage

---

### 1.4 GitHub Copilot / Agent HQ

**발표일: 2026-02-04**

- **Agent HQ 출시**: GitHub와 VS Code 내에서 여러 코딩 에이전트를 실행하는 통합 플랫폼
  - **Claude (Anthropic)**, **Codex (OpenAI)** 퍼블릭 프리뷰로 추가
  - 기존 Copilot 에이전트와 함께 **같은 태스크에 여러 에이전트 병렬 실행** 가능
  - Google, Cognition, xAI 등 추가 파트너 예정
- **에이전트 비교 워크플로**: 같은 문제에 여러 에이전트를 할당하여 접근 방식 비교
  - 아키텍처 가드레일, 로직 프레셔 테스팅, 실용적 구현 등 역할 분담
- **팀 기능**: 에이전트 정책 관리, GitHub Code Quality (퍼블릭 프리뷰), 자동 코드 리뷰, Copilot Metrics Dashboard
- Copilot Pro+ 및 Enterprise 구독자 대상

**배경**: Copilot 코딩 에이전트는 2025년 5월 출시 (이슈 할당 → 백그라운드 실행 → PR 제출). GitHub Actions 기반 실행 환경.

**출처**:
- https://github.blog/news-insights/company-news/pick-your-agent-use-claude-and-codex-on-agent-hq/
- https://github.blog/news-insights/product-news/github-copilot-meet-the-new-coding-agent/

---

### 1.5 Devin (Cognition) + Windsurf

**2026년 1-2월 업데이트**:

| 날짜 | 발표 | 핵심 내용 |
|------|------|----------|
| Jan 7 | **Infosys 파트너십** | Infosys가 전사적으로 Devin 배포 |
| Jan 21 | **Devin Review** | AI 코드 리뷰 도구. "코드 생성이 아닌 코드 리뷰가 병목" 진단. GitHub PR URL에서 github→devinreview 치환으로 즉시 사용 |
| Jan 28 | **Cognizant 파트너십** | Cognizant이 Devin + Windsurf를 엔지니어링 조직 전체에 배포 |
| Jan 28 | **런던 오피스 개설** | Cognition의 유럽 확장 |
| Jan 29 | **Agent Trace** | AI 기여도를 버전 관리에 기록하는 오픈 표준 지원. Cursor, Cloudflare, Vercel, Google Jules, Amp, OpenCode 등과 공동 |
| Feb 10 | **Devin Autofixes Review Comments** | Devin Review의 코멘트를 자동으로 수정하는 피드백 루프. "Write → Catch → Fix → Merge" 사이클 자동화 |

**Windsurf (Cognition 소유)**:
- 2026-02-19: **Gemini 3.1 Pro 지원** 추가
- 배경: Cognition이 2025년 7월 Windsurf 인수. SWE-1.5 모델(Cerebras에서 950 tok/s 서빙), SWE-grep(병렬 컨텍스트 검색) 등

**Devin Review 핵심 철학**:
- "코드 생성이 쉬워지면서, 코드 리뷰가 새로운 병목이 됨"
- Winston Churchill 패러디: "소프트웨어 엔지니어링 역사상 이렇게 많은 코드가 이렇게 많은 사람에 의해 만들어졌지만, 이렇게 적은 사람에게 배포된 적은 없다"
- 지능적 diff 정리, 인라인 AI 채팅, 버그 감지(빨강/노랑/회색 등급)

**Agent Trace 핵심 개념**:
- git이 "코드 라인"을 추적했다면, Agent Trace는 "컨텍스트"를 추적
- 각 변경 사항을 특정 대화/궤적(trajectory)에 연결
- 파일 뷰어에서 AI vs 인간 기여 구분, PR 수준 분석, 관리 대시보드 가능

**출처**:
- https://cognition.ai/blog/closing-the-agent-loop-devin-autofixes-review-comments
- https://cognition.ai/blog/devin-review
- https://cognition.ai/blog/agent-trace
- https://cognition.ai/blog/cognizant-cognition
- https://cognition.ai/blog/infosys-cognition
- https://windsurf.com/blog

---

### 1.6 OpenClaw

OpenClaw은 이 기간 동안 주요 공개 뉴스/발표 확인이 어려움. 이 문서를 작성하는 에이전트 자체가 OpenClaw 위에서 실행 중이며, 다음 특성을 실제 확인:
- **개인 AI 비서 플랫폼**: CLI가 아닌, 디바이스 연동(카메라, 스크린, 위치), 디스코드/메시징 채널 통합, 브라우저 제어 등
- **서브에이전트 시스템**: 메인 에이전트가 서브에이전트를 생성하여 병렬 작업 수행 (본 문서가 그 예시)
- **캔버스**: 시각적 UI 프레젠테이션
- **노드 시스템**: 여러 디바이스(노드)를 페어링하여 원격 제어
- 코딩 도구보다는 **범용 AI 비서/에이전트 오케스트레이터**에 가까움

---

## 2. 벤치마크 및 핵심 수치

### Terminal-Bench 2.0 (2026-02-06 기준, 상위 10)

| 순위 | 에이전트 | 모델 | 날짜 | 정확도 |
|------|---------|------|------|--------|
| 1 | Simple Codex | GPT-5.3-Codex | 2026-02-06 | **75.1%** |
| 2 | CodeBrain-1 | GPT-5.3-Codex | 2026-02-10 | 70.3% |
| 3 | Droid | Claude Opus 4.6 | 2026-02-05 | 69.9% |
| 4 | Mux | GPT-5.3-Codex | 2026-02-09 | 68.5% |
| 5 | Deep Agents | GPT-5.2-Codex | 2026-02-12 | 66.5% |
| 6 | Mux | Claude Opus 4.6 | 2026-02-13 | 66.5% |
| 7 | Droid | GPT-5.2 | 2025-12-24 | 64.9% |
| 8 | Ante | Gemini 3 Pro | 2026-01-06 | 64.7% |
| 9 | Terminus 2 | GPT-5.3-Codex | 2026-02-05 | 64.7% |
| 10 | Junie CLI | Gemini 3 Flash | 2025-12-23 | 64.3% |

주목: 
- **Claude Code (Opus 4.6)** = 58.0% (#24) → 공식 하네스 기준. 서드파티 하네스(Factory Droid)가 69.9%로 더 높음
- **Cursor Composer 1.5**는 Terminal-Bench 2.0에서 Sonnet 4.5 초과 성능 (정확한 수치는 비공개)
- GPT-5.3-Codex가 2026-02-06에 새로 등장하며 리더보드 상위 석권

### Anthropic Opus 4.6 주요 벤치마크:
- **Terminal-Bench 2.0**: SOTA (정확한 수치는 본문에서 "highest score"로만 언급)
- **Humanity's Last Exam**: 전 모델 중 1위
- **GDPval-AA**: GPT-5.2 대비 +144 Elo, Opus 4.5 대비 +190 Elo
- **BrowseComp**: 전 모델 중 1위
- **MRCR v2 (1M, 8-needle)**: 76% (Sonnet 4.5는 18.5%)
- **BigLaw Bench**: 90.2%

### 사업 수치:
- **Anthropic**: 연 매출 런레이트 $14B, 밸류에이션 $380B (2026-02-12)
- **Cognition (Devin)**: $400M+ 조달, $10.2B 밸류에이션 (2025-09 기준)
- **Cursor/NVIDIA**: 30,000명 일일 사용, 코드 커밋 3배
- **Cursor/Stripe**: 3,000명 엔지니어 전원 기본 설치
- **Cursor/Box**: 85%+ 엔지니어 일일 사용, 로드맵 처리량 30-50%↑

---

## 3. 에이전트 팀/서브에이전트 개념의 구현

### 3.1 구현 방식 비교

| 도구 | 접근 방식 | 에이전트 간 통신 | 오케스트레이션 |
|------|----------|----------------|---------------|
| **Claude Code Agent Teams** | 팀 리드 + 팀원 세션 | 직접 메시징 가능 | 공유 태스크 리스트, 셀프 클레임, 종속성 관리 |
| **Claude Code Subagents** | 메인 에이전트 내 스폰 | 결과만 반환 | 메인 에이전트가 모든 작업 관리 |
| **Cursor Self-Driving** | Root Planner → Subplanners → Workers | Handoff 메커니즘 (상향식) | 재귀적 계층. Workers는 서로 모름 |
| **Cursor Long-Running** | 클라우드 에이전트 | 계획 승인 후 실행 | 복수 에이전트 병렬, 계획-실행 분리 |
| **Cursor Plugins** | Subagents, Skills, MCP 서버 번들 | 플러그인 인터페이스를 통해 | 마켓플레이스 기반 확장 |
| **OpenAI Codex** | 독립 클라우드 샌드박스 | 없음 (각 태스크 독립) | 사용자가 여러 태스크를 동시 할당 |
| **GitHub Agent HQ** | 멀티 에이전트 플랫폼 | 없음 (각 에이전트 독립) | 사용자가 같은 이슈에 여러 에이전트 할당 |
| **Devin** | 단일 에이전트 + 리뷰 에이전트 루프 | Autofix 피드백 루프 | Write → Review → Fix → Merge 자동화 |
| **OpenClaw** | 메인 에이전트 → 서브에이전트 스폰 | 완료 시 자동 보고 | 라벨 기반, push-based completion |

### 3.2 핵심 패턴

**2026년 1-2월에 관찰되는 공통 패턴**:

1. **계층적 위임 (Hierarchical Delegation)**
   - Cursor: Planner → Subplanner → Worker
   - Claude Code: Team Lead → Teammates
   - OpenClaw: Main Agent → Subagents
   - 공통점: 상위 에이전트가 계획, 하위 에이전트가 실행

2. **피드백 루프 (Feedback Loop)**
   - Devin: Write → Review → Autofix → Merge
   - Claude Code: Teammates가 결과를 리드에게 보고, 리드가 재계획
   - Cursor: Worker의 Handoff가 Planner에게 메모/우려 포함하여 전달

3. **독립성과 격리 (Independence & Isolation)**
   - Cursor Workers: 서로 모르고, 자체 레포 복사본에서 작업
   - Codex: 각 태스크가 독립 샌드박스
   - Agent HQ: 각 에이전트가 독립적으로 같은 이슈 해결

4. **컨텍스트 관리 (Context Management)**
   - Claude: Compaction (자체 요약), 1M 컨텍스트
   - Cursor Composer 1.5: Self-summarization (RL로 훈련)
   - Agent Trace: 변경 사항에 컨텍스트 영구 연결

---

## 4. 동시 등장의 구조적 이유

이 도구들이 2025년 하반기~2026년 초에 동시에 급격히 발전한 이유는 **구조적**이다:

### 4.1 모델 성능의 임계점 돌파

- **GPT-5 시리즈** (2025년 하반기): o3 → GPT-5 → 5.1 → 5.2 → 5.3-Codex (2026-02)
- **Claude Opus 4.5 → 4.6** (2026-02-05): 장기 에이전틱 작업에서 질적 도약
- **Gemini 3 시리즈**: Pro/Flash 모두 에이전틱 코딩에서 경쟁력
- Terminal-Bench 2.0에서 상위 모델이 60-75% 정확도 → 2025년 초만 해도 상상 못한 수준
- **핵심**: 모델이 "지시를 따르고, 계획하고, 도구를 사용하고, 실수를 인식하고, 장시간 유지"하는 능력이 임계점을 넘음

### 4.2 인프라 비용 하락

- OpenAI: GPT-4 대비 토큰당 비용 95% 하락
- Cerebras 등 추론 전용 하드웨어: SWE-1.5를 950 tok/s로 서빙
- Cursor가 자체 모델(Composer 1.5)을 만든 이유: **지속 가능한 비용**으로 대규모 에이전트 사용량 제공
- 결과: 수천 개의 에이전트를 동시에 실행하는 것이 경제적으로 가능해짐

### 4.3 "코드 생성 → 코드 리뷰" 병목 이동

- Devin의 진단: "코드 생성이 쉬워지면서, 리뷰가 병목"
- Cursor의 관찰: "자동완성에서 에이전트로의 주요 전환"
- 결과: 에이전트가 생성한 코드를 에이전트가 리뷰하는 **에이전트-에이전트 루프** 등장
- Agent Trace 표준: AI 기여도를 추적해야 할 필요성 → 산업 전체의 공동 대응

### 4.4 엔터프라이즈 수요 폭발

- NVIDIA (30,000명), Stripe (3,000명), Box (85%+), Infosys, Cognizant 등 대기업 전사 도입
- 엔터프라이즈가 원하는 것: 보안, 감사, 거버넌스, 팀 수준 관리
- 도구들의 대응: Cursor 샌드박싱, GitHub Agent HQ 정책 관리, Claude Code의 effort 제어

### 4.5 RL(강화학습)의 성숙

- Cursor: "Composer 1.5의 RL 포스트트레이닝 컴퓨트가 프리트레이닝 컴퓨트를 초과"
- Codex: "codex-1은 실제 코딩 태스크에 RL로 훈련"
- Cognition: SWE-1.5, SWE-grep 모두 RL 기반
- **핵심**: RL for coding이 예측 가능하게 스케일링되면서, 에이전틱 코딩에 최적화된 모델 제작이 가능해짐

---

## 5. 각 도구가 바라보는 지점의 차이

### 5.1 포지셔닝 맵

```
                    개인 개발자 ←————————————→ 엔터프라이즈/팀
                         │                           │
    인터랙티브/         Cursor (IDE)          GitHub Agent HQ
    실시간 코딩          Claude Code (CLI)      (플랫폼/거버넌스)
         │                                           │
         │              Windsurf (IDE)                │
         │                                           │
    비동기/             Codex (클라우드)         Devin (클라우드)
    자율 실행            Cursor Long-Running      (자율 엔지니어)
         │                                           │
    범용 AI 비서 ——— OpenClaw (개인비서/오케스트레이터)
```

### 5.2 상세 비교

| 도구 | 인터페이스 | 핵심 철학 | 타겟 시장 | 차별점 |
|------|-----------|----------|----------|--------|
| **Claude Code** | CLI (터미널) | 개발자의 사고 과정에 가장 가까운 도구 | 전문 개발자 | Agent Teams, 1M 컨텍스트, 최강 추론 |
| **Codex (OpenAI)** | 웹 (ChatGPT 사이드바) + CLI | 비동기 태스크 위임, "동료에게 일 맡기기" | 모든 수준의 개발자 | 클라우드 샌드박스, 병렬 태스크, GitHub 통합 |
| **Cursor** | IDE (VS Code 포크) | IDE 안에서 모든 것을 해결 | 전문 개발자 + 팀 | 자체 모델, 멀티에이전트 연구, 마켓플레이스, 샌드박싱 |
| **GitHub Copilot/Agent HQ** | 플랫폼 (GitHub + VS Code) | 멀티 에이전트 오케스트레이션 허브 | 엔터프라이즈 | 기존 워크플로 통합, 여러 에이전트 제공자 지원, 거버넌스 |
| **Devin** | 웹 (독립 인터페이스) | 자율 소프트웨어 엔지니어 | 엔터프라이즈 팀 | 가장 높은 자율성, Review+Autofix 루프, 데이터 분석 확장 |
| **Windsurf** | IDE (VS Code 포크) | Devin 생태계의 인터랙티브 파트 | 개인 개발자 | Cognition 생태계, SWE-1.5 모델, Codemaps |
| **OpenClaw** | 멀티채널 (Discord, 노드, 브라우저 등) | 코딩을 넘어선 범용 AI 비서 | 개인 사용자 | 디바이스 통합, 서브에이전트, 비코딩 태스크 지원 |

### 5.3 각 도구의 "에이전트" 의미

- **Claude Code**: 에이전트 = 터미널에서 파일을 읽고, 쓰고, 명령을 실행하는 코딩 파트너. 팀 = 여러 Claude 세션이 공유 태스크로 협업.
- **Codex**: 에이전트 = 클라우드에서 독립적으로 작업하는 비동기 워커. 결과를 PR로 제출.
- **Cursor**: 에이전트 = IDE 내에서 (또는 클라우드에서) 코드베이스를 자율적으로 수정. "Self-driving codebase" = 수천 에이전트의 자동 조율.
- **GitHub Agent HQ**: 에이전트 = 다양한 제공자의 코딩 봇을 GitHub 이슈/PR에 통합. 에이전트는 교체 가능한 부품.
- **Devin**: 에이전트 = 독립적인 "AI 소프트웨어 엔지니어". 이슈 할당받고, 코드 쓰고, 리뷰하고, 수정하는 전체 루프.
- **OpenClaw**: 에이전트 = 개인 비서. 코딩뿐 아니라 메시지, 브라우징, 디바이스 제어, 스케줄링 등 범용.

---

## 6. 출처 URL 목록

### Anthropic
- https://www.anthropic.com/news/claude-opus-4-6
- https://www.anthropic.com/news
- https://code.claude.com/docs/en/agent-teams

### OpenAI
- https://openai.com/index/introducing-codex/

### Cursor
- https://cursor.com/blog/self-driving-codebases
- https://cursor.com/blog/composer-1-5
- https://cursor.com/blog/long-running-agents
- https://cursor.com/blog/agent-sandboxing
- https://cursor.com/blog/marketplace
- https://cursor.com/blog/stripe
- https://cursor.com/blog/nvidia
- https://cursor.com/blog/increased-agent-usage
- https://cursor.com/blog/secure-codebase-indexing
- https://cursor.com/blog/box

### GitHub
- https://github.blog/news-insights/company-news/pick-your-agent-use-claude-and-codex-on-agent-hq/
- https://github.blog/news-insights/product-news/github-copilot-meet-the-new-coding-agent/

### Cognition (Devin / Windsurf)
- https://cognition.ai/blog/closing-the-agent-loop-devin-autofixes-review-comments
- https://cognition.ai/blog/devin-review
- https://cognition.ai/blog/agent-trace
- https://cognition.ai/blog/cognizant-cognition
- https://cognition.ai/blog/infosys-cognition
- https://cognition.ai/blog/cognition-london
- https://windsurf.com/blog

### 벤치마크
- https://www.tbench.ai/leaderboard/terminal-bench/2.0

---

*이 문서는 2026-02-20 기준 웹 검색 및 공식 블로그/문서를 기반으로 작성되었습니다.*
