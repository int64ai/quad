# OpenClaw 멀티 인스턴스 + 보안 격리 가이드

> 조사일: 2026-02-21  
> 출처: 공식 문서 (docs.openclaw.ai), SECURITY.md, docker-compose.yml, Configuration Reference

---

## 1. 요약 (Executive Summary)

OpenClaw는 **한 서버에서 여러 독립 인스턴스를 운영**할 수 있도록 공식적으로 지원한다. 크게 두 가지 아키텍처가 가능하다:

| 아키텍처 | 격리 수준 | 복잡도 | 추천 시나리오 |
|----------|----------|--------|-------------|
| **A. 멀티 Gateway (--profile / Docker)** | OS-레벨 격리 (프로세스/컨테이너 단위) | 중간 | 상호 불신 관계, 완전 독립 필요 |
| **B. 싱글 Gateway + 멀티 Agent** | 논리적 격리 (workspace/session 단위) | 낮음 | 신뢰 관계, 공유 인프라 활용 |

**공식 입장 (SECURITY.md):**
> "Running one Gateway for multiple mutually untrusted/adversarial operators is **not a recommended setup**."
> "For mixed-trust teams, split trust boundaries with separate gateways (or at minimum separate OS users/hosts)."

→ A, B, C, D가 **상호 불신 관계**라면 반드시 **별도 Gateway** (아키텍처 A) 필요.
→ **신뢰 관계**라면 싱글 Gateway + 멀티 Agent (아키텍처 B)로도 충분.

---

## 2. 핵심 질문 답변

### Q1. 한 서버에서 여러 Gateway를 서로 다른 포트로 돌릴 수 있는가?

**✅ 가능 (공식 지원)**

공식 문서 "Multiple Gateways" 페이지에서 명확히 설명:

```bash
# 프로필 방식 (권장)
openclaw --profile userA setup
openclaw --profile userA gateway --port 18789

openclaw --profile userB setup  
openclaw --profile userB gateway --port 19001

openclaw --profile userC setup
openclaw --profile userC gateway --port 19201

openclaw --profile userD setup
openclaw --profile userD gateway --port 19401
```

**격리 체크리스트 (공식 필수):**
- `OPENCLAW_CONFIG_PATH` — 인스턴스별 설정 파일
- `OPENCLAW_STATE_DIR` — 인스턴스별 세션, 자격증명, 캐시
- `agents.defaults.workspace` — 인스턴스별 workspace 루트
- `gateway.port` — 인스턴스별 고유 포트
- 파생 포트 (browser/canvas)도 겹치지 않아야 함

> **포트 간격:** 기본 포트 사이에 최소 20 포트 간격 권장 (브라우저/CDP 포트 충돌 방지)

### Q2. Workspace/agent 디렉토리를 완전히 분리할 수 있는가?

**✅ 완전 분리 가능**

각 인스턴스(또는 에이전트)별로 독립 경로 지정:

```
# 프로필 사용 시 자동 분리
~/.openclaw-userA/          # STATE_DIR (세션, 자격증명)
~/.openclaw-userA/workspace # 워크스페이스 (AGENTS.md, SOUL.md, memory/)

~/.openclaw-userB/
~/.openclaw-userB/workspace
...
```

또는 수동 env 방식:
```bash
OPENCLAW_CONFIG_PATH=~/.openclaw/userA.json \
OPENCLAW_STATE_DIR=~/.openclaw-userA \
openclaw gateway --port 18789
```

**분리되는 항목:**
- workspace (AGENTS.md, SOUL.md, USER.md, MEMORY.md, memory/*)
- 세션 기록 (`~/.openclaw/agents/<agentId>/sessions/*.jsonl`)
- 자격증명 (`~/.openclaw/credentials/`)
- 인증 프로필 (`~/.openclaw/agents/<agentId>/agent/auth-profiles.json`)
- 스킬 (`workspace/skills/`)

### Q3. Docker Container 단위로 격리 가능한가?

**✅ 가능 (가장 강력한 격리)**

공식 docker-compose.yml을 인스턴스별로 복제:

```yaml
# docker-compose.userA.yml
services:
  openclaw-userA:
    image: openclaw:local
    environment:
      OPENCLAW_GATEWAY_TOKEN: ${TOKEN_A}
    volumes:
      - /data/userA/config:/home/node/.openclaw
      - /data/userA/workspace:/home/node/.openclaw/workspace
    ports:
      - "18789:18789"
      - "18790:18790"
    init: true
    restart: unless-stopped
    command: ["node", "dist/index.js", "gateway", "--bind", "loopback", "--port", "18789"]
```

**Docker 보안 강화 (SECURITY.md 권장):**
```bash
docker run --read-only --cap-drop=ALL \
  -v /data/userA/config:/home/node/.openclaw \
  -v /data/userA/workspace:/home/node/.openclaw/workspace \
  openclaw/openclaw:latest
```

추가로 내부 Sandboxing도 활성화 가능 (이중 격리):
```json5
{
  agents: {
    defaults: {
      sandbox: {
        mode: "all",        // 모든 세션 샌드박스
        scope: "session",   // 세션별 격리
        workspaceAccess: "rw",
        docker: {
          network: "none",       // 네트워크 차단
          readOnlyRoot: true,
          capDrop: ["ALL"],
          memory: "1g",
          pidsLimit: 256
        }
      }
    }
  }
}
```

### Q4. 공용 채널(Discord 서버 등)에 여러 인스턴스가 참여 가능한가?

**✅ 가능 (여러 방법)**

**방법 1: 각 인스턴스가 별도 봇 계정으로 같은 서버 참여**
- 각 유저의 Gateway에 별도 Discord bot token 설정
- 같은 Discord 서버에 모든 봇 초대
- 각 봇이 다른 채널에 반응하도록 설정

```json5
// userA의 설정
{
  channels: {
    discord: {
      token: "BOT_TOKEN_A",
      guilds: {
        "공유서버ID": {
          channels: {
            "공용채널": { allow: true, requireMention: true },
            "A전용채널": { allow: true, requireMention: false }
          }
        }
      }
    }
  }
}
```

**방법 2: 싱글 Gateway + 멀티 Agent + Bindings**
```json5
{
  agents: {
    list: [
      { id: "alex", workspace: "~/.openclaw/workspace-alex" },
      { id: "mia", workspace: "~/.openclaw/workspace-mia" }
    ]
  },
  bindings: [
    { agentId: "alex", match: { channel: "discord", accountId: "alex-bot" } },
    { agentId: "mia", match: { channel: "discord", accountId: "mia-bot" } }
  ]
}
```

**방법 3: 공유 채널에 여러 봇이 mention-gating으로 공존**
- `requireMention: true` 설정으로 각 봇이 @멘션될 때만 반응
- 자연스러운 멀티봇 환경 구현

### Q5. 파일시스템, 환경변수, 인증 토큰이 인스턴스 간 격리되는가?

**조건부 ✅ — 아키텍처에 따라 다름**

| 격리 항목 | 별도 Gateway (프로필) | Docker 컨테이너 | 싱글 GW + 멀티 Agent |
|----------|---------------------|----------------|---------------------|
| 파일시스템 | ✅ 별도 STATE_DIR | ✅ 컨테이너 격리 | ⚠️ 논리적 분리만 (같은 호스트) |
| 환경변수 | ✅ 프로세스별 독립 | ✅ 컨테이너별 독립 | ❌ 같은 프로세스 공유 |
| 인증 토큰 | ✅ 별도 credentials/ | ✅ 볼륨 격리 | ⚠️ agentDir별 분리 |
| Gateway 토큰 | ✅ 인스턴스별 고유 | ✅ 인스턴스별 고유 | N/A (단일 토큰) |
| 세션 기록 | ✅ 완전 분리 | ✅ 완전 분리 | ✅ agentId별 분리 |
| 설정 파일 | ✅ 별도 config | ✅ 별도 볼륨 | ❌ 하나의 openclaw.json |

**중요 보안 참고 (공식 문서):**
> "Any process/user with filesystem access can read session logs. Treat disk access as the trust boundary."

→ Docker 없이 같은 OS 유저로 여러 프로필을 돌리면, 한 프로세스가 다른 프로필의 STATE_DIR에 접근 가능. **별도 OS 유저 또는 Docker 필수.**

### Q6. 한 인스턴스가 다른 인스턴스의 데이터에 접근할 수 있는 경로가 있는가?

**⚠️ 아키텍처에 따라 위험 존재**

| 경로 | 별도 Gateway (같은 OS 유저) | Docker 컨테이너 | 별도 OS 유저 |
|------|---------------------------|----------------|-------------|
| 절대 경로로 파일 읽기 | ❌ 가능 (위험!) | ✅ 차단 | ✅ 차단 |
| exec로 다른 디렉토리 접근 | ❌ 가능 (위험!) | ✅ 차단 | ✅ 차단 |
| 환경변수 스니핑 | ❌ /proc 접근 가능 | ✅ 차단 | ✅ 차단 |
| 네트워크 API 접근 | ⚠️ loopback이면 가능 | ⚠️ 설정 필요 | ⚠️ 설정 필요 |

**공식 문서의 경고:**
> "The workspace is the default cwd, not a hard sandbox. Tools resolve relative paths against the workspace, but absolute paths can still reach elsewhere on the host unless sandboxing is enabled."

**완화 방법:**
1. `tools.fs.workspaceOnly: true` → 파일 작업을 workspace로 제한
2. `tools.exec.applyPatch.workspaceOnly: true` → 패치를 workspace로 제한
3. `sandbox.mode: "all"` → 모든 도구를 Docker 내에서 실행
4. Docker 컨테이너 사용 → 물리적 격리
5. 별도 OS 유저 → 파일시스템 권한으로 격리

---

## 3. 추천 아키텍처: A, B, C, D 시나리오

### 🏆 추천: Docker 기반 완전 격리 + 공유 채널

```
┌─────────────────────── 서버 (호스트) ──────────────────────┐
│                                                              │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐       │
│  │ Container│ │ Container│ │ Container│ │ Container│       │
│  │  User A  │ │  User B  │ │  User C  │ │  User D  │       │
│  │          │ │          │ │          │ │          │       │
│  │ Port:    │ │ Port:    │ │ Port:    │ │ Port:    │       │
│  │  18789   │ │  19001   │ │  19201   │ │  19401   │       │
│  │          │ │          │ │          │ │          │       │
│  │ Vol:     │ │ Vol:     │ │ Vol:     │ │ Vol:     │       │
│  │ /data/A  │ │ /data/B  │ │ /data/C  │ │ /data/D  │       │
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘       │
│       │             │             │             │             │
│       └─────────────┴──────┬──────┴─────────────┘             │
│                            │                                  │
│                    Discord Server                             │
│              (공유 채널 + 개인 채널)                          │
│                                                              │
│  ┌────────────────────────────────────────┐                  │
│  │       공유 볼륨 (read-only)            │                  │
│  │  /shared/knowledge-base/ (ro mount)    │                  │
│  └────────────────────────────────────────┘                  │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

### 구현: docker-compose.multi.yml

```yaml
version: "3.8"

# 공유 볼륨 (공용 knowledge base)
volumes:
  shared-knowledge:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: /srv/openclaw-shared/knowledge

services:
  # ===== User A =====
  openclaw-userA:
    image: openclaw/openclaw:latest
    container_name: openclaw-userA
    environment:
      HOME: /home/node
      OPENCLAW_GATEWAY_TOKEN: ${TOKEN_A}
    volumes:
      - /data/userA/config:/home/node/.openclaw
      - /data/userA/workspace:/home/node/.openclaw/workspace
      - shared-knowledge:/home/node/.openclaw/workspace/shared-knowledge:ro
    ports:
      - "18789:18789"
    init: true
    restart: unless-stopped
    read_only: true
    cap_drop:
      - ALL
    tmpfs:
      - /tmp
      - /run
    command: ["node", "dist/index.js", "gateway", "--bind", "loopback", "--port", "18789"]

  # ===== User B =====
  openclaw-userB:
    image: openclaw/openclaw:latest
    container_name: openclaw-userB
    environment:
      HOME: /home/node
      OPENCLAW_GATEWAY_TOKEN: ${TOKEN_B}
    volumes:
      - /data/userB/config:/home/node/.openclaw
      - /data/userB/workspace:/home/node/.openclaw/workspace
      - shared-knowledge:/home/node/.openclaw/workspace/shared-knowledge:ro
    ports:
      - "19001:18789"
    init: true
    restart: unless-stopped
    read_only: true
    cap_drop:
      - ALL
    tmpfs:
      - /tmp
      - /run
    command: ["node", "dist/index.js", "gateway", "--bind", "loopback", "--port", "18789"]

  # ===== User C =====
  openclaw-userC:
    image: openclaw/openclaw:latest
    container_name: openclaw-userC
    environment:
      HOME: /home/node
      OPENCLAW_GATEWAY_TOKEN: ${TOKEN_C}
    volumes:
      - /data/userC/config:/home/node/.openclaw
      - /data/userC/workspace:/home/node/.openclaw/workspace
      - shared-knowledge:/home/node/.openclaw/workspace/shared-knowledge:ro
    ports:
      - "19201:18789"
    init: true
    restart: unless-stopped
    read_only: true
    cap_drop:
      - ALL
    tmpfs:
      - /tmp
      - /run
    command: ["node", "dist/index.js", "gateway", "--bind", "loopback", "--port", "18789"]

  # ===== User D =====
  openclaw-userD:
    image: openclaw/openclaw:latest
    container_name: openclaw-userD
    environment:
      HOME: /home/node
      OPENCLAW_GATEWAY_TOKEN: ${TOKEN_D}
    volumes:
      - /data/userD/config:/home/node/.openclaw
      - /data/userD/workspace:/home/node/.openclaw/workspace
      - shared-knowledge:/home/node/.openclaw/workspace/shared-knowledge:ro
    ports:
      - "19401:18789"
    init: true
    restart: unless-stopped
    read_only: true
    cap_drop:
      - ALL
    tmpfs:
      - /tmp
      - /run
    command: ["node", "dist/index.js", "gateway", "--bind", "loopback", "--port", "18789"]
```

### 각 유저의 보안 강화 설정 (openclaw.json 템플릿)

```json5
{
  gateway: {
    mode: "local",
    bind: "loopback",
    auth: { mode: "token", token: "REPLACE_WITH_LONG_RANDOM_TOKEN" }
  },
  agents: {
    defaults: {
      workspace: "~/.openclaw/workspace",
      sandbox: {
        mode: "all",
        scope: "session",
        workspaceAccess: "rw",
        docker: {
          network: "none",
          readOnlyRoot: true,
          capDrop: ["ALL"],
          memory: "1g",
          pidsLimit: 256
        }
      }
    }
  },
  tools: {
    fs: { workspaceOnly: true },
    exec: {
      security: "allowlist",
      applyPatch: { workspaceOnly: true }
    },
    elevated: { enabled: false }
  },
  session: {
    dmScope: "per-channel-peer"
  }
}
```

### 공유 공간 구현 방법

#### 방법 1: 공유 볼륨 (Read-Only Knowledge Base)
```bash
# 호스트에 공유 디렉토리 생성
mkdir -p /srv/openclaw-shared/knowledge
# 공용 문서 넣기
cp -r shared-docs/* /srv/openclaw-shared/knowledge/

# docker-compose에서 ro로 마운트 (위 예시 참조)
# 각 에이전트는 /workspace/shared-knowledge/ 에서 읽기만 가능
```

#### 방법 2: 공유 Discord 채널
```json5
// 모든 유저의 봇이 같은 Discord 서버의 같은 채널에 참여
// 각 봇은 @멘션될 때만 반응
{
  channels: {
    discord: {
      guilds: {
        "공유서버ID": {
          channels: {
            "공용토론": { allow: true, requireMention: true }
          }
        }
      }
    }
  }
}
```

#### 방법 3: 공유 쓰기 공간 (주의 필요)
```yaml
# 쓰기 가능한 공유 볼륨 (dropbox 스타일)
volumes:
  shared-dropbox:
    driver: local

# 각 컨테이너에 마운트
volumes:
  - shared-dropbox:/home/node/.openclaw/workspace/shared-dropbox:rw
```
> ⚠️ 공유 rw 볼륨은 한 에이전트가 악성 파일을 넣을 수 있으므로, 신뢰 관계에서만 사용

---

## 4. 보안 체크리스트

### 필수 (CRITICAL)

- [ ] 인스턴스별 **별도 Docker 컨테이너** 사용
- [ ] `~/.openclaw/` 디렉토리 권한: 소유자만 읽기/쓰기 (`chmod 700`)
- [ ] `openclaw.json` 권한: 소유자만 읽기 (`chmod 600`)
- [ ] Gateway 인증: `auth.mode: "token"` + 강력한 토큰
- [ ] Gateway bind: `"loopback"` (외부 노출 금지)
- [ ] `tools.elevated.enabled: false` (호스트 탈출 차단)
- [ ] `tools.fs.workspaceOnly: true` (파일 접근 제한)

### 권장 (RECOMMENDED)

- [ ] `sandbox.mode: "all"` (모든 도구를 Docker 내 실행)
- [ ] `tools.exec.security: "allowlist"` (실행 명령 제한)
- [ ] `docker.network: "none"` (불필요한 네트워크 차단)
- [ ] `readOnlyRoot: true` + tmpfs (컨테이너 파일시스템 보호)
- [ ] `cap_drop: ALL` (리눅스 capability 제거)
- [ ] `session.dmScope: "per-channel-peer"` (DM 세션 격리)
- [ ] 정기적 `openclaw security audit --deep` 실행

### 공유 공간 보안

- [ ] 공유 knowledge base는 **read-only** 마운트
- [ ] 공유 쓰기 공간 사용 시 **별도 격리 볼륨** + 정기 스캔
- [ ] Discord 공용 채널: `requireMention: true`로 봇 남용 방지
- [ ] 공용 채널에서 tool 접근 제한: `tools.profile: "messaging"`

---

## 5. 아키텍처 비교표

| 항목 | Docker 멀티 컨테이너 | 프로필 (--profile) | 싱글 GW + 멀티 Agent |
|------|---------------------|-------------------|---------------------|
| **격리 수준** | 🟢 OS + 컨테이너 | 🟡 프로세스 | 🔴 논리적 |
| **설정 복잡도** | 중간 | 낮음 | 낮음 |
| **리소스 사용** | 높음 (컨테이너×N) | 중간 (프로세스×N) | 낮음 (단일 프로세스) |
| **상호 불신 적합** | ✅ | ⚠️ (별도 OS유저 필요) | ❌ |
| **공유 채널** | ✅ 별도 봇 | ✅ 별도 봇 | ✅ 바인딩 |
| **관리 편의** | docker-compose | openclaw CLI | 단일 config |
| **장애 격리** | ✅ 독립 | ✅ 독립 | ❌ GW 장애 = 전체 중단 |
| **공식 권장** | ✅ (불신 관계) | ✅ (불신 관계) | ⚠️ (신뢰 관계만) |

---

## 6. 초기 셋업 절차

### Docker 기반 (A, B, C, D 4인)

```bash
# 1. 디렉토리 구조 생성
for user in A B C D; do
  mkdir -p /data/user${user}/{config,workspace}
  chmod 700 /data/user${user}
done

# 공유 knowledge base
mkdir -p /srv/openclaw-shared/knowledge
chmod 755 /srv/openclaw-shared/knowledge

# 2. 각 유저별 온보딩 (초기 설정)
for user in A B C D; do
  docker run --rm -it \
    -v /data/user${user}/config:/home/node/.openclaw \
    -v /data/user${user}/workspace:/home/node/.openclaw/workspace \
    openclaw/openclaw:latest \
    node dist/index.js onboard
done

# 3. 토큰 생성
for user in A B C D; do
  echo "TOKEN_${user}=$(openssl rand -hex 32)"
done > .env

# 4. docker-compose 실행
docker compose -f docker-compose.multi.yml up -d

# 5. 각 인스턴스 보안 감사
for port in 18789 19001 19201 19401; do
  echo "=== Port $port ==="
  curl -s http://127.0.0.1:$port/health
done
```

### 프로필 기반 (Docker 없이)

```bash
# 별도 OS 유저 생성 (보안 강화)
for user in ocA ocB ocC ocD; do
  sudo useradd -m -s /bin/bash $user
done

# 각 유저로 전환하여 셋업
sudo -u ocA bash -c '
  openclaw --profile userA onboard
  openclaw --profile userA gateway install
'
# ... 반복

# 각 프로필의 서비스 시작
sudo -u ocA openclaw --profile userA gateway --port 18789 &
sudo -u ocB openclaw --profile userB gateway --port 19001 &
sudo -u ocC openclaw --profile userC gateway --port 19201 &
sudo -u ocD openclaw --profile userD gateway --port 19401 &
```

---

## 7. 알려진 제한사항 및 주의점

1. **싱글 Gateway + 멀티 Agent는 보안 경계가 아님**
   - 같은 프로세스 메모리 공간 공유
   - `openclaw.json`을 수정할 수 있는 사람 = 사실상 관리자
   - 상호 불신 관계에서는 사용 금지

2. **프로필 방식도 같은 OS 유저면 격리 불완전**
   - 한 프로필의 프로세스가 다른 프로필의 STATE_DIR에 접근 가능
   - 별도 OS 유저 + 파일 권한 설정 필수

3. **에이전트의 절대 경로 접근**
   - `tools.fs.workspaceOnly: true` 미설정 시, 에이전트가 다른 경로 읽기 가능
   - Sandbox 미사용 시, exec로 임의 명령 실행 가능

4. **플러그인 신뢰 경계**
   - 플러그인은 Gateway와 같은 권한으로 실행됨
   - 신뢰할 수 없는 플러그인은 설치 금지

5. **공유 채널의 프롬프트 인젝션 위험**
   - 공유 채널에서 악의적 사용자가 다른 봇에 프롬프트 인젝션 시도 가능
   - `requireMention: true` + 제한된 tool 프로필 사용 권장

6. **리소스 경쟁**
   - Docker 컨테이너별 리소스 제한 설정 권장 (`memory`, `cpus`, `pidsLimit`)
   - 한 인스턴스의 과도한 사용이 다른 인스턴스에 영향 주지 않도록

---

## 8. 출처

| 문서 | URL |
|------|-----|
| Multiple Gateways | https://docs.openclaw.ai/gateway/multiple-gateways.md |
| Security | https://docs.openclaw.ai/gateway/security/index.md |
| SECURITY.md | https://github.com/openclaw/openclaw/blob/main/SECURITY.md |
| Sandboxing | https://docs.openclaw.ai/gateway/sandboxing.md |
| Docker Install | https://docs.openclaw.ai/install/docker.md |
| Multi-Agent Routing | https://docs.openclaw.ai/concepts/multi-agent.md |
| Agent Workspace | https://docs.openclaw.ai/concepts/agent-workspace.md |
| Configuration Reference | https://docs.openclaw.ai/gateway/configuration-reference.md |
| Sandbox vs Tool Policy | https://docs.openclaw.ai/gateway/sandbox-vs-tool-policy-vs-elevated.md |
| docker-compose.yml | https://github.com/openclaw/openclaw/blob/main/docker-compose.yml |
