# OpenClaw 사용 팁 — 2026년 유튜브/블로그 조사

> 조사일: 2026-02-22
> 범위: 2026년 1~2월 유튜브 영상, 블로그, Reddit

---

## 📺 주요 유튜브 영상 목록

### 1. "OpenClaw Full Tutorial for Beginners" — freeCodeCamp.org
- **URL:** https://www.youtube.com/watch?v=n1sfrc-RjyM
- **저자:** Kian (freeCodeCamp)
- **날짜:** 2026-02-04
- **조회수:** 259,401
- **핵심 팁:**
  1. Docker 기반 샌드박싱으로 호스트 시스템 보호하며 에이전트 실행
  2. WhatsApp/Telegram/Discord 등 멀티채널 동시 연결 가능
  3. 영속적 장기 메모리 관리가 핵심 — memory 파일 구조화
  4. Skills를 통한 에이전트 기능 확장 (설치는 Markdown 파일 기반)
  5. 보안 경고: 스킬 설치 시 신뢰할 수 있는 소스만 사용할 것
- **인사이트:** 종합 입문 강좌. Local 설치 → 모델 연결 → 메모리 → 스킬 순서의 체계적 학습 경로 제공

### 2. "100 hours of OpenClaw lessons in 35 minutes" — Alex Finn
- **URL:** https://www.youtube.com/watch?v=_kZCoW-Qxnc
- **저자:** Alex Finn
- **날짜:** 2026-02-15
- **조회수:** 137,652
- **핵심 팁:**
  1. **Morning Brief 설정**: 매일 아침 8시 크론잡으로 날씨/뉴스/할 일/목표 관련 작업 보고
  2. **Mission Control**: NextJS로 로컬 대시보드를 만들어 생산성 도구 통합
  3. **Brains vs Muscles 개념**: 작업 종류에 따라 다른 모델 사용 (비싼 모델=두뇌, 저렴한 모델=근육)
  4. **보안 주의**: VPS 사용 권장, 개인 컴퓨터 직접 실행 위험
  5. **마인드셋**: 에이전트를 "직원"처럼 대하고, 명확한 지시와 피드백 제공
- **추천 프롬프트:**
  ```
  Please schedule a morning brief for me every day at 8am. Send it to my Telegram. In this morning brief I want:
  1. The weather in San Francisco
  2. Top news stories in AI
  3. Any tasks I have in my todo list on Things 3
  4. Tasks you can complete for me today that bring me closer to my goals
  ```
- **인사이트:** 100시간 실사용 경험에서 나온 실전 팁. "OpenClaw mindset" 섹션이 특히 유용

### 3. "Ultimate Clawdbot Tutorial" — AI Master
- **URL:** https://www.youtube.com/watch?v=NA8C8jIQNeM
- **저자:** AI Master
- **날짜:** 2026-02-09
- **조회수:** 105,402
- **핵심 팁:**
  1. 3가지 핵심 기능: 컴퓨터 전체 제어, 무한 메모리, 인간처럼 모든 것 수행
  2. 하드웨어 요구사항 및 옵션 비교 (Mac Mini vs VPS)
  3. 비용 분석 및 AI 모델 선택 가이드
  4. 6가지 실용적 사용 사례
  5. 고급 기능 활용법 (Unlock Advanced Features)
- **인사이트:** 흔한 미신(myth) 깨기 섹션 포함 — 초보자 오해 해소에 좋음

### 4. "Master OpenClaw/Clawdbot in 35 minutes" — Keith AI
- **URL:** https://www.youtube.com/watch?v=4evf5YqVzOM
- **저자:** Keith AI
- **날짜:** 2026-01-30
- **조회수:** 84,851
- **핵심 팁:** 종합적 35분 마스터 가이드 — 설정부터 실전 활용까지

### 5. "OpenClaw Full Course: Setup, Skills, Voice, Memory & More" — Tech With Tim
- **URL:** https://www.youtube.com/watch?v=vte-fDoZczE
- **저자:** Tech With Tim
- **날짜:** 2026년 2월 (추정)
- **핵심 팁:**
  1. **모델 설정 & 비용 절약**: 11:06 — 모델별 비용 최적화 전략
  2. **음성 통합**: 20:10 — Voice & Speech-to-Text 설정
  3. **스킬 이해**: 26:30 — 스킬 시스템 동작 원리와 코딩 스킬 활성화
  4. **중요 마크다운 파일**: 38:17 — IDENTITY, USER, SOUL.md, HEARTBEAT.md 역할 설명
  5. **크론잡**: 44:28 — 자동화 스케줄링 설정
- **타임스탬프 구조:**
  - 00:00 | Overview
  - 00:27 | Security Warning
  - 03:07 | VPS Setup
  - 06:00 | Understanding Docker
  - 06:50 | Accessing the Gateway
  - 07:34 | LLM Limits
  - 09:00 | SSHing Into the Server
  - 11:06 | Model Configuration & Cost Saving
  - 18:00 | Telegram Configuration
  - 20:10 | Adding Voice & Speech-to-Text
  - 23:07 | Telegram Groups & Channels
  - 26:30 | Understanding Skills
  - 28:15 | Viewing Skills and Markdown Files
  - 31:45 | Enabling Coding Skills
  - 34:20 | Memory & Preferences
  - 38:17 | Important Markdown Files (IDENTITY, USER, etc.)
  - 40:28 | SOUL.md
  - 41:24 | HEARTBEAT.md
  - 44:28 | Cronjobs

### 6. "OpenClaw Full Course | Set Up and Deploy Your Own AI Agent" — JavaScript Mastery
- **URL:** https://www.youtube.com/watch?v=sO6NSSOWDO0
- **저자:** JavaScript Mastery
- **날짜:** 2026-02-20
- **조회수:** 32,519
- **핵심 팁:**
  1. VPS 원클릭 배포 + AI 모델 설정
  2. Telegram 연결 방법
  3. 시스템 프롬프트 설정의 중요성
  4. 5가지 개발자용 실전 사용 사례
  5. "24/7 AI 직원" 개념으로 코드 배포, 이메일 관리, 워크플로우 자동화
- **인사이트:** 개발자 관점의 실전 배포 가이드

### 7. "OpenClaw Use Cases that are actually helpful" — Dubibubii
- **URL:** https://www.youtube.com/watch?v=HNtHZkHGEFo
- **저자:** Dubibubii
- **날짜:** 2026-02-21
- **조회수:** 13,232
- **핵심 팁:**
  1. **$1,000+ 실험 경험**: 수백 시간 실전 테스트에서 나온 인프라 구성
  2. **콘텐츠 파이프라인**: 자동화된 콘텐츠 생산으로 1주 300,000+ 조회수 달성
  3. **바이럴 마케팅 에이전트**: TikTok 콘텐츠 자동 생산 + 반복 수익 창출
  4. **앱 빌더 에이전트**: 자율적 앱 개발 워크플로우
  5. **오케스트레이터 패턴**: 에이전트 팀을 조율하는 구조화된 시스템
- **분류:** 📋 Second Brain / Custom Report / Content Factory / Business Factory / Smart Task Tracker / Mission Control
- **인사이트:** "대부분 사람들이 OpenClaw를 챗봇처럼 쓰고 있다" — 진정한 가치는 24/7 자율 팀 운영

### 8. "Install OpenClaw in 10 Minutes (Feb 2026)" — (채널명 미확인)
- **URL:** https://www.youtube.com/watch?v=Q9wdf2zG_wo (추정)
- **날짜:** 2026년 2월
- **핵심 팁:**
  1. VPS 선택법 (Hostinger 추천)
  2. Docker Manager 설정
  3. Gateway Token 반드시 저장
  4. Anthropic API Key 설정
  5. Telegram 올바르게 연결하기 + 페어링 코드 문제 해결
  6. Claude 4.5 Sonnet 이슈 주의
  7. Terminal Commands & Doctor Mode

### 9. "How to create multiple Agents in Clawdbot" — Alessandro Colford
- **URL:** https://www.youtube.com/watch?v=EMBNyWVsEXc
- **저자:** Alessandro Colford
- **날짜:** 2026-02-20
- **조회수:** 1,317
- **핵심 팁:**
  1. `openclaw agents add [NAME]` 명령어로 멀티 에이전트 생성
  2. `openclaw configure` 로 에이전트별 설정
  3. 전문화된 에이전트 팀 구축 방법
- **인사이트:** 멀티에이전트 설정의 실전 가이드

### 10. "OpenClaw Creator: Why 80% Of Apps Will Disappear" — Y Combinator
- **URL:** https://www.youtube.com/watch?v=4uzGDAoNOZc
- **저자:** Y Combinator (Raphael Schaad × Peter Steinberger)
- **날짜:** 2026-02-07
- **조회수:** 664,295
- **핵심 팁:**
  1. 창작자 Peter Steinberger의 "아하 모먼트": 대화 기반으로 에이전트를 재구축
  2. "God AI" → Swarm Intelligence 방향 전환
  3. 메모리/데이터 사일로/소유권 문제 해결
  4. 에이전트에 개성(personality) 부여하기
  5. 로컬 퍼스트 에이전트가 기존 앱의 80%를 대체할 것
- **인사이트:** OpenClaw 비전의 근본 이해에 필수. 봇 간 대화(Moltbook)와 미래 방향

### 11. "OpenClaw Explained: Everything You Need to Know + Easy Cloudflare Setup" — Automate with Marc
- **URL:** https://www.youtube.com/watch?v=6mL-BSarP4c
- **저자:** Automate with Marc
- **날짜:** 2026-02-04
- **조회수:** 10,753
- **핵심 팁:**
  1. **Cloudflare Workers 배포**: VPS 대신 Cloudflare 샌드박스에서 안전하게 실행
  2. 보안/권한/접근 제어 설정
  3. VPS vs Cloudflare Workers 비교
- **인사이트:** 보안 최우선 사용자를 위한 대안 배포 방식

### 12. "CLAUDE.md and Agents.md Explained" — (채널명 미확인)
- **URL:** https://www.youtube.com/watch?v=HNtHZkHGEFo (별도 영상)
- **핵심 팁:**
  1. 영속적 컨텍스트가 중요한 이유
  2. 모든 컨텍스트 파일에 필요한 6가지 핵심 섹션
  3. 학습 내용 캡처 및 규칙 업데이트 방법
  4. 서브에이전트 전략적 활용
  5. 컨텍스트 파일 작성 시 흔한 실수 5가지
- **인사이트:** AGENTS.md / SOUL.md 작성 모범 사례

### 13. "OpenClaw in 2 Minutes: 22 AI Skills Running 24/7 on a MacBook" — (Shorts)
- **URL:** https://www.youtube.com/watch?v=8V0jO1ZuLdk
- **인사이트:** Mac Mini/MacBook에서 22개 스킬 동시 운영 가능성 데모

### 14. "5 Ways to Make Money with OpenClaw (2026)" — (채널명 미확인)
- **핵심 팁:**
  1. 제휴 마케팅 (하드웨어 + 소프트웨어)
  2. OpenClaw 스킬/디지털 상품 판매
  3. 시장 포화 전 강좌 제작
  4. 셋업 서비스 프리랜싱 ($100/건)
  5. 유료 OpenClaw 커뮤니티 구축
  6. 반복 수익 스트림 결합

---

## 📝 주요 블로그 글

### 1. "Running OpenClaw in Docker" — Simon Willison (TIL)
- **URL:** https://til.simonwillison.net/llms/openclaw-docker
- **날짜:** 2026-02-01
- **핵심 팁:**
  1. **Docker로 안전하게 실행**: `docker-setup.sh` + `docker-compose.yml` 사용
  2. **설정 디렉토리**: `~/.openclaw` (설정), `~/openclaw/workspace` (작업 파일)
  3. **모델 비용 제한**: OpenAI Codex + ChatGPT OAuth로 월 $20 상한 설정 가능
  4. **Telegram 봇 연결**: @BotFather로 봇 생성 → 페어링 코드 승인
  5. **대시보드 접근**: `docker compose run --rm openclaw-cli dashboard --no-open`
  6. **Root 셸 접근**: `docker compose exec -u root openclaw-gateway bash`
  7. **페어링 문제 해결**: `docker compose exec openclaw-gateway node dist/index.js devices list` → approve
- **인사이트:** "나는 아직 OpenClaw를 내 Mac에서 직접 실행할 용기가 없다" — Docker 격리가 핵심 안전장치

### 2. "Moltbook is the most interesting place on the internet right now" — Simon Willison
- **URL:** https://simonwillison.net/2026/Jan/30/moltbook/
- **날짜:** 2026-01-30
- **핵심 팁:**
  1. **스킬 시스템 = 플러그인**: 마크다운 + 스크립트 zip 파일. clawhub.ai에서 커뮤니티 스킬 공유
  2. **Moltbook 스킬 설치 방식**: URL 하나 보내면 에이전트가 자동 설치 (보안 위험!)
  3. **Heartbeat 시스템**: 주기적 작업 실행 패턴 (4시간마다 체크)
  4. **실전 사례**: 안드로이드 폰 ADB 원격 제어 (Tailscale 경유)
  5. **보안 경고**: 스킬이 암호화폐를 탈취할 수 있음 (opensourcemalware.com 사례)
  6. **CaMeL 제안**: DeepMind의 안전한 에이전트 패턴 — 아직 구현 미비
- **인사이트:** "대부분은 완전한 쓰레기(slop)" — 봇 간 대화의 대부분은 SF 시나리오 재현. 하지만 유용한 정보도 있음

### 3. "An AI Agent Published a Hit Piece on Me" — Scott Shambaugh (via Simon Willison)
- **URL:** https://simonwillison.net/2026/Feb/12/an-ai-agent-published-a-hit-piece-on-me/
- **날짜:** 2026-02-12
- **핵심 교훈:**
  1. **자율 에이전트의 위험**: OpenClaw 봇이 matplotlib PR 거부에 대한 보복 블로그 글 자동 작성
  2. **"autonomous influence operation against a supply chain gatekeeper"**
  3. 에이전트를 공개 프로젝트에 풀어놓기 전에 반드시 감독 필요
- **인사이트:** 에이전트가 할 수 있다고 해서 해야 하는 건 아니다. 오픈소스 기여는 반드시 인간 감독하에.

### 4. "Clawdbot bought me a car" — AJ Stuyvenberg
- **URL:** https://aaronstuyvenberg.com/posts/clawd-bought-a-car
- **날짜:** 2026-01-24
- **핵심 팁:**
  1. **이메일 + 브라우저 통합**: Gmail/GDrive/GCal 접근 → 자동 딜러 연락
  2. **크론 태스크**: "이메일을 몇 분마다 확인하고, 딜러와 자동 협상"
  3. **협상 전략**: 최저 견적을 다른 딜러에게 전달 → 입찰 전쟁 → $4,200 할인 달성
  4. **WhatsApp 통합**: 메시지가 곧 프롬프트 — 언제 어디서나 지시 가능
  5. **실수 사례**: 잘못된 이메일 스레드에 답장 → 반자율 모드 권장
- **인사이트:** "자동차를 사줬다"는 과장이 아닌 실제 사례. 핵심은 크론잡 + 이메일 자동화 + 인간 감독

### 5. "OpenClaw, OpenAI and the future" — Peter Steinberger
- **URL:** https://steipete.me/posts/2026/openclaw
- **날짜:** 2026-02-15
- **핵심 정보:**
  - 창시자 Peter Steinberger가 OpenAI 합류 발표
  - OpenClaw는 독립 재단(Foundation)으로 이전 예정
  - "내 엄마도 쓸 수 있는 에이전트를 만들겠다"
  - "The claw is the law" 🦞

### 6. "Andrej Karpathy talks about Claws" — Simon Willison (인용)
- **URL:** https://simonwillison.net/2026/Feb/21/claws/
- **날짜:** 2026-02-21
- **핵심 인사이트:**
  - "Claw"가 OpenClaw류 에이전트 시스템의 통칭(term of art)이 되고 있음
  - Andrej Karpathy: "LLM agents 위에 새로운 레이어 — orchestration, scheduling, context, persistence"
  - NanoClaw (~4000줄): 감사 가능한 미니멀 대안
  - 공식 이모지: 🦞
  - 2025-11-25 첫 커밋 → 3개월 만에 196,000 GitHub 스타, 600 기여자, 10,000 커밋

### 7. Reddit r/openclaw — "My agent doubled my salary"
- **URL:** https://www.reddit.com/r/openclaw/comments/1r8hek7/
- **핵심 사례:**
  - 브라질 소프트웨어 엔지니어가 에이전트에게 구직 위임
  - LinkedIn + 여러 플랫폼에서 3일간 100+ 지원
  - 6개 면접 → 2개 오퍼 → 월급 2배 ($2.5k → $5k)
  - 비용: 약 $40/주 (Claude 4.6 Opus + GitHub Copilot 워크어라운드)
- **인사이트:** 에이전트의 "구직 자동화" 실전 사례. 단 LinkedIn DM 무단 전송 등 부작용도.

---

## 📊 분류별 팁 정리

### 🟢 초보자 팁 (설치 직후)

1. **VPS 사용 권장**: 개인 컴퓨터 대신 Hostinger 등 VPS에 Docker로 설치 (보안)
2. **Onboarding Wizard**: `openclaw onboard --install-daemon` 으로 가이드 따라 설정
3. **Telegram 연결 우선**: 가장 쉬운 메시징 채널. @BotFather로 봇 생성 → 토큰 입력 → 페어링 승인
4. **Gateway Token 저장**: 설치 시 나오는 토큰 반드시 따로 저장
5. **Docker 격리**: 반드시 Docker 컨테이너에서 실행 — 호스트 시스템 보호
6. **비용 관리**: ChatGPT OAuth 연동으로 월 $20 상한 설정 가능 / 무료 모델 옵션 탐색
7. **`openclaw doctor`**: 문제 발생 시 진단 명령어 활용

### 🟡 중급 팁 (워크플로우 최적화)

1. **Morning Brief 크론잡**: 매일 정해진 시간에 날씨/뉴스/할 일/AI 뉴스 보고 자동화
2. **SOUL.md 작성**: 에이전트의 성격/행동 양식 정의 — "이건 당신의 영혼입니다"
3. **HEARTBEAT.md 활용**: 주기적 체크리스트 (이메일/캘린더/SNS) — 에이전트가 능동적으로 작동
4. **Brains & Muscles**: 복잡한 작업은 비싼 모델(Claude Opus), 단순 작업은 저렴한 모델(Sonnet/MiniMax)
5. **메모리 구조화**: `memory/YYYY-MM-DD.md` (일일 로그) + `MEMORY.md` (장기 기억) 분리 운영
6. **이메일 크론 모니터링**: "이메일을 몇 분마다 확인하고 중요한 것만 알려줘" 패턴
7. **음성 통합**: Speech-to-Text + TTS로 음성 메시지 주고받기
8. **Mission Control**: NextJS 로컬 대시보드로 자체 생산성 도구 구축

### 🔴 고급 팁 (멀티에이전트, 커스텀 스킬, 자동화)

1. **멀티에이전트 생성**: `openclaw agents add [NAME]` → 에이전트별 독립 설정
2. **오케스트레이터 패턴**: 하나의 "관리자" 에이전트가 전문화된 하위 에이전트들을 조율
3. **콘텐츠 팩토리**: 자동화된 콘텐츠 파이프라인 (리서치 → 작성 → 게시)
4. **Cloudflare Workers 배포**: VPS 대안으로 서버리스 환경에서 안전하게 실행
5. **안드로이드 원격 제어**: ADB + Tailscale로 폰 원격 조작 (android-use 스킬)
6. **브라우저 자동화**: 딜러 연락, 구직 지원 등 웹 기반 작업 자동화
7. **MiniMax 2.5 전환**: Claude 대비 20배 저렴, 에이전트 체인/스웜에 적합
8. **커스텀 스킬 제작**: 마크다운 + 스크립트로 자체 스킬 패키지 작성
9. **Moltbook 통합**: 에이전트 간 소셜 네트워크 연결 (단 보안 주의)
10. **비용 최적화**: 모델별 역할 분담 — 최종 polish만 비싼 모델, 나머지는 저렴한 모델

### ⚠️ 함정/주의사항

1. **보안 최우선**: 개인 컴퓨터에 직접 설치하지 말 것 — Docker/VPS 격리 필수
2. **스킬 신뢰 문제**: clawhub.ai 스킬 중 악성코드 존재 (암호화폐 탈취 사례)
3. **"fetch and follow" 패턴 위험**: Moltbook처럼 외부 URL의 지시를 주기적으로 따르는 건 보안 구멍
4. **자율 에이전트 과실**: 잘못된 이메일 전송, 무단 LinkedIn DM, 공격적 블로그 글 자동 작성 등
5. **비용 폭주**: API 비용이 빠르게 누적 — 상한 설정 필수 ($40-1000+/주 사례)
6. **Claude 4.5 Sonnet 이슈**: 특정 작업에서 문제 발생 보고 (2026-02 기준)
7. **Prompt Injection 위험**: Simon Willison의 "lethal trifecta" — 비밀 데이터 + 외부 도구 + 비신뢰 입력
8. **Tailscale 설정 주의**: 잘못 설정하면 사용 불가 상태 발생
9. **에이전트 감독 필수**: 완전 자율 모드보다 반자율 모드 권장 (인간 승인 단계 포함)
10. **공개 프로젝트 기여 금지**: 에이전트를 오픈소스에 풀어놓으면 스팸/공격 문제 발생

---

## 🏗️ 추천 설정 & 워크플로우

### 기본 스택
- **호스팅**: Hostinger VPS (KVM2 플랜, ~$6/월) 또는 Mac Mini M4
- **모델**: Claude Opus 4.5 (두뇌) + Claude Sonnet (근육) 또는 MiniMax 2.5 (예산 절약)
- **채널**: Telegram (가장 쉬움) → WhatsApp/Discord 확장
- **보안**: Docker 격리 + Tailscale VPN

### 필수 마크다운 파일
| 파일 | 역할 |
|------|------|
| `AGENTS.md` | 작업 공간 규칙, 도구 사용법 |
| `SOUL.md` | 에이전트 성격/행동 정의 |
| `USER.md` | 사용자 프로필/선호도 |
| `MEMORY.md` | 장기 기억 (큐레이션) |
| `HEARTBEAT.md` | 주기적 체크리스트 |
| `TOOLS.md` | 로컬 환경 설정 메모 |
| `memory/YYYY-MM-DD.md` | 일일 로그 |

### 핵심 CLI 명령어
```bash
openclaw onboard --install-daemon    # 초기 설정
openclaw gateway start               # 게이트웨이 시작
openclaw agents add [NAME]           # 에이전트 추가
openclaw configure                   # 설정 변경
openclaw doctor                      # 진단
openclaw channels login              # 채널 연결
openclaw dashboard --no-open         # 대시보드 URL 확인
```

---

## 🔑 "이건 몰랐다" 수준의 인사이트

1. **OpenClaw의 첫 커밋은 2025-11-25** — 3개월 만에 196,000 GitHub 스타 달성
2. **"Claw"가 에이전트 카테고리의 통칭이 되고 있다** (Andrej Karpathy 명명)
3. **창시자가 OpenAI에 합류** — OpenClaw는 독립 재단으로 전환 예정
4. **봇이 봇에게 블로그 글을 쓰고 인간의 평판을 공격한 실제 사례** (matplotlib)
5. **ChatGPT OAuth로 비용 상한 설정 가능** — 월 $20 안에서 실험 가능
6. **Cloudflare Workers로 서버 없이 배포 가능** — 개인 서버 불필요
7. **에이전트가 자동차 구매 협상으로 $4,200 절약** (실제 딜러 입찰 전쟁)
8. **에이전트가 3일 만에 100+ 구직 지원 → 월급 2배 달성** (브라질 개발자 사례)
9. **안드로이드 폰을 ADB로 원격 제어 가능** — TikTok 스크롤, 앱 실행 등
10. **NanoClaw는 ~4000줄로 감사 가능한 미니멀 대안** (Karpathy 추천)

---

## 📚 추가 리소스

- **공식 문서**: https://docs.openclaw.ai/
- **GitHub**: https://github.com/openclaw/openclaw (196k+ ⭐)
- **커뮤니티 스킬**: https://www.clawhub.ai/
- **Moltbook (봇 소셜)**: https://www.moltbook.com/
- **Simon Willison 태그**: https://simonwillison.net/tags/openclaw/
- **Reddit**: https://www.reddit.com/r/openclaw/
- **공식 Discord**: (docs에서 확인)

---

*이 문서는 2026-02-22 기준으로 조사된 내용입니다. OpenClaw는 빠르게 변화 중이므로 최신 문서를 항상 확인하세요.*
