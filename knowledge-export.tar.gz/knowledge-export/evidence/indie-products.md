# 1인/소규모 AI 제품 증거 수집

> 수집일: 2026-02-20
> 논리나 의견 없음. 오직 증거만.

---

## 📈 성공 사례: API 래퍼 / AI 제품으로 돈 번 개인/소규모 팀

---

### 1. Base44

- **만든 사람:** Maor Shlomo — 1인 창업 (매각 시점 8명)
- **한 줄 설명:** AI 기반 노코드 앱 빌더 (채팅으로 소프트웨어 생성)
- **매출/수익 증거:**
  - 런칭 3주 만에 $1M ARR
  - 런칭 6개월 만에 월 $189K 순이익 (LLM 비용 차감 후)
  - 250,000~400,000 유저 달성
  - **Wix에 $80M 현금 매각** (2025년 6월)
  - 출처: TechCrunch, Lenny's Newsletter, Wix 공식 발표
- **기술 스택:** LLM API (토큰 비용 공개적으로 기록), 자체 프론트엔드
- **만드는 데 걸린 시간:** 사이드 프로젝트로 시작, ~6개월
- **경쟁자 대비 차별점:** 100% 자동화된 채팅 기반 인터페이스, DB/인증/배포 모두 자동 처리. 외부 투자 0원. 빌드인퍼블릭으로 성장.
- **출처 URL:**
  - <https://techcrunch.com/2025/06/18/6-month-old-solo-owned-vibe-coder-base44-sells-to-wix-for-80m-cash/>
  - <https://www.lennysnewsletter.com/p/the-base44-bootstrapped-startup-success-story-maor-shlomo>

---

### 2. FormulaBot (ExcelFormulaBot)

- **만든 사람:** David Bressler — 1인 (본업 유지하며 사이드 프로젝트)
- **한 줄 설명:** 텍스트를 Excel 수식으로 변환하는 AI 도구
- **매출/수익 증거:**
  - 런칭 6개월 만에 $26K MRR
  - 현재 $226K MRR (월 매출)
  - 750,000+ 유저, 5,000 유료 유저
  - 첫해 추정 총수익 $192K, 순이익 $164K (이익률 87.5%)
  - 노코드(Bubble.io)로 제작, 마케팅 비용 $5,000 미만
  - 출처: Indie Hackers, PickleRooms, Solopreneur.global
- **기술 스택:** OpenAI API, Bubble.io (노코드), Excel/Google Sheets 플러그인
- **만드는 데 걸린 시간:** MVP 수 주 (6주 휴가 기간)
- **경쟁자 대비 차별점:** "API 래퍼"의 전형적 성공 사례. 수식은 토큰 소모가 극히 적어 마진 87%+. Reddit 바이럴 (10,000 업보트, 81,000 방문자). TikTok KOL 마케팅.
- **출처 URL:**
  - <https://picklerooms.com/blogs/origin-stories/david-bressler-formula-bot>
  - <https://www.indiehackers.com/post/case-study-excel-ai-bot-makes-projected-164-850-profit-in-12-months-402bf5338c>

---

### 3. Photo AI

- **만든 사람:** Pieter Levels (@levelsio) — 1인
- **한 줄 설명:** AI 포토 제너레이터 ("사진작가를 해고하라")
- **매출/수익 증거:**
  - 런칭 1주 $5.4K MRR → 6개월 $61.8K MRR → 현재 $132-138K MRR
  - 연간 런레이트 ~$1.6M
  - 이익률 87%+ (GPU 비용 월 ~$13K)
  - 100% 부트스트랩, 투자 0
  - 출처: Pieter의 트위터, IndieHackers
- **기술 스택:** Stable Diffusion / 커스텀 파인튜닝, 바닐라 HTML/CSS/jQuery, PHP
- **만드는 데 걸린 시간:** ~2개월
- **경쟁자 대비 차별점:** 10년간 70+ 프로젝트 실패 후 쌓인 청중(85만 팔로워). "졸업한" 기술 스택(React 없음, TypeScript 없음)으로도 성공. 빌드인퍼블릭.
- **출처 URL:**
  - <https://www.indiehackers.com/post/photo-ai-by-pieter-levels-complete-deep-dive-case-study-0-to-132k-mrr-in-18-months-3a9a2b1579>
  - <https://www.fast-saas.com/blog/pieter-levels-success-story/>

---

### 4. HeadshotPro

- **만든 사람:** Danny Postma — 1인
- **한 줄 설명:** AI 프로필 사진/헤드샷 생성기
- **매출/수익 증거:**
  - 월 $300K 매출 (연 $3.6M ARR)
  - 196,987+ 고객, 17.9M+ 헤드샷 생성
  - 전환율 ~5%
  - 어필리에이트만으로 월 $50K+ (매출의 15%)
  - 출처: Medium, Market Clarity, BootstrappersFM
- **기술 스택:** Stable Diffusion + DreamBooth 파인튜닝, LLaVa (필터), Codeformer (아티팩트 제거), Replicate (GPU)
- **만드는 데 걸린 시간:** MVP 30시간
- **경쟁자 대비 차별점:** 이전 제품 Headlime을 $1M에 매각한 경험. 공격적 SEO ("AI headshot" 1위). 빌드인퍼블릭 (158K 트위터 팔로워).
- **출처 URL:**
  - <https://mktclarity.com/blogs/news/ai-wrappers-top>
  - <https://bootstrappers.com/how-danny-postma-became-a-viral-saas-sensation-twice/>

---

### 5. Postiz

- **만든 사람:** Nevo David — 1인 개발자
- **한 줄 설명:** 오픈소스 소셜 미디어 스케줄러 (AI 기능 탑재)
- **매출/수익 증거:**
  - 런칭 4개월 만에 $2K MRR (2024년 12월)
  - 2025년 7월 $6.5K MRR → 8월 $12.6K → 현재 $21.5K MRR
  - 총 수익 $138K+, 556 유료 구독
  - Stripe 검증된 수치 (TrustMRR)
  - 출처: IndieHackers, TrustMRR, dev.to
- **기술 스택:** 오픈소스, AI API 통합 (콘텐츠 생성), n8n 연동
- **만드는 데 걸린 시간:** 2024년 초부터 개발, 9월 오픈소스 런칭
- **경쟁자 대비 차별점:** 20년 된 시장(Hootsuite 등 1000+ 경쟁자)에서 **오픈소스 전략**으로 차별화. Product Hunt 1위. Discord 커뮤니티 + GitHub 스타 15K+. Docker 584K 다운로드.
- **출처 URL:**
  - <https://www.indiehackers.com/post/i-did-it-my-open-source-company-now-makes-14-2k-monthly-as-a-single-developer-f2fec088a4>
  - <https://trustmrr.com/startup/postiz>

---

### 6. SiteGPT

- **만든 사람:** Bhanu Teja Paccha — 1인 (24세, IIT Madras 졸업)
- **한 줄 설명:** 자체 데이터로 학습시키는 AI 챗봇 빌더
- **매출/수익 증거:**
  - ~$95K MRR (~$1.14M ARR)
  - 출처: CrazyBurst, IndieHackers
- **기술 스택:** GPT API, 노코드 챗봇 빌더 인터페이스
- **만드는 데 걸린 시간:** 2023년 런칭
- **경쟁자 대비 차별점:** 범용 챗봇이 아닌 기업 자체 데이터에 특화. B2B 니치.
- **출처 URL:**
  - <https://crazyburst.com/ai-saas-solo-founder-success-stories-2026/>

---

### 7. PDF.ai

- **만든 사람:** Seth Kramer — 1인
- **한 줄 설명:** PDF와 채팅하기
- **매출/수익 증거:**
  - ~$100K MRR
  - 출처: CrazyBurst
- **기술 스택:** LLM API, PDF 파싱, 사용량 기반 가격 모델
- **만드는 데 걸린 시간:** 2023년 런칭, 빠르게 수요 검증
- **경쟁자 대비 차별점:** 매우 단순한 유즈케이스("PDF와 대화"). 명확한 SEO 키워드 의도. 즉각적 사용자 가치.
- **출처 URL:**
  - <https://crazyburst.com/ai-saas-solo-founder-success-stories-2026/>

---

### 8. InsertChatGPT

- **만든 사람:** 소규모 팀
- **한 줄 설명:** 화이트라벨 ChatGPT 챗봇 (자체 데이터 학습)
- **매출/수익 증거:**
  - $30K MRR 달성
  - 출처: IndieHackers
- **기술 스택:** ChatGPT API, 화이트라벨 솔루션
- **만드는 데 걸린 시간:** 불명
- **경쟁자 대비 차별점:** "자체 데이터로 학습된 ChatGPT"라는 명확한 가치 제안. B2B 화이트라벨.
- **출처 URL:**
  - <https://www.indiehackers.com/post/30-new-ai-startup-ideas-earning-report-1715be210a>

---

### 9. Dante AI

- **만든 사람:** 소규모 팀 (15명)
- **한 줄 설명:** 맞춤형 GPT 챗봇 빌더
- **매출/수익 증거:**
  - $1.7M 연매출 (2025년)
  - 런칭 1개월 미만에 $7K MRR 달성
  - 외부 펀딩 $0
  - 출처: GetLatka
- **기술 스택:** GPT API 기반 챗봇 빌더
- **만드는 데 걸린 시간:** 2023년 런칭
- **경쟁자 대비 차별점:** 부트스트랩으로 성장, 외부 투자 없이 수익성 확보.
- **출처 URL:**
  - <https://getlatka.com/companies/dante-ai.com>

---

### 10. CustomGPT

- **만든 사람:** Ali Zahid — 1인
- **한 줄 설명:** 환각(hallucination) 방지에 특화된 도메인 AI 에이전트
- **매출/수익 증거:**
  - $50K+ MRR
  - 출처: CrazyBurst
- **기술 스택:** LLM API + 자체 데이터 파이프라인
- **만드는 데 걸린 시간:** 2023년 런칭
- **경쟁자 대비 차별점:** "정확성"이라는 기술적 신뢰 격차 해결. 노코드 커스터마이징.
- **출처 URL:**
  - <https://crazyburst.com/ai-saas-solo-founder-success-stories-2026/>

---

### 11. Blackbox AI

- **만든 사람:** Mohamed Maamer — 부트스트랩 창업 → 180명 팀으로 성장
- **한 줄 설명:** AI 코딩 어시스턴트
- **매출/수익 증거:**
  - $31.7M 연매출 (2025년)
  - 12M+ 개발자 사용 (전 세계 개발자의 ~10%)
  - 878K 일일 방문, 26.3M 월간 방문
  - VS Code 3.96M+ 설치
  - **외부 펀딩 $0**
  - 출처: Tenet, GetLatka, LinkedIn
- **기술 스택:** 멀티모델 LLM (GPT-4o, Claude 3.5, DeepSeek R1 등), 30+ IDE 지원
- **만드는 데 걸린 시간:** 2023년 런칭
- **경쟁자 대비 차별점:** GitHub 바이럴 + 개발자 구전으로 성장. 펀딩 없이 $31.7M 매출. 멀티모델 아키텍처.
- **출처 URL:**
  - <https://www.wearetenet.com/blog/blackbox-ai-usage-statistics>

---

## 📈 성공 사례: 소규모 팀 (10~50명) — 폭발적 성장

---

### 12. Midjourney

- **만든 사람:** David Holz + 소규모 팀 (50명 미만)
- **한 줄 설명:** AI 이미지 생성 플랫폼
- **매출/수익 증거:**
  - 2022년 $50M → 2023년 $200M → 2024년 $300M → 2025년 **$500M** 매출
  - **외부 투자 $0** (완전 부트스트랩)
  - 50명 미만 팀으로 직원당 매출 $10M+
  - 출처: GetLatka, seo.ai, Sacra
- **기술 스택:** 자체 이미지 생성 모델 (API 래퍼 아님)
- **만드는 데 걸린 시간:** 2022년 런칭
- **경쟁자 대비 차별점:** 자체 모델. VC 투자 없이 $500M 매출. Discord 커뮤니티 기반 배포.
- **출처 URL:**
  - <https://getlatka.com/companies/midjourney>
  - <https://seo.ai/blog/how-many-people-work-at-midjourney>

---

### 13. Cursor (Anysphere)

- **만든 사람:** Michael Truell, Sualeh Asif, Aman Sanger, Arvid Lunnemark — 4인 창업 → ~150명
- **한 줄 설명:** AI 코딩 에디터
- **매출/수익 증거:**
  - 2025년 1월 $100M ARR → 6월 $500M ARR → 11월 **$1B ARR**
  - 직원당 매출 ~$5M
  - 밸류에이션 $29.3B
  - **마케팅 비용 $0으로 $100M ARR 달성**
  - 출처: Wikipedia, TechCrunch, Contrary Research
- **기술 스택:** VS Code 기반, 자체 모델 + 외부 LLM
- **만드는 데 걸린 시간:** 2022년 설립, 2023년 3월 런칭
- **경쟁자 대비 차별점:** 개발자 경험 중심 설계. 마케팅 없이 구전으로 성장. 직원당 매출이 MAG7 기업 능가.
- **출처 URL:**
  - <https://en.wikipedia.org/wiki/Anysphere>
  - <https://techcrunch.com/2025/06/05/cursors-anysphere-nabs-9-9b-valuation-soars-past-500m-arr/>

---

### 14. Lovable

- **만든 사람:** Anton Osika + 소규모 팀 (15명으로 $10M ARR)
- **한 줄 설명:** 바이브 코딩 플랫폼 (자연어로 앱 생성)
- **매출/수익 증거:**
  - 2024년 11월 런칭 → 12월 $1M ARR → 4주 $4M → 2개월 $10M → 8개월 **$100M ARR** → 12개월 $200M ARR
  - "역사상 가장 빠르게 성장한 소프트웨어 스타트업"
  - 하루 $1M 구독 매출
  - 밸류에이션 $6.6B
  - 출처: Forbes, LinkedIn(Nico Rosberg), aifundingtracker
- **기술 스택:** AI 기반 코드 생성, 클라우드 호스팅
- **만드는 데 걸린 시간:** 2023년 9월 설립, 2024년 11월 퍼블릭 런칭
- **경쟁자 대비 차별점:** 스웨덴 기반. 70% 유저가 코딩 경험 없음. 프리미엄 + 크레딧 기반 수익 모델.
- **출처 URL:**
  - <https://www.forbes.com/sites/iainmartin/2025/07/23/vibe-coding-turned-this-swedish-ai-unicorn-into-the-fastest-growing-software-startup-ever/>
  - <https://aifundingtracker.com/lovable-vibe-coding-revenue/>

---

### 15. Bolt.new (StackBlitz)

- **만든 사람:** Eric Simons — 15~20명 팀
- **한 줄 설명:** 브라우저 기반 AI 앱 빌더
- **매출/수익 증거:**
  - 런칭 전 7년간 $1M 미만 매출 (거의 폐업 직전)
  - 2024년 10월 Bolt.new 런칭 (트윗 1개로)
  - 1주차 $1M ARR → 30일 $4M ARR → 60일 $20M ARR → 5개월 **$40M ARR**
  - 3M+ 등록 유저, 1M DAU
  - **현재 수익성 확보**
  - 출처: Business Insider, LinkedIn(Lenny), Medium
- **기술 스택:** WebContainers (7년간 자체 개발한 브라우저 내 Node.js 런타임) + Claude 3.5 Sonnet
- **만드는 데 걸린 시간:** 핵심 기술(WebContainers) 7년 + Bolt.new 자체는 수 주
- **경쟁자 대비 차별점:** "7년간의 하룻밤 성공." 7년간 쌓은 독자 기술이 AI와 결합하며 폭발. 비기술자도 소프트웨어 생성 가능.
- **출처 URL:**
  - <https://www.businessinsider.com/stackblitz-bolt-silicon-valley-hottest-ai-coding-startup-nearly-died-2025-5>
  - <https://angelina-yang.medium.com/bolt-news-coo-on-why-vibe-coding-is-the-wrong-word>

---

### 16. HeyGen

- **만든 사람:** Joshua Xu + 소규모 팀 (~30명으로 시작)
- **한 줄 설명:** AI 비디오 생성 플랫폼 (아바타, 음성 합성)
- **매출/수익 증거:**
  - 2022년 7월 런칭 → 178일 만에 $1M ARR
  - 2023년 Q2부터 수익성 확보
  - 1년 만에 $35M ARR → 2025년 10월 **$100M ARR**
  - 85K+ 고객
  - 출처: ARR Club, TechCrunch, Sacra
- **기술 스택:** 자체 AI 비디오/음성 모델
- **만드는 데 걸린 시간:** 2022년 7월 런칭
- **경쟁자 대비 차별점:** 프리미엄 모델 (워터마크 → 유료 전환). 주간 릴리스. "AI 비디오의 Canva."
- **출처 URL:**
  - <https://www.arr.club/signal/heygen-arr-hits-100m>
  - <https://www.heygen.com/blog/0-1m-arr-in-7-months>

---

### 17. ElevenLabs

- **만든 사람:** Mati Staniszewski + Piotr Dąbkowski — 2인 창업 (폴란드 바르샤바)
- **한 줄 설명:** AI 음성 생성/복제 플랫폼
- **매출/수익 증거:**
  - ~30개월 만에 **$200M ARR** 달성 → 2025년 **$330M ARR**
  - 밸류에이션 $6.6B
  - Fortune 500 기업 및 스타트업 모두 채택
  - 출처: LinkedIn(CEO), TechCrunch, a16z
- **기술 스택:** 자체 음성 AI 모델 (API 래퍼 아님)
- **만드는 데 걸린 시간:** 2022년 설립
- **경쟁자 대비 차별점:** 폴란드 더빙 품질 불만에서 시작. 자체 모델로 기술적 해자. 크리에이터/엔터프라이즈 양면 시장.
- **출처 URL:**
  - <https://techcrunch.com/2026/01/13/elevenlabs-ceo-says-the-voice-ai-startup-crossed-330-million-arr-last-year/>
  - <https://a16z.com/where-you-build-is-who-you-are-the-elevenlabs-story/>

---

## ❌ 실패 사례: "API 래퍼는 죽는다"의 증거

---

### 18. AI 래퍼 시장 전체 — 실패 통계

- **데이터:**
  - AI 래퍼 스타트업의 **90-92%가 18개월 내 폐업** (AI Journal)
  - 40-50%가 첫해에 피벗
  - 2025년 전체 스타트업 폐업 중 **16%가 AI 기업** (SimpleClosure 2025 보고서)
  - Series A 폐업이 전년 대비 2.5배 증가 (6% → 14%)
  - "AI 래퍼와 커모디티 모델 위에 빠르게 구축된 앱들이 가장 급격한 조정을 받고 있다"
  - **평균 90일 이탈률 65%** (일반 SaaS 35%의 거의 2배)
  - $50 미만 AI 제품: GRR 23%, NRR 32% (B2B SaaS 대비 20포인트 낮음)
  - 출처: SimpleClosure, ChartMogul, AI Journal, Yahoo Finance
- **출처 URL:**
  - <https://finance.yahoo.com/news/2025-startup-shutdown-more-capital-140000985.html>
  - <https://chartmogul.com/reports/saas-retention-the-ai-churn-wave/>
  - <https://mktclarity.com/blogs/news/ai-wrapper-market>

---

### 19. Builder.ai — $1.5B 밸류에이션 → 파산

- **한 줄 설명:** AI로 앱을 만든다고 홍보했지만, 실제로는 인도의 700명 엔지니어가 수동 코딩
- **매출/수익 증거:** Microsoft 투자 유치 → 2025년 5월 파산 신청
- **실패 원인:** "AI 기반"이라고 했지만 실제 AI 없음. 사기에 가까운 구조.
- **출처 URL:**
  - <https://medium.com/@Jason__Li/the-100-billion-ai-bubble-when-it-pops-these-startups-will-survive-6a5c4cb6ee84>

---

### 20. $10M ARR AI 고객서비스 래퍼 (익명) — 80% 매출 감소

- **한 줄 설명:** GPT-4 래퍼 + 좋은 UI로 고객서비스 팀 대상 제품
- **매출/수익 증거:** $10M ARR 달성 → OpenAI가 더 나은 function calling 출시 후 고객이 자체 구축 시작 → **2개월 만에 매출 80% 감소** → 폐업
- **실패 원인:** 방어 불가능한 해자. 기반 모델 업그레이드가 곧 제품의 죽음.
- **출처 URL:**
  - <https://www.linkedin.com/posts/itamarnovick_simpleclosure-just-released-the-2025-startup-activity-7417987759791063040-fA26>

---

### 21. "프롬프트 스타트업" 시대의 전형적 실패 패턴

- **데이터 (dev.to "AI 스타트업의 무덤" 기사 기반):**
  - 78%의 2024년 AI 스타트업이 API 래퍼 (CB Insights)
  - 12,000+ 회사가 같은 파운데이션 모델 위에 구축
  - 전형적 스택: Next.js + Vercel + TailwindCSS + Firebase Auth + OpenAI SDK + Stripe
  - "12시간 만에 만들고 런칭" → 바로 알 수 있음
  - 유저가 "$9.99/월에 ChatGPT 다크모드?"라고 깨달으면 즉시 이탈
  - 토큰 경제: 유저가 $10/월 내고 전자책 통째 요약 → OpenAI 비용 $200 → 적자 $190
  - 출처: dev.to, CB Insights
- **출처 URL:**
  - <https://dev.to/dev_tips/the-graveyard-of-ai-startups-startups-that-forgot-to-build-real-value-5ad9>

---

## 🔑 "API 래퍼인데 성공한 것" vs "실패한 것" — 패턴 분석

### 성공한 API 래퍼의 공통점 (FormulaBot, HeadshotPro, SiteGPT, PDF.ai, InsertChatGPT 등)

1. **특정 유즈케이스에 극도로 특화** (범용 AI가 아님)
2. **토큰 소모가 적거나, 높은 가격 정당화 가능** (B2B/고가)
3. **SEO + 바이럴 채널 확보** (Product Hunt, Reddit, TikTok)
4. **워크플로 통합** (Excel 플러그인, 웹사이트 임베드 등)
5. **빌드인퍼블릭** + 개인 브랜드
6. **오픈소스 전략** (Postiz 사례)

### 실패한 API 래퍼의 공통점

1. **ChatGPT와 동일한 경험** ($20 → $10/월이지만 기능은 덜함)
2. **해자 없음** — 모델 업그레이드 시 죽음
3. **높은 토큰 비용** + 낮은 가격 = 구조적 적자
4. **높은 이탈률** (90일 내 65%)
5. **"AI 래퍼"라는 것이 너무 투명**하게 보임

---

## 📊 시장 메타 데이터

| 지표 | 수치 | 출처 |
|---|---|---|
| AI 래퍼 시장 규모 | ~$50B (2025) | Market Clarity |
| AI 래퍼 연간 성장률 | 35-45% (2030년까지) | Market Clarity |
| AI 래퍼 실패율 | 90-92% (18개월 내) | AI Journal |
| AI 래퍼 중앙 MRR (1년 후) | $30K-50K | Market Clarity |
| AI 래퍼 평균 마진 | 50-65% (전통 SaaS 80-90%) | Market Clarity |
| 솔로 파운더 비율 (Carta) | 23.7% (2019) → 36.3% (2025 H1) | Carta Solo Founders Report |
| 솔로 파운더 첫 고용까지 중앙값 | 399일 | Carta |
| AI 스타트업 매출 배수 | 29.7x (전통 SaaS 7.0x) | Forbes |

---

## 🇰🇷 한국어 관련

- **fello.io** — 한국 IT 스타트업 인수/매각 플랫폼에서 AI 서비스 매물 다수 확인
  - 살롱AI (헤어 모델 사진 생성): 희망 매도가 2000만원, 월 매출 16만원
  - AI 기반 숏폼 영상 제작 솔루션: 희망 매도가 20억원
  - 웹 영상 AI 노트 테이킹 서비스: 월 매출 1000만원, 희망 매도가 5억원
  - 생성형 AI 글작성 플랫폼: 월 매출 20만원 → 판매 완료
  - 출처: <https://www.fello.io/products>

- **코딩배워투자하자 뉴스레터** — 국내외 수익형 서비스 사례 분석 (1인 AI 서비스 포함)
  - 4년 만에 연 14억 원 버는 사이드 프로젝트 사례 소개
  - 출처: <https://maily.so/cobaetoo/posts/8mo58nn2o9p>

---

*최종 수집: 21개 케이스 (성공 17 + 실패/통계 4)*
*"API 래퍼는 죽는다"에 대한 반례: FormulaBot, HeadshotPro, SiteGPT, PDF.ai, InsertChatGPT, CustomGPT 등 — 특화 + SEO + 워크플로 통합이면 래퍼도 생존/성공 가능*
