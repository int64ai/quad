# OpenClaw 가장 간단한 설치 방법 조사

> 조사일: 2026-02-21
> 소스: docs.openclaw.ai (Getting Started, Install, Wizard, Onboarding, FAQ)

---

## 🏆 TL;DR — 가장 빠른 경로 (3단계, ~5분)

```bash
# 1. 설치 (Node 22 없으면 자동 설치됨)
curl -fsSL https://openclaw.ai/install.sh | bash

# 2. 온보딩 위자드 (auth, gateway, channels 설정)
openclaw onboard --install-daemon

# 3. 대시보드 열기 → 바로 채팅 가능
openclaw dashboard
```

**Windows:**
```powershell
iwr -useb https://openclaw.ai/install.ps1 | iex
```

**채널 연결 없이 가장 빠른 채팅:**
- `openclaw dashboard` 실행 → 브라우저에서 `http://127.0.0.1:18789/` 접속
- Control UI에서 바로 채팅 가능 (채널 설정 불필요!)

---

## 1. 가장 빠른 설치 경로는?

### 추천: Installer Script (공식 추천)
- **한 줄**로 Node 감지 → 설치 → npm global install → 온보딩 위자드 실행까지 자동
- `curl -fsSL https://openclaw.ai/install.sh | bash`
- Node 22가 없으면 자동으로 설치해줌
- 설치 후 자동으로 `openclaw onboard` 진입

### 대안 경로들
| 방법 | 명령 | 비고 |
|------|-------|------|
| **Installer script** ⭐ | `curl -fsSL https://openclaw.ai/install.sh \| bash` | 가장 쉬움, Node 자동 설치 |
| npm | `npm install -g openclaw@latest && openclaw onboard --install-daemon` | Node 22+ 필요 |
| pnpm | `pnpm add -g openclaw@latest && pnpm approve-builds -g` | build scripts 승인 필요 |
| From source | `git clone → pnpm install → pnpm build → pnpm link --global` | 개발자용 |
| Docker | docs: /install/docker | 컨테이너 환경용 |
| Podman | docs: /install/podman | Rootless 컨테이너 |
| Nix | docs: /install/nix | 선언형 설치 |
| Ansible | docs: /install/ansible | 자동화 플릿 |
| Bun | docs: /install/bun | CLI-only |
| **macOS App** | GUI 앱 다운로드 | macOS 전용, GUI 온보딩 |

---

## 2. `openclaw onboard` 위자드가 무엇을 하는가?

위자드는 **QuickStart** (기본값) vs **Advanced** (풀 컨트롤) 중 선택 가능.

### QuickStart 모드 기본값:
- 로컬 게이트웨이 (loopback)
- 기본 워크스페이스 (`~/.openclaw/workspace`)
- 게이트웨이 포트 **18789**
- 게이트웨이 인증: **Token** (자동 생성, loopback에서도)
- Tailscale 노출: Off
- Telegram + WhatsApp DMs: allowlist (전화번호 입력 프롬프트)

### 위자드가 설정하는 7가지:
1. **Model/Auth** — Anthropic API key (추천), OpenAI, 또는 Custom Provider 선택. 기본 모델 선택.
2. **Workspace** — 에이전트 파일 위치 (기본: `~/.openclaw/workspace`). 부트스트랩 파일 시딩.
3. **Gateway** — 포트, bind 주소, auth 모드, Tailscale 노출.
4. **Channels** — WhatsApp, Telegram, Discord, Google Chat, Mattermost, Signal, BlueBubbles, iMessage.
5. **Daemon** — LaunchAgent (macOS) 또는 systemd user unit (Linux/WSL2) 설치.
6. **Health check** — 게이트웨이 시작 및 실행 확인.
7. **Skills** — 추천 스킬 및 선택적 의존성 설치.

> **재실행해도 안전!** `--reset` 명시하지 않으면 기존 설정을 지우지 않음.

---

## 3. 최소 필요 사양

### 필수:
- **Node.js 22+** (installer script가 없으면 자동 설치)
- macOS, Linux, 또는 Windows (WSL2 강력 추천)
- pnpm은 소스 빌드 시에만 필요

### VPS 최소 사양 (FAQ 언급):
- FAQ에 "minimum VPS requirements and recommended OS" 항목 존재
- Raspberry Pi에서도 실행 가능 (FAQ에 전용 팁 섹션 있음)
- VM에서도 실행 가능

### 디스크/메모리:
- OpenClaw 자체는 Node.js 앱이므로 경량
- 모든 데이터는 로컬 저장

---

## 4. 어떤 API 키/구독이 필요한가?

### 인증 옵션 (온보딩에서 선택):
1. **Anthropic API key** — 추천 경로
2. **Claude subscription auth** (Claude Pro/Max) — `setup-token` 방식 지원
3. **OpenAI API key** — OpenAI 모델 사용
4. **Codex OAuth** — OpenAI 구독 인증
5. **Gemini CLI OAuth** — Google Gemini
6. **AWS Bedrock** — 지원됨
7. **Custom Provider** — OpenAI/Anthropic 호환 엔드포인트 (OpenRouter, Ollama 등)
8. **Self-hosted models** — llama.cpp, vLLM, Ollama 지원

### Claude Max 구독으로 API key 없이 가능?
- FAQ에 "Can I use Claude Max subscription without an API key" 항목 존재
- `setup-token` 방식 지원 → 별도 API key 없이 구독으로 사용 가능

### 무료로 시작하려면:
- 로컬 모델 (Ollama 등)으로 가능 (FAQ: "Is a local model OK for casual chats?")
- 하지만 tool-use 성능은 Claude/GPT 급이 최적

---

## 5. 첫 메시지까지 몇 단계인가?

### 최소 경로 (채널 연결 없이):
1. `curl -fsSL https://openclaw.ai/install.sh | bash` → 설치 + 온보딩 위자드 자동 시작
2. 위자드에서 API key 입력 + QuickStart 선택
3. `openclaw dashboard` → 브라우저에서 바로 채팅

**→ 실질적으로 3단계, 실행 시간 ~5분** (네트워크 속도에 따라)

### 채널 연결 포함:
4. 위자드에서 채널 설정 (Telegram/WhatsApp/Discord 등)
5. 채널에서 메시지 전송

---

## 6. macOS vs Linux vs Windows — 가장 쉬운 건?

### macOS (가장 쉬움 ⭐):
- **macOS App** 제공: GUI 온보딩, 클릭만으로 설정
- CLI도 동일하게 작동
- LaunchAgent로 데몬 자동 관리
- iMessage, AppleScript, 화면 녹화 등 macOS 전용 기능 풍부
- Apple Silicon/Intel 모두 지원

### Linux (두 번째로 쉬움):
- Installer script 한 줄이면 끝
- systemd user unit으로 데몬 관리
- VPS/Raspberry Pi에서도 OK
- WSL2 포함

### Windows (WSL2 강력 추천):
- **WSL2를 통해 Linux처럼 사용** 권장
- PowerShell 스크립트도 있지만 WSL2가 더 안정적
- 네이티브 Windows: `git not found` / `openclaw not recognized` 등 문제 가능 (FAQ에 트러블슈팅 있음)

---

## 7. 설치 후 확인 명령어

```bash
openclaw doctor        # 설정 문제 진단
openclaw status        # 게이트웨이 상태 확인
openclaw gateway status  # 게이트웨이 실행 여부
openclaw dashboard     # 브라우저 UI 열기
```

---

## 8. 추가 참고 정보

### 환경 변수:
- `OPENCLAW_HOME` — 홈 디렉토리 내부 경로 설정
- `OPENCLAW_STATE_DIR` — 상태 디렉토리 오버라이드
- `OPENCLAW_CONFIG_PATH` — 설정 파일 경로 오버라이드

### 업데이트:
- FAQ: "Can I ask OpenClaw to update itself?" → 에이전트에게 직접 요청 가능
- `npm update -g openclaw@latest`

### 문제 발생 시:
- `openclaw doctor` 실행
- FAQ: https://docs.openclaw.ai/help/faq
- 트러블슈팅: https://docs.openclaw.ai/gateway/troubleshooting

---

## 소스 URL

| 문서 | URL |
|------|-----|
| Getting Started | https://docs.openclaw.ai/start/getting-started |
| Install | https://docs.openclaw.ai/install |
| Onboarding Wizard (CLI) | https://docs.openclaw.ai/start/wizard |
| Onboarding (macOS App) | https://docs.openclaw.ai/start/onboarding |
| Onboarding Overview | https://docs.openclaw.ai/start/onboarding-overview |
| FAQ | https://docs.openclaw.ai/help/faq |
| Dashboard | https://docs.openclaw.ai/web/dashboard |
| Control UI | https://docs.openclaw.ai/web/control-ui |
