# OpenClaw 공식 문서 — 숨겨진 팁 & 고급 기능 모음

> 출처: docs.openclaw.ai 공식 문서 + 로컬 `/app/docs/` 소스 (2026-02-22 기준)
> 일반 사용자가 놓치기 쉬운 기능을 위주로 정리

---

## 1. 워크스페이스 파일 베스트 프랙티스

### SOUL.md — 페르소나의 영혼
- **의견을 가져라**: "Great question!" 같은 빈말 금지. 실질적으로 도움이 되는 성격을 부여
- **게스트 정신**: "누군가의 삶에 접근 권한을 가진 게스트"라는 철학. 존중과 조심스러움
- **진화 가능**: 에이전트가 직접 수정 가능하되, 변경 시 유저에게 알려야 함
- 공식 템플릿: "Be genuinely helpful, not performatively helpful"

### AGENTS.md — 운영 매뉴얼
- 매 세션 시작 시 자동 로드됨 (SOUL.md, USER.md와 함께)
- `memory/YYYY-MM-DD.md` (오늘 + 어제) 읽기를 여기서 지시
- **MEMORY.md는 메인 세션에서만** 로드 (그룹 채팅/공유 컨텍스트에서는 보안상 로드 금지)
- 그룹 채팅 행동 규칙 정의 장소 (언제 말할지, 리액션 규칙 등)

### USER.md — 유저 프로필
- 이름, 호칭, 대명사, 타임존, 메모 기록
- "dossier가 아닌 사람에 대한 이해를 구축"하라는 철학

### IDENTITY.md
- 에이전트 이름/이모지/바이브 저장
- `identity.emoji`가 ackReaction 기본값으로 사용됨
- `identity.name`이 mentionPatterns 기본값으로 파생

### BOOTSTRAP.md — 첫 실행 의식
- 새 워크스페이스에서만 생성됨
- 에이전트와 대화하며 정체성 설정 → 완료 후 삭제
- `agent.skipBootstrap: true`로 자동 생성 비활성화 가능

### 💡 숨겨진 팁: bootstrapMaxChars
```json5
{
  agents: { defaults: {
    bootstrapMaxChars: 20000,       // 파일당 최대
    bootstrapTotalMaxChars: 150000  // 전체 총합 최대
  }}
}
```
- 큰 TOOLS.md나 AGENTS.md가 잘리면 이 값을 조정
- `/context list`로 실제 injected 크기 확인 가능

---

## 2. HEARTBEAT.md 활용법

### 기본 동작
- 기본 30분마다 (Anthropic OAuth면 1h) 메인 세션에서 에이전트 턴 실행
- `HEARTBEAT_OK` 응답 시 메시지 미전달 (토큰 절약)
- **비어있는 HEARTBEAT.md는 하트비트 실행 자체를 스킵** (API 콜 절약!)

### 고급 설정
```json5
{
  agents: { defaults: { heartbeat: {
    every: "30m",
    target: "last",           // last | none | whatsapp | telegram | discord ...
    model: "openai/gpt-5.2-mini",  // 저렴한 모델로 하트비트 실행
    activeHours: { start: "08:00", end: "22:00" },  // 활동 시간대 제한
    includeReasoning: true,   // 디버깅용 reasoning 메시지 전달
    ackMaxChars: 300,         // HEARTBEAT_OK 후 허용 글자 수
    suppressToolErrorWarnings: true  // 도구 에러 경고 숨김
  }}}
}
```

### 💡 숨겨진 팁: 캐시 워밍
- Anthropic 캐시 TTL이 1h이면 하트비트를 `55m`으로 설정 → **캐시 재작성 비용 절약**
- 하트비트가 캐시를 계속 따뜻하게 유지
```yaml
agents:
  defaults:
    heartbeat:
      every: "55m"
    models:
      "anthropic/claude-opus-4-6":
        params:
          cacheRetention: "long"
```

### 💡 숨겨진 팁: 에이전트별 하트비트
- `agents.list[]`에 `heartbeat` 블록이 있으면 **그 에이전트만** 하트비트 실행
- 메인 에이전트는 하트비트 없이, ops 에이전트만 1시간마다 실행 가능

### 💡 숨겨진 팁: target: "none"
- 하트비트를 실행하되 외부 메시지는 보내지 않음
- 내부 상태 업데이트/메모리 관리에만 활용

---

## 3. 크론 잡 고급 활용

### Main vs Isolated 세션
| | Main 세션 | Isolated 세션 |
|---|---|---|
| 히스토리 | 공유 | 매번 새로 시작 |
| 컨텍스트 | 전체 | 없음 (깨끗한 시작) |
| 모델 | 메인 모델 | 오버라이드 가능 |
| 출력 | 하트비트 프롬프트 | announce 요약 (기본) |

### 핵심 패턴들

**원샷 리마인더 (20분 후):**
```bash
openclaw cron add --name "회의" --at "20m" --session main \
  --system-event "10분 후 스탠드업" --wake now --delete-after-run
```

**주간 딥 분석 (Opus + high thinking):**
```bash
openclaw cron add --name "주간 분석" --cron "0 6 * * 1" \
  --tz "Asia/Seoul" --session isolated \
  --message "프로젝트 진척 분석" --model opus --thinking high \
  --announce --channel discord --to "channel:123456"
```

**텔레그램 포럼 토픽으로 전달:**
```bash
--to "-1001234567890:topic:123"
```

### 💡 숨겨진 팁: 탑-오브-아워 스태거링
- 반복 크론 (`0 * * * *`)은 자동으로 0~5분 지연 분산
- `--exact`로 정확한 타이밍 강제 가능
- `--stagger 30s`로 명시적 스태거 윈도우 설정

### 💡 숨겨진 팁: 에이전트 바인딩
```bash
openclaw cron add --name "Ops" --cron "0 6 * * *" --session isolated \
  --message "큐 확인" --agent ops
```
- 멀티에이전트에서 특정 에이전트에 크론 잡 할당

### 💡 숨겨진 팁: 웹훅 전달
```json
{
  "delivery": {
    "mode": "webhook",
    "to": "https://example.com/hook"
  }
}
```
- 크론 결과를 외부 HTTP 엔드포인트로 직접 전달

---

## 4. 멀티에이전트 패턴

### 바인딩 우선순위 (most-specific wins)
1. `peer` 매칭 (정확한 DM/그룹/채널 ID)
2. `parentPeer` (스레드 상속)
3. `guildId + roles` (Discord 역할 라우팅)
4. `guildId` / `teamId`
5. `accountId` (정확)
6. 채널 레벨 (`accountId: "*"`)
7. 기본 에이전트 폴백

### 💡 숨겨진 팁: 채널별 모델 분리
```json5
{
  agents: { list: [
    { id: "chat", model: "anthropic/claude-sonnet-4-5" },
    { id: "opus", model: "anthropic/claude-opus-4-6" }
  ]},
  bindings: [
    { agentId: "chat", match: { channel: "whatsapp" } },
    { agentId: "opus", match: { channel: "telegram" } }
  ]
}
```
- WhatsApp은 빠른 모델, Telegram은 깊은 분석 모델

### 💡 숨겨진 팁: 하나의 WhatsApp 번호로 여러 사람 분리
```json5
{
  bindings: [
    { agentId: "alex", match: { channel: "whatsapp", peer: { kind: "direct", id: "+1555..." } } },
    { agentId: "mia", match: { channel: "whatsapp", peer: { kind: "direct", id: "+1556..." } } }
  ]
}
```

### 💡 숨겨진 팁: 가족 에이전트 (제한된 도구)
```json5
{
  id: "family",
  sandbox: { mode: "all", scope: "agent" },
  tools: {
    allow: ["read", "sessions_list", "session_status"],
    deny: ["write", "edit", "exec", "browser", "cron"]
  }
}
```

### 서브에이전트 오케스트레이션
- `sessions_spawn`으로 백그라운드 에이전트 실행
- 기본: 세션 도구 없음 (격리됨)
- `maxSpawnDepth: 2`로 중첩 허용 → 오케스트레이터 패턴
  - 메인 → 오케스트레이터 → 워커들
- Discord 스레드 바인딩: `thread: true` + `mode: "session"`
- 💡 **서브에이전트는 AGENTS.md + TOOLS.md만 주입** (SOUL.md, USER.md, HEARTBEAT.md 없음)
- 💡 서브에이전트 모델을 저렴하게 설정:
```json5
{ agents: { defaults: { subagents: { model: "anthropic/claude-sonnet-4-5" } } } }
```

### 💡 숨겨진 팁: 에이전트 간 메시징
```json5
{
  tools: { agentToAgent: { enabled: true, allow: ["home", "work"] } }
}
```
- 기본 비활성. 명시적으로 허용 + 화이트리스트 필요

---

## 5. 스킬 시스템

### 우선순위
1. `<workspace>/skills` (최고) → 2. `~/.openclaw/skills` → 3. 번들 스킬 (최저)
- 이름 충돌 시 워크스페이스 스킬이 승리

### ClawHub (스킬 마켓플레이스)
```bash
clawhub search "calendar"     # 검색
clawhub install my-skill      # 설치
clawhub update --all           # 전체 업데이트
clawhub sync --all             # 로컬 스킬 퍼블리시
```

### 커스텀 스킬 만들기
```markdown
---
name: my-skill
description: 내 커스텀 스킬
metadata: { "openclaw": { "requires": { "bins": ["python3"] }, "primaryEnv": "MY_API_KEY" } }
---
# 사용법
{baseDir}로 스킬 폴더 경로 참조 가능
```

### 💡 숨겨진 팁: 슬래시 커맨드로 직접 도구 디스패치
```markdown
---
command-dispatch: tool
command-tool: exec
command-arg-mode: raw
---
```
- 모델을 거치지 않고 바로 도구 실행

### 💡 숨겨진 팁: 스킬 토큰 비용 계산
```
total chars = 195 + Σ(97 + name + description + location)
```
- 스킬이 많으면 시스템 프롬프트 크기 증가 → 스킬 설명을 짧게!

### 💡 숨겨진 팁: 모델 호출 비활성화
```markdown
disable-model-invocation: true
```
- 슬래시 커맨드로만 사용 가능, 모델 프롬프트에서 제외 (토큰 절약)

### 💡 숨겨진 팁: 원격 macOS 노드에서 스킬 실행
- Linux 게이트웨이 + macOS 노드 연결 → macOS 전용 스킬 자동 활성화
- `nodes.run`으로 실행

---

## 6. 메모리 관리

### 자동 메모리 플러시 (컴팩션 전)
- 세션이 컴팩션에 가까워지면 **자동으로 사일런트 턴** 실행
- "지금 중요한 것을 memory/에 저장해"라고 에이전트에게 알림
- `NO_REPLY`로 유저에게 보이지 않음
```json5
{
  compaction: { memoryFlush: {
    enabled: true,
    softThresholdTokens: 4000
  }}
}
```

### memory_search — 시맨틱 검색
- 기본 활성, MEMORY.md + memory/*.md 벡터 인덱싱
- 제공자 자동 선택: local → openai → gemini → voyage 순
- 💡 **하이브리드 검색**: BM25 (키워드) + 벡터 (시맨틱) 결합
```json5
{
  memorySearch: { query: { hybrid: {
    enabled: true,
    vectorWeight: 0.7,
    textWeight: 0.3
  }}}
}
```

### 💡 숨겨진 팁: MMR 리랭킹 (다양성)
- 유사한 결과 중복 방지. 일간 노트에서 같은 내용 반복 제거
```json5
{ mmr: { enabled: true, lambda: 0.7 } }
```

### 💡 숨겨진 팁: 시간 감쇠 (최신 우선)
- 30일 반감기: 오늘 메모 100% → 30일 전 50% → 90일 전 12.5%
- `MEMORY.md`와 비날짜 파일은 감쇠 없음 (상록 파일)
```json5
{ temporalDecay: { enabled: true, halfLifeDays: 30 } }
```

### 💡 숨겨진 팁: QMD 백엔드 (실험적)
- `memory.backend = "qmd"` → BM25 + 벡터 + 리랭킹 로컬 사이드카
- 세션 트랜스크립트 인덱싱 가능 (`sessions.enabled: true`)
- 완전 로컬 실행 (Ollama 불필요, node-llama-cpp 사용)

### 💡 숨겨진 팁: 세션 메모리 검색
```json5
{
  memorySearch: {
    experimental: { sessionMemory: true },
    sources: ["memory", "sessions"]
  }
}
```
- 과거 대화 내용까지 `memory_search`로 검색 가능

### 💡 숨겨진 팁: 추가 메모리 경로
```json5
{ memorySearch: { extraPaths: ["../team-docs", "/srv/shared-notes"] } }
```
- 워크스페이스 외부 마크다운도 인덱싱

---

## 7. 채널별 차이점

### Discord
- **컴포넌트 v2**: 버튼, 셀렉트, 모달 지원
- 스레드 바인딩 (`threadBindings`): 서브에이전트를 스레드에 연결
- 보이스 채널 지원 (`voice.enabled`)
- `maxLinesPerMessage: 17` — 길면 자동 분할
- 리액션 알림: `off | own | all | allowlist`
- 스트리밍: `off | partial | block | progress`
- 💡 마크다운 테이블 사용 불가 → 불릿 리스트 사용
- 💡 링크 여러 개면 `<>`로 감싸서 임베드 억제

### Telegram
- 포럼 토픽 지원 (`-1001234567890:topic:99`)
- 토픽별 systemPrompt, skills, requireMention 설정
- 커스텀 봇 메뉴 커맨드 (`customCommands`)
- 프록시 지원 (`proxy: "socks5://localhost:9050"`)
- 웹훅 모드 지원
- 💡 스트리밍 프리뷰: `sendMessage` + `editMessageText`

### WhatsApp
- 셀프챗 모드: 자기 번호를 `allowFrom`에 포함
- 멀티 계정: `accounts: { personal: {}, biz: {} }`
- 읽음 표시 제어 (`sendReadReceipts`)
- 💡 그룹에서 자기 메시지의 @멘션은 무시됨 → `mentionPatterns` 텍스트 패턴 사용

### Slack
- 네이티브 스트리밍 (`nativeStreaming: true`)
- 슬래시 커맨드 (`slashCommand.enabled`)
- 소켓 모드 + HTTP 모드 지원
- 스레드 세션 격리 (`thread.historyScope: "thread"`)

### Signal / iMessage / Google Chat
- Signal: 리액션 알림 + allowlist 지원
- iMessage: SSH 래퍼 + 원격 Mac 지원, 서비스 자동 감지
- Google Chat: 서비스 계정 JSON + 웹훅 모드

### 💡 숨겨진 팁: 채널별 모델 오버라이드
```json5
{
  channels: { modelByChannel: {
    discord: { "123456789": "anthropic/claude-opus-4-6" },
    telegram: { "-1001234567890:topic:99": "anthropic/claude-sonnet-4-6" }
  }}
}
```

---

## 8. 보안 강화

### 즉시 실행: security audit
```bash
openclaw security audit          # 기본 검사
openclaw security audit --deep   # 라이브 Gateway 프로브 포함
openclaw security audit --fix    # 자동 수정 가능한 항목 수정
openclaw security audit --json   # JSON 출력
```

### 60초 강화 베이스라인
```json5
{
  gateway: { mode: "local", bind: "loopback",
    auth: { mode: "token", token: "long-random-token" } },
  session: { dmScope: "per-channel-peer" },
  tools: {
    profile: "messaging",
    deny: ["group:automation", "group:runtime", "group:fs", "sessions_spawn"],
    exec: { security: "deny", ask: "always" },
    elevated: { enabled: false }
  }
}
```

### 💡 숨겨진 팁: 도구 프로필 (base allowlist)
| 프로필 | 포함 도구 |
|---|---|
| `minimal` | session_status만 |
| `coding` | fs, runtime, sessions, memory, image |
| `messaging` | message, sessions 일부, session_status |
| `full` | 제한 없음 |

### 💡 숨겨진 팁: 프로바이더별 도구 제한
```json5
{
  tools: { byProvider: {
    "google-antigravity": { profile: "minimal" },
    "openai/gpt-5.2": { allow: ["group:fs", "sessions_list"] }
  }}
}
```
- 특정 모델에만 제한된 도구 세트 제공

### 💡 숨겨진 팁: mDNS 정보 노출
- 기본으로 `_openclaw-gw._tcp` 브로드캐스트
- `cliPath`, `sshPort` 등 노출 가능
- `discovery.mdns.mode: "minimal"` 또는 `"off"`로 비활성화
- 환경변수: `OPENCLAW_DISABLE_BONJOUR=1`

### 💡 숨겨진 팁: 루프 감지
```json5
{
  tools: { loopDetection: {
    enabled: true,
    warningThreshold: 10,
    criticalThreshold: 20,
    globalCircuitBreakerThreshold: 30
  }}
}
```
- 무한 도구 호출 루프 자동 감지 및 차단

### 💡 숨겨진 팁: 위험한 도구 격리
```json5
{ tools: { deny: ["gateway", "cron", "sessions_spawn", "sessions_send"] } }
```
- `gateway`는 config 변경 가능, `cron`은 지속적 잡 생성 가능 → 신뢰 못하는 에이전트에서 차단

---

## 9. 성능 최적화 & 토큰 절약

### 컨텍스트 프루닝 (cache-ttl)
```json5
{
  contextPruning: {
    mode: "cache-ttl",
    ttl: "1h",
    keepLastAssistants: 3,
    softTrim: { maxChars: 4000 },
    hardClear: { enabled: true }
  }
}
```
- 오래된 도구 결과를 메모리에서만 정리 (디스크 불변)
- Anthropic 캐시 TTL 만료 후 다음 요청의 cacheWrite 비용 절감

### 컴팩션 모드
- `default`: 기본 요약
- `safeguard`: 긴 히스토리를 청크별 요약 (더 안전)

### 이미지 최적화
```json5
{ agents: { defaults: { imageMaxDimensionPx: 800 } } }
```
- 기본 1200px → 낮추면 비전 토큰 비용 절감
- 스크린샷 무거운 세션에 효과적

### 💡 숨겨진 팁: `/context list`와 `/context detail`
- 시스템 프롬프트, 스킬, 도구 스키마의 실제 크기 확인
- 어디서 토큰이 소모되는지 디버깅

### 💡 숨겨진 팁: `/usage tokens` 또는 `/usage full`
- 매 응답마다 토큰 사용량 + 예상 비용 표시
- OAuth는 비용 숨김 (토큰만 표시)

### 💡 숨겨진 팁: 블록 스트리밍 + humanDelay
```json5
{
  blockStreamingDefault: "on",
  humanDelay: { mode: "natural" }  // 800-2500ms 랜덤 딜레이
}
```
- 더 자연스러운 응답 느낌

### 💡 숨겨진 팁: maxConcurrent
```json5
{ agents: { defaults: { maxConcurrent: 3 } } }
```
- 동시 에이전트 런 수 제한 (기본 1). 여러 채팅 동시 처리 시 증가

### 💡 숨겨진 팁: Anthropic 1M 컨텍스트 베타
```json5
{ agents: { defaults: { models: {
  "anthropic/claude-opus-4-6": { params: { context1m: true } }
}}}}
```
- 100만 토큰 컨텍스트 윈도우 활성화

---

## 10. 숨겨진 기능 모음

### BOOT.md — 게이트웨이 시작 시 실행
- `hooks.internal.enabled: true` + `boot-md` 훅 활성화 필요
- 게이트웨이 재시작마다 실행되는 체크리스트

### 훅 시스템
- `command:new`, `command:reset`, `command:stop` 이벤트 리스닝
- `message:received`, `message:sent` 메시지 이벤트
- `agent:bootstrap` — 부트스트랩 파일 동적 수정 가능
- `gateway:startup` — 게이트웨이 시작 시 실행
- 💡 **bootstrap-extra-files 훅**: glob 패턴으로 추가 워크스페이스 파일 주입
- 💡 **session-memory 훅**: `/new` 시 자동으로 세션 컨텍스트를 memory/에 저장

### 멀티 게이트웨이 (동일 호스트)
```bash
openclaw --profile main gateway --port 18789
openclaw --profile rescue gateway --port 19001
```
- 프로필로 완전 격리 (config, state, workspace, 포트)
- 포트 간격 20 이상 유지 (파생 포트 충돌 방지)
- 💡 **레스큐 봇**: 메인 봇이 다운됐을 때 디버깅/설정 변경용

### OAuth 토큰 싱크
- `auth-profiles.json`이 단일 진실 원천
- Claude Code와 OpenClaw가 같은 토큰을 사용하면 서로 로그아웃 → **별도 에이전트** 권장
- `/model Opus@anthropic:work`로 세션별 프로필 오버라이드

### identityLinks (크로스채널 세션 공유)
```json5
{
  session: { identityLinks: {
    alice: ["telegram:123456789", "discord:987654321012345678"]
  }}
}
```
- 여러 채널에서 같은 사람의 DM을 하나의 세션으로 병합

### 인바운드 디바운스
```json5
{
  messages: { inbound: {
    debounceMs: 2000,
    byChannel: { whatsapp: 5000 }
  }}
}
```
- 빠른 연속 메시지를 하나의 에이전트 턴으로 배칭 (토큰 절약)

### 메시지 큐 모드
```json5
{ messages: { queue: { mode: "collect", debounceMs: 1000, cap: 20 } } }
```
- `steer`: 진행 중인 에이전트에게 새 메시지 전달
- `collect`: 대기열에 수집 후 한 번에 처리
- `interrupt`: 현재 실행 중단하고 새 메시지 처리

### 응답 프리픽스 템플릿
```json5
{ messages: { responsePrefix: "[{model}|{thinkingLevel}] " } }
```
- `{model}`, `{provider}`, `{thinkingLevel}`, `{identity.name}` 변수 사용 가능

### CLI 백엔드 (텍스트 전용 폴백)
```json5
{
  agents: { defaults: { cliBackends: {
    "claude-cli": { command: "/opt/homebrew/bin/claude" }
  }}}
}
```
- API 프로바이더 실패 시 로컬 CLI를 백업으로 사용 (도구 없음)

### 세션 유지보수
```json5
{
  session: { maintenance: {
    mode: "enforce",
    pruneAfter: "30d",
    maxEntries: 500,
    rotateBytes: "10mb"
  }}
}
```
- 오래된 세션 자동 정리

### 세션 리셋 타입별 설정
```json5
{
  session: { resetByType: {
    thread: { mode: "daily", atHour: 4 },
    direct: { mode: "idle", idleMinutes: 240 },
    group: { mode: "idle", idleMinutes: 120 }
  }}
}
```

### 💡 숨겨진 팁: sendPolicy (세션 전송 제한)
```json5
{
  session: { sendPolicy: {
    rules: [{ action: "deny", match: { channel: "discord", chatType: "group" } }],
    default: "allow"
  }}
}
```
- 특정 채널/타입에서 에이전트 메시지 전송 차단

### 💡 숨겨진 팁: sessions visibility
```json5
{ tools: { sessions: { visibility: "self" } } }
```
- 공유 에이전트에서 크로스세션 브라우징 방지

### 💡 숨겨진 팁: Lobster (워크플로우 런타임)
- 결정론적 파이프라인 + 승인 게이트
- `needs_approval` → `resumeToken`으로 재개
- `tools.alsoAllow: ["lobster"]`로 활성화

### 💡 숨겨진 팁: openclaw doctor
```bash
openclaw doctor                    # 전반적 건강 체크
openclaw doctor --generate-gateway-token  # 토큰 자동 생성
```
- 여분 워크스페이스 디렉토리 감지
- 파일 권한 문제 감지
- 레거시 인증 마이그레이션

### 💡 숨겨진 팁: Formal Verification
- `/security/formal-verification/` — 보안 모델의 형식 검증 문서
- 고급 보안 분석용

---

## 11. 빠른 참조 — 유용한 슬래시 커맨드

| 커맨드 | 설명 |
|---|---|
| `/status` | 세션 상태 + 토큰 사용량 + 예상 비용 |
| `/context list` | 주입된 파일 크기 + 시스템 프롬프트 크기 |
| `/context detail` | 스킬/도구별 상세 크기 |
| `/usage tokens` | 매 응답 토큰 푸터 |
| `/usage cost` | 로컬 비용 요약 |
| `/compact` | 수동 컴팩션 (명령 포함 가능) |
| `/model opus` | 세션 모델 변경 |
| `/think high` | 사고 레벨 변경 |
| `/new` | 새 세션 |
| `/subagents list` | 서브에이전트 목록 |
| `/subagents spawn <agentId> <task>` | 서브에이전트 생성 |
| `/focus` / `/unfocus` | Discord 스레드 바인딩 |
| `/elevated on` | 호스트 exec 모드 |

---

*이 문서는 OpenClaw 공식 문서를 기반으로 일반 사용자가 놓치기 쉬운 고급 기능과 숨겨진 팁을 발굴하여 정리한 것입니다.*
