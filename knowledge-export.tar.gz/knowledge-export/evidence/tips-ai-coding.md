# AI 코딩 도구 사용 팁 — 2026년 2월 기준

> 수집일: 2026-02-22 | 출처: Cursor Blog, OpenAI Codex Docs, Devin Docs, Claude Code Docs, GitHub Blog, Terminal-Bench 2.0 Leaderboard 등

---

## 목차
1. [Cursor 팁](#1-cursor-팁)
2. [Claude Code (Anthropic) 팁](#2-claude-code-anthropic-팁)
3. [OpenAI Codex CLI 팁](#3-openai-codex-cli-팁)
4. [Devin (Cognition) 팁](#4-devin-cognition-팁)
5. [GitHub Copilot / Agent HQ 팁](#5-github-copilot--agent-hq-팁)
6. [도구 간 비교 / 선택 가이드](#6-도구-간-비교--선택-가이드)
7. [바이브 코딩 전반 팁](#7-바이브-코딩-전반-팁)
8. [.cursorrules / AGENTS.md 작성법](#8-cursorrules--agentsmd-작성법)
9. [비용 비교](#9-비용-비교)
10. [Terminal-Bench 2.0 리더보드](#10-terminal-bench-20-리더보드)

---

## 1. Cursor 팁

### 2026년 최신 기능 (1~2월)

| 날짜 | 기능 | 요약 |
|---|---|---|
| Feb 18 | **Agent Sandboxing** | macOS(Seatbelt), Linux(Landlock+seccomp), Windows(WSL2) 기반 샌드박스. 에이전트가 자유롭게 실행하되, 네트워크 등 외부 접근시만 승인 요청. 중단 40% 감소 |
| Feb 17 | **Marketplace (플러그인)** | Amplitude, AWS, Figma, Linear, Stripe 등 파트너 플러그인. Skills, Subagents, MCP servers, Hooks, Rules 번들 |
| Feb 17 | **Stripe 사례** | 3,000명 엔지니어에 Cursor 프리인스톨. Rules로 코드베이스 컨텍스트 제공. 신입도 첫날 PR 가능 |
| Feb 13 | **Box 사례** | 85%+ 엔지니어가 매일 사용. 로드맵 처리량 30-50% 증가, 마이그레이션 작업 80-90% 감소 |
| Feb 12 | **Long-Running Agents 확장** | Ultra/Teams/Enterprise에서 cursor.com/agents로 이용 가능. 36시간짜리 채팅 플랫폼 구축, 30시간 모바일 앱 포팅 등 사례 |
| Feb 11 | **사용량 증가** | Auto+Composer 풀과 API 풀 분리. Composer 1.5는 3x 한도 (프로모 기간 6x) |
| Feb 9 | **Composer 1.5** | RL 20x 스케일링으로 학습. 쉬운 문제는 빠르게, 어려운 문제는 깊게 사고. Self-summarization으로 긴 컨텍스트 유지. Terminal-Bench 2.0에서 Sonnet 4.5보다 높은 점수 |
| Feb 6 | **NVIDIA 사례** | 30,000명 개발자 사용, 커밋 코드량 3x 증가. 코드 생성부터 리뷰, 테스트, 디버깅, 배포까지 SDLC 전체에 활용 |
| Feb 5 | **Self-Driving Codebases** | 다중 에이전트 연구 프리뷰. 1주간 ~1,000 커밋/시간, 1,000만+ 도구 호출. 웹 브라우저를 에이전트만으로 제작 |
| Jan 27 | **Secure Codebase Indexing** | Merkle tree 기반 팀원 인덱스 재사용. 99th percentile: 4시간→21초 |

### 핵심 팁 10가지

1. **Rules는 짧고 명확하게** — 500줄 이하. 에이전트가 이미 아는 것(npm, git, 일반 스타일)은 적지 말 것. 반복 실수할 때만 규칙 추가
2. **Marketplace 플러그인 활용** — Stripe(결제), Figma(디자인→코드), Linear(이슈), AWS/Vercel(배포) 연동으로 편집기 안에서 전체 SDLC 처리
3. **Sandbox 활성화** — 에이전트 자동 승인 시 보안 위험 줄임. 승인 피로 없이 안전하게 자동 실행
4. **Long-Running Agents로 큰 작업 위임** — 밤새 돌리고 아침에 PR 확인. "가능한지 모르겠는데 궁금" 류의 탐색에 최적
5. **Composer 1.5 적극 활용** — Auto+Composer 풀로 사용량 대폭 증가. 일상 에이전트 코딩에 비용 효율적
6. **병렬 에이전트 실행** — 여러 에이전트를 동시에 돌려 다른 접근법 비교. Stripe는 이 워크플로우를 팀 내 전파
7. **경험 많은 개발자일수록 더 효과적** — Stripe 사례에서 오래 근속한 엔지니어가 가장 높은 생산성 향상 (코드베이스 맥락을 이미 알기 때문)
8. **코드 리뷰 프로세스 적응** — AI가 생성한 코드량이 많아지므로, LLM 기반 리뷰어로 복잡한 메서드/위험 파일 자동 플래그
9. **Secure Indexing으로 대형 코드베이스 즉시 사용** — 팀원 인덱스를 재사용해 수 시간의 초기 인덱싱 제거
10. **NVIDIA 스타일: SDLC 전체 자동화** — 커스텀 Rules로 git flow(브랜치 생성→커밋→CI 디버깅→이슈 트래킹) 완전 자동화

### Self-Driving Codebases 상세

Cursor의 다중 에이전트 시스템 설계 진화:

- **초기: 동등한 에이전트 + 공유 상태 파일** → 실패. 락 경합, 소극적 작업 선택
- **역할 분리(Planner→Executor→Workers→Judge)** → 개선되었으나 가장 느린 워커에 병목
- **연속 실행자(Continuous Executor)** → 동적이지만 역할 과부하로 병리적 행동
- **최종 설계:**
  - **Root Planner**: 전체 범위 소유, 직접 코딩 안 함, 작업 분배
  - **Subplanners**: 재귀적 분할, 좁은 범위의 완전 소유
  - **Workers**: 할당 작업만 수행, 다른 에이전트와 통신 없음, 자체 repo 복사본에서 작업
  - **Handoff**: 작업 결과 + 우려사항/피드백을 상위 Planner에게 전달
- **핵심 학습:**
  - 100% 커밋 정확도 강요 시 처리량 급감 → 일정 오류율을 허용하고 다른 에이전트가 수정하도록 신뢰
  - 동기화 오버헤드보다 시스템 단순성이 더 중요
  - 프로젝트 구조(모놀리스→크레이트 분할)가 토큰/커밋 처리량에 직접 영향
  - 명확한 지침이 결정적: "많은 태스크 생성" < "20-100개 태스크 생성"
  - 제약이 지시보다 효과적: "TODO 금지, 부분 구현 금지" > "구현을 완료하세요"
  - 모델을 "코드를 잘 아는 신입"처럼 대하라: 모델이 이미 아는 것은 지시하지 말고, 모르는 것(도메인/프로세스)만 알려줌

---

## 2. Claude Code (Anthropic) 팁

### 최신 기능

- **다중 환경**: 터미널 CLI, VS Code/Cursor 확장, 데스크톱 앱, 웹(claude.ai/code), JetBrains 플러그인
- **Agent SDK**: 커스텀 에이전트 구축 가능
- **Sub-agents**: 병렬 작업을 위한 전용 컨텍스트의 하위 에이전트 생성
- **Skills**: `.claude/skills/`에 `SKILL.md`로 도메인 지식/반복 워크플로우 정의
- **Hooks**: 파일 편집 후 eslint 자동 실행, 특정 폴더 쓰기 차단 등 결정론적 동작
- **MCP 서버**: Notion, Figma, DB, Jira, Slack 등 외부 도구 연결
- **Chrome 확장**: 브라우저에서 UI 변경 검증
- **Slack 통합**: `@Claude`로 버그 리포트→PR 자동화
- **Teleport**: 웹 세션→터미널, 터미널→데스크톱 앱으로 세션 이동

### 핵심 팁

1. **CLAUDE.md는 짧고 핵심만** — "이걸 제거하면 Claude가 실수하나?" 테스트. 너무 길면 무시됨
2. **`/init`으로 시작** — 프로젝트 분석해서 자동 CLAUDE.md 생성
3. **검증 수단 제공이 최우선** — 테스트, 스크린샷, 예상 출력 포함. Claude가 자체 검증할 수 있으면 성능 극적 향상
4. **탐색→계획→구현→커밋 순서** — Plan Mode로 탐색/계획(코드 변경 없음), 이후 Normal Mode로 구현
5. **컨텍스트 창이 핵심 자원** — 가득 차면 성능 저하. 작업 단위를 적절히 분리
6. **CLI 도구 활용** — `gh`, `aws`, `gcloud` 등을 Claude에게 사용하도록 지시. API보다 효율적
7. **`@` 파일 참조 > 내용 복사** — Rules/CLAUDE.md에서 파일 직접 참조로 짧고 최신 상태 유지
8. **강조 표현으로 준수율 향상** — "IMPORTANT", "YOU MUST" 등 사용
9. **중첩 CLAUDE.md** — `frontend/CLAUDE.md`, `backend/CLAUDE.md`로 디렉토리별 특화 지침
10. **Hooks > CLAUDE.md 지시** — 반드시 실행해야 하는 것(lint, format)은 Hook으로. CLAUDE.md는 자문 역할

### Terminal-Bench 2.0 성적
- Claude Code + Opus 4.6: **58.0%** (26위)
- Claude Code + Opus 4.5: **52.1%** (34위)
- Claude Code + Sonnet 4.5: **40.1%** (54위)

→ Claude Code 자체보다 **서드파티 하니스**(Factory Droid, KRAFTON Terminus-KIRA 등)가 Claude 모델을 더 잘 활용

---

## 3. OpenAI Codex CLI 팁

### 최신 기능

- **Codex CLI**: Rust 기반 로컬 터미널 에이전트. `npm i -g @openai/codex` 또는 `brew install --cask codex`
- **Codex Web**: chatgpt.com/codex — 클라우드 기반 에이전트
- **Codex IDE**: VS Code, Cursor, Windsurf 확장
- **Codex Desktop App**: `codex app` 명령으로 데스크톱 경험
- **Multi-agent (실험적)**: 복잡한 작업 병렬화
- **Web Search**: 최신 정보를 위한 웹 검색 내장
- **이미지 입력**: 스크린샷/디자인 스펙 첨부
- **로컬 코드 리뷰**: 커밋 전 별도 Codex 에이전트가 리뷰
- **MCP 지원**: 서드파티 도구/컨텍스트 연결
- **Approval Modes**: suggest(보기만) / auto-edit(파일 편집 자동) / full-auto(모두 자동) 세 단계

### ChatGPT 플랜 포함

Plus, Pro, Business, Edu, Enterprise 플랜에 Codex 포함. API 키로도 사용 가능.

### 핵심 팁

1. **GPT-5.3-Codex가 현재 최강** — Terminal-Bench 2.0에서 Simple Codex + GPT-5.3-Codex = **75.1%** (1위!)
2. **`/model`로 모델/추론 수준 전환** — 작업 복잡도에 따라 모델 변경
3. **AGENTS.md 지원** — 프로젝트 루트에 AGENTS.md 배치하면 Codex가 자동으로 읽음
4. **스크립팅 가능** — `codex exec`로 반복 워크플로우 자동화
5. **Codex Cloud Task** — 터미널에서 클라우드 태스크 시작, 결과 diff 적용
6. **GPT-5.2가 장기 자율 작업에 탁월** — Cursor의 Self-Driving 연구에서 확인: 지시 따르기, 집중 유지, 드리프트 방지에서 Opus 4.5보다 우수

### Terminal-Bench 2.0 성적 (Codex 관련)
| 에이전트 | 모델 | 점수 |
|---|---|---|
| Simple Codex | GPT-5.3-Codex | **75.1%** (1위) |
| Codex CLI | GPT-5.2 | 62.9% |
| Codex CLI | GPT-5.1-Codex-Max | 60.4% |
| Codex CLI | GPT-5.1-Codex | 57.8% |
| Codex CLI | GPT-5 | 49.6% |

---

## 4. Devin (Cognition) 팁

### Devin이 잘하는 것

1. **병렬 소규모 작업** — 리팩토링, 프론트엔드 버그, 테스트 커버리지, CI 실패 수정, CVE 대응
2. **코드 마이그레이션/현대화** — JS→TS, Angular 16→18, 모노레포→서브모듈, 피처 플래그 제거
3. **반복 엔지니어링 작업** — PR 리뷰, 코드베이스 Q&A, 버그 재현, 유닛 테스트, 문서 유지
4. **고객 엔지니어링** — 새 API 통합, 데모 구축, 프로토타이핑, 내부 도구 구축

### Nubank 사례 (주요 증거)
- 6백만 줄 모놀리스 ETL 마이그레이션
- 엔지니어링 시간 **8-12x 효율 향상**, 비용 **20x 절감**
- 파인튜닝 후 작업 완료율 2배, 속도 4배 개선 (40분→10분/서브태스크)
- Devin이 자체 도구/스크립트를 만들어 반복 단계 최적화

### 핵심 팁

1. **주니어 엔지니어 수준 작업 할당** — 판단이 명확하고, 검증이 쉬운(CI 통과 확인) 작업
2. **Ask Devin으로 사전 범위 설정** — 상세 스펙을 직접 쓰는 대신 대화형으로 프롬프트 구성
3. **세션은 짧게(XS, S, M)** — 길고 큰 세션은 성능 저하
4. **Slack/Teams에서 직접 태그** — <30분짜리 작업을 백로그에 쌓지 말고 바로 위임
5. **Knowledge 기능 활용** — 이전 세션에서 배운 것을 기억하도록 지식 승인
6. **파인튜닝 효과 큼** — 회사 특화 태스크에 예제를 제공하면 완료율/속도 대폭 향상

### 제한사항
- **대규모 도전**: 작고 명확한 범위가 좋음. 큰 프로젝트는 여러 세션으로 분할
- **UI 미학**: 기능적 프론트엔드는 만들지만 디자인 감각은 부족
- **모바일 개발**: 테스트할 폰이 없음
- **보안**: Secrets Manager로 자격 증명 관리

---

## 5. GitHub Copilot / Agent HQ 팁

### Agent HQ (2026-02-04)

- **Claude, Codex를 GitHub/VS Code 내에서 직접 실행** — Copilot Pro+ 또는 Enterprise 구독
- 동일 이슈에 여러 에이전트 할당, 접근 방식 비교 가능
- 에이전트가 생성한 변경은 **Draft PR + 코멘트**로 표시 → 기존 리뷰 프로세스 그대로 사용
- Google, Cognition(Devin), xAI 등 추가 에이전트 곧 지원 예정

### Agent Mode (VS Code)

- 자체 출력과 결과를 반복 검증하는 에이전틱 모드
- 터미널 명령 제안 및 실행 요청
- 자가 치유(self-healing): 런타임 에러 자동 분석/수정
- 명시하지 않은 추가 작업도 추론해서 수행

### 팀/엔터프라이즈 기능
- **Agent Controls**: 조직 차원의 에이전트/모델 정책 관리
- **Code Quality**: 변경 코드의 유지보수성/신뢰성 자동 평가
- **자동 1차 리뷰**: Copilot이 개발자가 보기 전 초기 문제 처리
- **Impact Metrics**: 조직 전체 AI 사용량/영향도 대시보드
- **감사 로그**: 에이전트 생성 작업의 추적성 보장

### 핵심 팁

1. **에이전트 비교 활용** — 같은 문제에 Copilot/Claude/Codex를 동시 할당, 아키텍처/엣지 케이스/구현 관점 비교
2. **AGENTS.md / .github/copilot-instructions.md** — 레포 규칙과 컨벤션을 에이전트가 인지하도록
3. **Draft PR 기반 워크플로** — 에이전트 결과를 팀원 PR처럼 리뷰
4. **이슈→PR 자동화** — 이슈를 Copilot에 할당하면 환경 셋업→코드 수정→테스트→PR 생성까지 자동

---

## 6. 도구 간 비교 / 선택 가이드

### 각 도구의 강점

| 도구 | 최적 사용처 | 약점 |
|---|---|---|
| **Cursor** | 일상적 에디터 내 에이전트 코딩. 거대 코드베이스 이해. Long-running 대형 작업. 자체 모델(Composer 1.5) | 독립 실행 도구가 아닌 에디터 종속. 무료 플랜 제한적 |
| **Claude Code** | 터미널 기반 깊은 코드베이스 탐색. 멀티-서피스(터미널/IDE/웹/데스크톱). Skills/Hooks로 커스터마이징 | Terminal-Bench에서 자체 하니스 점수가 서드파티 대비 낮음 |
| **Codex CLI** | 터미널 코딩 에이전트 벤치마크 1위(GPT-5.3). ChatGPT 플랜 포함. 오픈소스(Apache-2.0) | 에디터 통합은 별도 설치 필요 |
| **Devin** | 대규모 마이그레이션/리팩토링. 병렬 소규모 작업 대량 처리. Slack/Teams 통합. 파인튜닝 가능 | 큰 단일 작업에서 성능 저하. UI 감각 부족. 가격 높음 |
| **GitHub Copilot Agent HQ** | 멀티-에이전트(Copilot+Claude+Codex) 비교/병행. GitHub 네이티브 워크플로. 팀 거버넌스 | Pro+ 또는 Enterprise 필요. 아직 프리뷰 단계 |

### 어떤 상황에 어떤 도구?

- **에디터에서 빠른 반복 작업** → Cursor (Composer 1.5 또는 Auto 모드)
- **터미널에서 깊은 디버깅/탐색** → Claude Code 또는 Codex CLI
- **밤새 큰 PR 만들기** → Cursor Long-Running Agents
- **백로그 소규모 작업 대량 처리** → Devin (병렬 세션)
- **PR 리뷰/이슈 자동화** → GitHub Copilot Agent HQ + Devin
- **벤치마크 최고 성능** → Codex CLI + GPT-5.3-Codex
- **팀 전체 거버넌스** → GitHub Agent HQ + Cursor Enterprise

### 모델별 특성 (Cursor Self-Driving 연구에서)

- **GPT-5.2**: 장기 자율 작업에 최고. 지시 정확히 따르고, 집중 유지, 드리프트 방지
- **Opus 4.5**: 빨리 멈추고 단축키 사용 경향. 제어권 빠르게 반환
- **역할별 최적 모델이 다름**: GPT-5.2가 Planner로 더 좋고, GPT-5.1-Codex는 코딩 특화지만 계획 능력은 약함

---

## 7. 바이브 코딩 전반 팁

### 바이브 코딩이란?
자연어로 의도를 설명하면 AI가 구현하는 개발 방식. 코드를 직접 작성하기보다 AI와 대화하며 방향을 잡는 것.

### 핵심 원칙

1. **구체적으로 요청** — "로그인 버그 수정해"보다 "세션 타임아웃 후 로그인 실패. src/auth/의 토큰 리프레시 확인. 재현 테스트 작성 후 수정"
2. **검증 수단 항상 제공** — 테스트 케이스, 스크린샷, 예상 출력. AI가 자체 검증할 수 있으면 퀄리티 극적 향상
3. **탐색→계획→구현→커밋** — 바로 코딩하지 말고 먼저 코드베이스 탐색 + 계획 수립
4. **작은 단위로 쪼개기** — 큰 작업을 10-100개의 구체적 서브태스크로 분해
5. **기존 패턴 참조** — "HotDogWidget.php 패턴을 따라 캘린더 위젯 구현해"
6. **제약으로 안내** — "TODO 금지, 부분 구현 금지, 외부 의존성 금지"가 "완성해"보다 효과적
7. **구체적 수량 제시** — "많이 생성"은 3개만 나옴. "20-100개 생성"으로 명시
8. **에이전트를 '코드를 잘 아는 신입'으로 대하라** — 일반 엔지니어링은 알지만, 당신의 코드베이스/프로세스는 모름
9. **병렬 에이전트로 속도/비용 최적화** — 여러 접근을 동시에 시도하고 가장 좋은 결과 채택
10. **결과를 항상 리뷰** — AI 생성 코드도 사람 PR처럼 리뷰. LLM 기반 리뷰어 병행 추천

### 실전 워크플로우

```
1. 아침에 TODO 리스트에서 작업 분류
   - 작은 것(30분 이하): Devin에 Slack으로 위임
   - 중간(1-4시간): Cursor Agent로 직접 작업
   - 큰 것(하루 이상): Cursor Long-Running Agent에 위임

2. 에디터에서:
   - Plan Mode로 탐색/계획
   - Normal Mode로 구현
   - 테스트 실행 확인

3. 리뷰:
   - AI 생성 코드를 Copilot/Codex로 1차 리뷰
   - 인간 리뷰어가 2차 리뷰

4. 저녁에:
   - 큰 작업의 Long-Running Agent 결과 확인
   - 다음날 할 작업 Devin에 미리 위임
```

---

## 8. .cursorrules / AGENTS.md 작성법

### .cursorrules (레거시 — 곧 deprecated)
- `.cursorrules` 파일은 프로젝트 루트에 배치
- **권장: `.cursor/rules/`로 마이그레이션** 또는 `AGENTS.md` 사용

### Project Rules (`.cursor/rules/`)

```markdown
# .cursor/rules/react-patterns.mdc
---
description: "React 컴포넌트 표준"
globs: "src/components/**/*.tsx"
alwaysApply: false
---

- Tailwind으로 스타일링
- Framer Motion으로 애니메이션
- 컴포넌트 네이밍: PascalCase
- Props 인터페이스를 파일 상단에
```

### 규칙 유형 4가지

| 유형 | 동작 |
|---|---|
| `Always Apply` | 모든 채팅 세션에 적용 |
| `Apply Intelligently` | 에이전트가 description 기반으로 관련성 판단 |
| `Apply to Specific Files` | glob 패턴 매치 시 적용 |
| `Apply Manually` | `@my-rule`로 수동 호출 |

### AGENTS.md

```markdown
# AGENTS.md (프로젝트 루트)

## 코드 스타일
- TypeScript 사용 (모든 새 파일)
- React에서 함수형 컴포넌트 선호
- DB 칼럼은 snake_case

## 아키텍처
- Repository 패턴 따르기
- 비즈니스 로직은 서비스 레이어에

## 테스트
- vitest 사용, `npm run test` 명령
- 커버리지 80% 이상 유지

## 배포
- `npm run build` 후 `npm run deploy:staging`
```

**중첩 AGENTS.md 지원:**
```
project/
  AGENTS.md              # 글로벌 지침
  frontend/
    AGENTS.md            # 프론트엔드 특화
  backend/
    AGENTS.md            # 백엔드 특화
```

### CLAUDE.md (Claude Code용)

```markdown
# CLAUDE.md

## 빌드/테스트
- `npm run build` — TypeScript 컴파일
- `npm run test -- --watch=false` — 전체 테스트
- `npm run lint` — ESLint

## 코드 스타일
- ES modules (import/export), CommonJS 아님
- 가능하면 구조 분해 임포트

## 워크플로우
- 코드 변경 후 반드시 typecheck
- 전체 테스트 대신 단일 테스트 실행 (성능)
```

### 작성 베스트 프랙티스 (모든 도구 공통)

1. **짧게 유지** — AI가 이미 아는 것(일반 관행, 도구 사용법)은 빼라
2. **구체적 예제 포함** — 추상적 원칙보다 실제 코드 패턴 참조
3. **제약 > 지시** — "~하지 마라"가 "~해라"보다 효과적
4. **파일 참조** — `@filename.ts`로 내용 복사 대신 참조
5. **git에 커밋** — 팀 전체가 혜택을 받도록
6. **정기 업데이트** — 에이전트 실수 시 규칙 업데이트
7. **도메인 지식만** — AI가 추론 불가능한 것만 포함 (빌드 명령, 특수 환경변수, 아키텍처 결정)

---

## 9. 비용 비교

### Cursor 가격 (2026-02)

| 플랜 | 가격 | 포함 사항 |
|---|---|---|
| Hobby | 무료 | 제한된 프론티어 모델, 제한된 에이전트/탭 |
| Individual (Pro+) | $60/월 | 모든 모델, 확장 한도, $70/월 사용량, Cloud Agents, CLI |
| Teams | $40/유저/월 | 모든 모델, $20/유저/월 사용량, 분석, 팀 규칙 |
| Enterprise | 커스텀 | 공유 풀, 서브팀 한도, 감사 API, MDM 배포 |

### Codex CLI
- **ChatGPT Plus/Pro/Business/Edu/Enterprise에 포함** (별도 비용 없음)
- API 키 사용 시 API 가격 적용

### Claude Code
- **Claude 구독** (Pro: $20/월, Team: $30/유저/월 등) 또는 Anthropic Console API
- 서드파티 프로바이더(AWS Bedrock 등) 지원

### Devin
- **Teams 플랜**: 별도 가격 (cognition.ai에서 문의)
- Nubank 사례: 엔지니어 인건비 대비 **20x 비용 절감** 보고

### GitHub Copilot
- **Free**: 제한적 완성
- **Pro** ($10/월): 무제한 완성, 채팅
- **Pro+** ($39/월): Agent HQ, Claude/Codex 접근
- **Enterprise** ($21/유저/월): 조직 정책, 감사

---

## 10. Terminal-Bench 2.0 리더보드

> 2026-02-22 기준 상위 15개 (105개 중)

| 순위 | 에이전트 | 모델 | 조직 | 정확도 |
|---|---|---|---|---|
| 1 | **Simple Codex** | GPT-5.3-Codex | OpenAI | **75.1%** |
| 2 | Terminus-KIRA | Claude Opus 4.6 | KRAFTON AI | 74.7% |
| 3 | Judy | Claude Opus 4.6 | Bigai | 71.9% |
| 4 | CodeBrain-1 | GPT-5.3-Codex | Feeling AI | 70.3% |
| 5 | Droid | Claude Opus 4.6 | Factory | 69.9% |
| 6 | Mux | GPT-5.3-Codex | Coder | 68.5% |
| 7 | Mux | Claude Opus 4.6 | Coder | 66.5% |
| 8 | Deep Agents | GPT-5.2-Codex | LangChain | 66.5% |
| 9 | Droid | GPT-5.2 | Factory | 64.9% |
| 10 | Terminus 2 | GPT-5.3-Codex | Terminal Bench | 64.7% |
| 11 | Ante | Gemini 3 Pro | Antigma Labs | 64.7% |
| 12 | Junie CLI | Gemini 3 Flash | JetBrains | 64.3% |
| 13 | Droid | Claude Opus 4.5 | Factory | 63.1% |
| 14 | Codex CLI | GPT-5.2 | OpenAI | 62.9% |
| 15 | Terminus 2 | Claude Opus 4.6 | Terminal Bench | 62.9% |

**핵심 인사이트:**
- **하니스(에이전트 프레임워크)가 모델만큼 중요** — 같은 모델이라도 하니스에 따라 10%p 이상 차이
- **GPT-5.3-Codex + Simple Codex가 현재 1위** (75.1%)
- **Claude Opus 4.6이 Anthropic 모델 중 최고** — KRAFTON의 Terminus-KIRA가 74.7%로 2위
- **Cursor Composer 1.5는 Terminal-Bench에서 Sonnet 4.5 이상** (정확한 순위는 Cursor 자체 측정)
- **Gemini 3 Pro/Flash도 상위권** — JetBrains Junie CLI(64.3%), Ante(64.7%)

---

## 출처

- Cursor Blog: <https://cursor.com/blog>
  - Self-Driving Codebases (Feb 5, 2026)
  - Scaling Agents (earlier)
  - Marketplace (Feb 17), Sandboxing (Feb 18), Composer 1.5 (Feb 9)
  - Long-Running Agents (Feb 12), Stripe (Feb 17), NVIDIA (Feb 6), Box (Feb 13)
  - Secure Codebase Indexing (Jan 27), Increased Agent Usage (Feb 11)
- Cursor Docs: <https://cursor.com/docs/context/rules>
- Cursor Pricing: <https://cursor.com/pricing>
- OpenAI Codex CLI: <https://github.com/openai/codex>, <https://developers.openai.com/codex>
- Claude Code Docs: <https://code.claude.com/docs/en/overview>, <https://code.claude.com/docs/en/best-practices>
- Devin Docs: <https://docs.devin.ai>, <https://docs.devin.ai/essential-guidelines/when-to-use-devin>
- Devin Homepage (Nubank Case): <https://devin.ai>
- GitHub Blog: Agent HQ (Feb 4, 2026), The Agent Awakens (Feb 6, 2025)
- Terminal-Bench 2.0: <https://www.tbench.ai/leaderboard/terminal-bench/2.0>
- awesome-cursorrules: <https://github.com/PatrickJS/awesome-cursorrules>
