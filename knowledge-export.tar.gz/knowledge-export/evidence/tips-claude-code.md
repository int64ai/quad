# Claude Code 사용 팁 — 2026년 자료 기반 종합 가이드

> 조사일: 2026-02-22
> 출처: Anthropic 공식 문서 (code.claude.com/docs), Simon Willison 블로그, 커뮤니티 인사이트
> 참고: YouTube 검색 결과는 JS 렌더링 필요로 web_fetch로 수집 불가. Brave Search API 키 미설정으로 web_search도 불가. 대신 공식 문서와 블로그에서 풍부한 자료 수집.

---

## 📚 수집된 주요 출처

### 공식 문서 (Anthropic)
| 제목 | URL |
|------|-----|
| Claude Code Overview | <https://code.claude.com/docs/en/overview> |
| Best Practices | <https://code.claude.com/docs/en/best-practices> |
| Common Workflows | <https://code.claude.com/docs/en/common-workflows> |
| Sub-agents | <https://code.claude.com/docs/en/sub-agents> |
| Agent Teams | <https://code.claude.com/docs/en/agent-teams> |
| Costs & Token Management | <https://code.claude.com/docs/en/costs> |
| Skills | <https://code.claude.com/docs/en/skills> |
| Hooks | <https://code.claude.com/docs/en/hooks-guide> |
| CLAUDE.md (Memory) | <https://code.claude.com/docs/en/memory> |
| Fast Mode | <https://code.claude.com/docs/en/fast-mode> |
| Full Docs Index (llms.txt) | <https://code.claude.com/docs/llms.txt> |

### Simon Willison 블로그 (2026년 2월)
| 제목 | 날짜 | URL |
|------|------|-----|
| Prompt Caching & Claude Code (Thariq Shihipar 인용) | 2026-02-20 | <https://simonwillison.net/2026/Feb/20/thariq-shihipar/> |
| Parallel Agent Psychosis — 세션 로그 복구 | 2026-02-19 | <https://simonwillison.net/2026/Feb/19/recovering-lost-code/> |
| Paul Ford NYT: "The AI Disruption" | 2026-02-18 | <https://simonwillison.net/2026/Feb/18/the-ai-disruption/> |
| Sonnet 4.6 출시 | 2026-02-17 | <https://simonwillison.net/2026/Feb/17/claude-sonnet-46/> |
| Showboat + Chartroom + Rodney 도구 | 2026-02-17 | <https://simonwillison.net/2026/Feb/17/chartroom-and-datasette-showboat/> |
| Claude Code on the Web (Desktop App 활용) | 2026-02-16 | <https://simonwillison.net/2026/Feb/16/rodney-claude-code/> |
| Fast Mode (Opus 4.6 2.5x 빠르지만 6x 비쌈) | 2026-02-07 | <https://simonwillison.net/2026/Feb/7/claude-fast-mode/> |
| IMPLEMENTATION_NOTES.md 패턴 (antirez/FLUX.2) | 2026-01-18 | <https://simonwillison.net/2026/Jan/18/> |
| Claude Cowork 보안 취약점 (파일 유출) | 2026-01-14 | <https://simonwillison.net/2026/Jan/14/> |
| Jaana Dogan (Google) — Claude Code 평가 | 2026-01-04 | <https://simonwillison.net/2026/Jan/4/> |

### 커뮤니티 인사이트
- **Boris Cherny** (Claude Code 창시자): "엔지니어는 여전히 중요. Claude에게 프롬프트를 쓰고, 고객과 소통하고, 무엇을 만들지 결정해야 한다"
- **Dimitris Papailiopoulos**: "질문과 첫 번째 답 사이의 거리가 매우 작아졌다"
- **Paul Ford**: "$200/월 Claude 플랜으로 주말과 저녁에 수십만 달러 가치의 작업 가능"
- **Chris Ashworth** (QLab CEO): "나쁜 프로그래머는 빠르게 나쁜 프로그램을 만들고, 좋은 프로그래머는 빠르게 좋은 프로그램을 만든다"

---

## 🟢 초보자 (첫 사용)

### 1. 설치 & 시작
```bash
# macOS/Linux/WSL
curl -fsSL https://claude.ai/install.sh | bash

# Windows PowerShell
irm https://claude.ai/install.ps1 | iex

# 프로젝트에서 시작
cd your-project
claude
```
- VS Code 확장, Desktop 앱, Web (claude.ai/code), JetBrains 플러그인도 지원
- 첫 사용 시 로그인 프롬프트 나타남

### 2. 핵심 개념: 컨텍스트 윈도우
- **Claude Code의 가장 중요한 리소스 = 컨텍스트 윈도우**
- 대화 전체, 읽은 파일, 명령어 출력 모두 컨텍스트에 들어감
- 컨텍스트가 차면 성능 저하 → 적극적 관리 필요
- `/cost`로 토큰 사용량 확인, 상태줄에 컨텍스트 사용량 표시 가능

### 3. 기본 워크플로우
```
# 코드베이스 탐색
> give me an overview of this codebase
> explain the main architecture patterns used here
> how is authentication handled?

# 버그 수정
> I'm seeing an error when I run npm test

# 커밋 & PR
> commit my changes with a descriptive message
> create a pr
```

### 4. /init으로 CLAUDE.md 생성
```bash
# 프로젝트 루트에서 실행
/init
```
- 빌드 시스템, 테스트 프레임워크, 코드 패턴 자동 감지
- 이후 수동 개선

### 5. 파일 참조 (@)
```
> Explain the logic in @src/utils/auth.js
> What's the structure of @src/components?
```

### 6. 이미지 활용
- 드래그 앤 드롭, Ctrl+V로 이미지 붙여넣기
- 스크린샷, UI 디자인, 다이어그램 분석 가능

---

## 🟡 중급 (효율 극대화)

### 1. Plan Mode 활용 (Shift+Tab)
```
Explore → Plan → Implement → Commit
```
1. **Plan Mode 진입** (Shift+Tab 두 번 또는 `claude --permission-mode plan`)
2. 코드베이스 탐색 (읽기 전용)
3. 계획 수립 → Ctrl+G로 에디터에서 편집
4. **Normal Mode 전환** → 구현
5. 커밋 & PR

> ⚠️ Plan Mode는 오버헤드가 있음. 간단한 작업(오타 수정, 변수 이름 변경)은 직접 요청이 효율적.

### 2. 검증 가능한 프롬프트 작성 (가장 중요한 팁!)
| 나쁜 예 | 좋은 예 |
|---------|---------|
| "이메일 유효성 검사 함수 구현" | "validateEmail 함수 작성. user@example.com → true, invalid → false, user@.com → false. 구현 후 테스트 실행" |
| "대시보드 더 보기 좋게" | "[스크린샷 붙여넣기] 이 디자인 구현. 결과 스크린샷 찍어서 비교. 차이점 나열 후 수정" |
| "빌드 실패" | "빌드가 이 에러로 실패: [에러 붙여넣기]. 수정하고 빌드 성공 확인. 근본 원인 해결, 에러 무시 금지" |

### 3. 구체적 컨텍스트 제공
| 전략 | 예시 |
|------|------|
| 범위 지정 | "로그아웃 상태 엣지 케이스에 대한 foo.py 테스트 작성. 목 사용 금지" |
| 소스 지정 | "ExecutionFactory의 git 히스토리를 보고 API가 어떻게 변했는지 요약" |
| 기존 패턴 참조 | "홈페이지 위젯 패턴 참고. HotDogWidget.php가 좋은 예시. 캘린더 위젯 구현" |

### 4. Claude에게 인터뷰받기
```
I want to build [간단한 설명]. Interview me in detail using the AskUserQuestion tool.
Ask about technical implementation, UI/UX, edge cases, concerns, and tradeoffs.
Don't ask obvious questions, dig into the hard parts I might not have considered.
Keep interviewing until we've covered everything, then write a complete spec to SPEC.md.
```
→ 스펙 완성 후 **새 세션에서 구현** (깨끗한 컨텍스트)

### 5. 세션 관리
- **Esc**: 중간에 멈추기 (컨텍스트 유지)
- **Esc + Esc** 또는 `/rewind`: 이전 체크포인트로 복원
- **`/clear`**: 관련 없는 작업 전환 시 컨텍스트 초기화
- **`"Undo that"`**: 변경 취소
- **`/rename`**: 세션 이름 지정 ("oauth-migration", "debugging-memory-leak")
- **`claude --continue`**: 가장 최근 세션 재개
- **`claude --resume`**: 세션 선택기 열기

> 💡 핵심: 같은 이슈에 2번 이상 수정했으면 `/clear` 후 더 나은 프롬프트로 새 세션 시작

### 6. CLAUDE.md 효과적 작성법
```markdown
# Code style
- Use ES modules (import/export) syntax, not CommonJS (require)
- Destructure imports when possible (eg. import { foo } from 'bar')

# Workflow
- Be sure to typecheck when you're done making a series of code changes
- Prefer running single tests, and not the whole test suite, for performance
```

**포함할 것:**
- Claude가 추측할 수 없는 Bash 명령어
- 기본값과 다른 코드 스타일 규칙
- 테스트 방법과 선호 테스트 러너
- 브랜치 네이밍, PR 규약
- 프로젝트 특유의 아키텍처 결정
- 개발 환경 quirk (필요 환경변수)
- 일반적이지 않은 동작/gotcha

**제외할 것:**
- 코드를 읽으면 알 수 있는 것
- 언어의 표준 관례
- 자주 변하는 정보
- 긴 설명이나 튜토리얼
- 파일별 코드베이스 설명
- "깨끗한 코드 작성" 같은 자명한 것

**중요:** CLAUDE.md가 너무 길면 Claude가 지시를 무시함! 각 줄에 대해 "이것을 제거하면 Claude가 실수할까?" 질문.

**강조 표현**: "IMPORTANT", "YOU MUST" 같은 표현으로 중요도 높이기

**@import 구문:**
```markdown
See @README.md for project overview and @package.json for available npm commands.
# Additional Instructions
- Git workflow: @docs/git-instructions.md
```

**위치별 CLAUDE.md:**
- `~/.claude/CLAUDE.md` — 모든 세션에 적용
- `./CLAUDE.md` — 프로젝트 루트 (git에 커밋)
- `./CLAUDE.local.md` — 개인 설정 (.gitignore에 추가)
- 부모/자식 디렉토리 — 모노레포에서 자동 로드

### 7. CLI 도구 활용
```bash
# GitHub CLI
gh pr list
gh issue view 123

# Claude에게 알려주기
> Use 'foo-cli-tool --help' to learn about foo tool, then use it to solve A, B, C.
```
- `gh`, `aws`, `gcloud`, `sentry-cli` 등 CLI 도구가 MCP보다 컨텍스트 효율적

### 8. 서브에이전트로 조사 위임
```
Use subagents to investigate how our authentication system handles token
refresh, and whether we have any existing OAuth utilities I should reuse.
```
- 서브에이전트는 별도 컨텍스트에서 실행 → 메인 대화 깔끔 유지
- 결과 요약만 반환
- 구현 후 검증에도 활용: `use a subagent to review this code for edge cases`

---

## 🔴 고급 (Agent Teams, 자동화, CI/CD 통합)

### 1. Agent Teams (실험적 기능)
```json
// settings.json에서 활성화
{
  "env": {
    "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1"
  }
}
```

**최적 사용 사례:**
- 리서치 & 리뷰: 여러 관점 동시 탐색
- 새 모듈/기능: 각 팀원이 별도 파일 담당
- 경쟁 가설 디버깅: 다른 이론을 병렬로 테스트
- 크로스 레이어 조정: 프론트엔드/백엔드/테스트 각각 담당

**예시 — 병렬 코드 리뷰:**
```
Create an agent team to review PR #142. Spawn three reviewers:
- One focused on security implications
- One checking performance impact
- One validating test coverage
Have them each review and report findings.
```

**예시 — 경쟁 가설 디버깅:**
```
Users report the app exits after one message instead of staying connected.
Spawn 5 agent teammates to investigate different hypotheses. Have them talk to
each other to try to disprove each other's theories, like a scientific
debate. Update the findings doc with whatever consensus emerges.
```

**Agent Teams vs Subagents:**
| | Subagents | Agent Teams |
|--|-----------|-------------|
| 컨텍스트 | 자체 윈도우, 결과만 반환 | 자체 윈도우, 완전 독립 |
| 통신 | 메인 에이전트에만 보고 | 팀원끼리 직접 소통 |
| 조정 | 메인 에이전트가 관리 | 공유 작업 목록 + 자율 조정 |
| 최적 상황 | 결과만 필요한 집중 작업 | 토론/협업 필요한 복잡한 작업 |
| 토큰 비용 | 낮음 | 높음 (각 팀원 별도 인스턴스) |

**주의사항:**
- 표준 세션 대비 ~7x 토큰 사용
- 파일 충돌 피하기 — 각 팀원이 다른 파일 담당
- 팀원에게 충분한 컨텍스트 제공
- in-process 모드가 기본 (tmux/iTerm2로 split-pane 가능)

### 2. 커스텀 서브에이전트 정의
```markdown
# .claude/agents/security-reviewer.md
---
name: security-reviewer
description: Reviews code for security vulnerabilities
tools: Read, Grep, Glob, Bash
model: opus
---
You are a senior security engineer. Review code for:
- Injection vulnerabilities (SQL, XSS, command injection)
- Authentication and authorization flaws
- Secrets or credentials in code
- Insecure data handling

Provide specific line references and suggested fixes.
```

**서브에이전트 설정 옵션:**
- `model`: `sonnet`, `opus`, `haiku`, `inherit`
- `permissionMode`: `default`, `acceptEdits`, `dontAsk`, `bypassPermissions`, `plan`
- `isolation`: `worktree` (별도 git 워크트리에서 실행)
- `background`: `true` (백그라운드 실행)
- `memory`: `user`, `project`, `local` (영구 메모리)
- `skills`: 스킬을 주입하여 도메인 지식 제공
- `hooks`: 생명주기 훅 정의
- `maxTurns`: 최대 턴 수 제한

### 3. Skills (온디맨드 지식)
```markdown
# .claude/skills/fix-issue/SKILL.md
---
name: fix-issue
description: Fix a GitHub issue
disable-model-invocation: true
---
Analyze and fix the GitHub issue: $ARGUMENTS.

1. Use `gh issue view` to get the issue details
2. Understand the problem described in the issue
3. Search the codebase for relevant files
4. Implement the necessary changes to fix the issue
5. Write and run tests to verify the fix
6. Ensure code passes linting and type checking
7. Create a descriptive commit message
8. Push and create a PR
```
→ `/fix-issue 1234`로 실행

**Skills vs CLAUDE.md:**
- CLAUDE.md: 매 세션 로드 (토큰 소모) → 공통 규칙만
- Skills: 필요할 때만 로드 → 특정 워크플로우에 적합
- CLAUDE.md ~500줄 이하 권장, 나머지는 Skills로

### 4. Hooks (자동 실행)
```json
// .claude/settings.json
{
  "hooks": {
    "PostToolUse": [{
      "matcher": "Edit|Write",
      "hooks": [{
        "type": "command",
        "command": "npx eslint --fix $FILE_PATH"
      }]
    }]
  }
}
```
- **PreToolUse**: 도구 실행 전 검증/수정
- **PostToolUse**: 도구 실행 후 자동 포매팅/린팅
- **Notification**: Claude가 대기 중일 때 알림
- **Stop**: 세션 종료 시

### 5. Headless Mode (CI/CD)
```bash
# 일회성 쿼리
claude -p "Explain what this project does"

# 구조화된 출력
claude -p "List all API endpoints" --output-format json

# 스트리밍
claude -p "Analyze this log file" --output-format stream-json

# CI 린터로 사용
# package.json
{
  "scripts": {
    "lint:claude": "claude -p 'you are a linter. please look at the changes vs. main and report any issues related to typos.'"
  }
}

# 파이프
cat build-error.txt | claude -p 'concisely explain the root cause' > output.txt
git diff main --name-only | claude -p "review these changed files for security issues"
tail -f app.log | claude -p "Slack me if you see any anomalies"
```

### 6. Git Worktrees로 병렬 세션
```bash
# 워크트리에서 Claude 시작
claude --worktree feature-auth
claude --worktree bugfix-123

# 이름 자동 생성
claude --worktree

# .gitignore에 추가
# .claude/worktrees/
```
- 각 세션이 독립된 파일과 브랜치 보유
- 서브에이전트도 `isolation: worktree`로 워크트리 격리 가능

### 7. Writer/Reviewer 패턴
| Session A (Writer) | Session B (Reviewer) |
|-------|---------|
| Rate limiter 구현 | `git diff main`로 변경 리뷰 |
| 코드 작성 완료 | 보안, 성능, 엣지 케이스 검토 |

→ 다른 세션의 Claude가 작성한 코드를 리뷰하면 편향 없는 리뷰 가능

### 8. GitHub Actions / GitLab CI/CD
- PR 리뷰 자동화, 이슈 분류
- `claude --from-pr <number>`로 PR 연결 세션 재개

### 9. MCP (Model Context Protocol)
```bash
claude mcp add  # 외부 도구 연결
```
- Google Drive, Jira, Slack, Figma, 데이터베이스 등 연결
- 단, MCP 서버마다 컨텍스트 오버헤드 발생 → 미사용 서버 비활성화

---

## 💰 비용/토큰 관리

### 비용 현황 (2026년 기준)
- **평균**: 개발자당 하루 ~$6, 90%가 하루 $12 이하
- **월간**: Sonnet 4.6 기준 개발자당 ~$100-200/월
- **모델 가격**:
  - Opus 4.6: $5/M input, $25/M output
  - Sonnet 4.6: $3/M input, $15/M output
  - Fast Mode (Opus): $30/M input, $150/M output (6x!)
  - 1M 토큰 확장: 200K 초과 시 input 2x, output 1.5x

### 토큰 절약 전략

1. **`/clear` 자주 사용** — 관련 없는 작업 전환 시 반드시
2. **커스텀 컴팩션** — `/compact Focus on code samples and API usage`
3. **올바른 모델 선택**:
   - 대부분 작업: **Sonnet** (저렴하고 충분)
   - 복잡한 아키텍처: **Opus**
   - 간단한 서브에이전트: **Haiku**
   - `/model`로 세션 중 전환 가능
4. **MCP 서버 오버헤드 줄이기**:
   - CLI 도구(`gh`, `aws`) 선호 — MCP보다 컨텍스트 효율적
   - `/mcp`로 미사용 서버 비활성화
   - `ENABLE_TOOL_SEARCH=auto:5`로 자동 지연 로딩
5. **CLAUDE.md → Skills로 이동** — 특정 워크플로우 지침은 Skills로
6. **Hooks로 전처리** — 10,000줄 로그를 grep으로 필터링 후 Claude에 전달
7. **Extended Thinking 조절**:
   - 기본 31,999 토큰 (비용에 포함!)
   - 간단한 작업: `/model`에서 effort level 낮추기
   - `/config`에서 thinking 비활성화
   - `MAX_THINKING_TOKENS=8000`으로 제한
8. **서브에이전트에 heavy 작업 위임** — 테스트 실행, 문서 조회 등 verbose 출력을 서브에이전트에서 처리
9. **구체적 프롬프트** — "이 코드베이스 개선해줘" (❌) vs "auth.ts의 로그인 함수에 입력 검증 추가" (✅)
10. **Code Intelligence 플러그인 설치** — "go to definition" 한 번 > grep + 여러 파일 읽기

### Prompt Caching 인사이트 (Thariq Shihipar, Claude Code 팀)
> "장기 실행 에이전트 제품인 Claude Code는 프롬프트 캐싱으로 실현 가능. 이전 라운드트립의 계산을 재사용하여 레이턴시와 비용을 크게 줄인다. Claude Code에서는 프롬프트 캐시 히트율에 알림을 설정하고, 너무 낮으면 SEV를 선언한다."

### Agent Teams 비용
- 표준 세션 대비 ~7x 토큰
- 팀원에 Sonnet 사용 권장
- 팀 크기 최소화
- 작업 완료 시 즉시 팀 정리

---

## ⚠️ 함정/안티패턴

### 1. 컨텍스트 관리 실패
- ❌ 긴 세션에서 관련 없는 작업 계속하기
- ❌ `/clear` 없이 주제 전환
- ❌ 같은 이슈에 2번 이상 수정 후에도 계속 진행
- ✅ `/clear` 후 더 나은 프롬프트로 새 세션

### 2. CLAUDE.md 비대화
- ❌ 모든 것을 CLAUDE.md에 넣기
- ❌ 파일별 코드베이스 설명
- ❌ 긴 튜토리얼이나 API 문서
- ✅ ~500줄 이하 유지, 나머지는 Skills로

### 3. 모호한 프롬프트
- ❌ "코드 개선해줘"
- ❌ "버그 고쳐"
- ✅ 파일명, 시나리오, 테스트 케이스 명시

### 4. 검증 없는 구현
- ❌ 테스트 없이 코드 작성 요청
- ❌ Claude 결과를 검증 없이 수락
- ✅ 항상 검증 기준 제공 (테스트, 스크린샷, 기대 출력)

### 5. Plan 없이 큰 작업 시작
- ❌ 복잡한 기능을 바로 구현 요청
- ✅ Plan Mode로 탐색 → 계획 → 구현

### 6. /fast 모드 남용
- ❌ 모든 작업에 /fast 사용 (6x 비용!)
- ✅ 레이턴시가 중요한 경우에만 선택적 사용

### 7. Agent Teams 남용
- ❌ 순차적 작업에 Agent Teams 사용
- ❌ 같은 파일을 여러 팀원이 편집
- ✅ 독립적 병렬 작업에만 사용

### 8. 코드 미확인 배포 (Chris Ashworth 경고)
> "프로그래머들이 '보지도 이해하지도 못한 코드를 배포하고 있다'고 말하는 것은 끔찍하다. 코드를 이해하고, 지시하고, 설계하고, 편집하고, 삭제하고, 품질 관리할 수 있어야 한다."

### 9. Parallel Agent Psychosis (Simon Willison)
> "병렬 에이전트 사이코시스 단계에 도달 — 기능 하나를 잃어버렸다. 어제 있었는데 어떤 브랜치, 워크트리, 클라우드 인스턴스에서도 찾을 수 없다."
- 해결: `~/.claude/projects/` 세션 로그에서 복구 가능
- 교훈: 많은 병렬 세션 관리 시 체계적 이름/브랜치 규약 필수

### 10. 보안 취약점 주의
- Claude Cowork/Code가 외부 HTTP 접근 시 프롬프트 인젝션을 통한 파일 유출 가능
- `--dangerously-skip-permissions`는 인터넷 없는 샌드박스에서만 사용
- 외부 도메인 접근은 `/permissions`로 화이트리스트 관리

---

## 🔑 핵심 내장 명령어 정리

| 명령어 | 설명 |
|--------|------|
| `/init` | CLAUDE.md 자동 생성 |
| `/clear` | 컨텍스트 초기화 |
| `/compact [지시]` | 컨텍스트 압축 (커스텀 지시 가능) |
| `/cost` | 토큰 사용량 확인 (API 사용자용) |
| `/stats` | 사용 패턴 확인 (구독자용) |
| `/model` | 모델 전환 + effort level 조절 |
| `/config` | 전역 설정 |
| `/fast` | Fast Mode 토글 (Opus 4.6, 6x 비용) |
| `/permissions` | 권한 화이트리스트 관리 |
| `/mcp` | MCP 서버 관리 |
| `/hooks` | 훅 대화형 설정 |
| `/agents` | 서브에이전트 관리 |
| `/plugin` | 플러그인 마켓플레이스 |
| `/context` | 컨텍스트 소모 항목 확인 |
| `/rename` | 세션 이름 지정 |
| `/resume` | 이전 세션 재개 |
| `/rewind` | 체크포인트 복원 |
| `/sandbox` | OS 레벨 격리 |
| `/commit-push-pr` | 커밋+푸시+PR 한 번에 |
| `/skill-name` | 커스텀 스킬 실행 |
| `/statusline` | 상태줄 설정 |
| Shift+Tab | Normal ↔ Auto-Accept ↔ Plan 모드 전환 |
| Ctrl+G | 계획을 에디터에서 편집 |
| Ctrl+O | Verbose 모드 토글 (thinking 표시) |
| Ctrl+B | 서브에이전트 백그라운드로 전환 |
| Option+T / Alt+T | Thinking 모드 토글 |
| Esc | 중단 (컨텍스트 유지) |
| Esc+Esc | 체크포인트 복원 메뉴 |

---

## 📋 추천 워크플로우 요약

### 일상 개발 워크플로우
1. `cd project && claude`
2. `/clear`로 깨끗한 시작
3. Plan Mode에서 탐색 & 계획
4. Normal Mode에서 구현
5. 테스트 실행 & 수정
6. `/commit-push-pr`

### 대규모 기능 개발
1. Claude에게 인터뷰 받기 → `SPEC.md` 생성
2. 새 세션에서 스펙 기반 구현
3. 서브에이전트로 보안/성능 리뷰
4. 별도 세션에서 코드 리뷰 (Writer/Reviewer 패턴)
5. Agent Teams로 복잡한 병렬 작업

### 디버깅 워크플로우
1. 에러 메시지 & 재현 단계 제공
2. 서브에이전트로 관련 코드 탐색
3. 실패 테스트 작성 → 수정 → 통과 확인
4. 근본 원인 문서화

### CI/CD 통합
1. `claude -p` headless 모드로 자동화
2. GitHub Actions / GitLab CI/CD 연동
3. Hooks로 파일 편집 후 자동 린팅/포매팅
4. Skills로 팀 공유 워크플로우 표준화

---

## 🆕 2026년 2월 새로운 기능/트렌드

### Sonnet 4.6 출시 (2026-02-17)
- Opus 4.5와 유사한 성능, Sonnet 가격 ($3/$15)
- knowledge cutoff: 2025년 8월

### Fast Mode (2026-02-07)
- Opus 4.6의 2.5x 빠른 버전
- 가격: 6x (일반 $5/$25 → Fast $30/$150)
- `/fast`로 토글

### IMPLEMENTATION_NOTES.md 패턴 (antirez)
- Salvatore Sanfilippo (antirez)가 FLUX.2 C 구현에 사용
- 모든 구현 노트와 발견 사항을 파일에 누적
- 컨텍스트 컴팩션 후 즉시 처리하도록 지시
- → 대규모 코딩 작업에서 트래킹 유지 가능

### 세션 로그 복구
- `~/.claude/projects/`에 전체 세션 로그 저장
- 코드를 잃어도 세션 로그에서 추출 가능 (Simon Willison 경험)

### Claude Code on the Web
- `claude.ai/code`에서 브라우저로 실행
- Desktop/iOS 앱에서도 접근
- `/teleport`로 웹 → 터미널 이동 가능
- Desktop 앱에서 Claude가 보는 이미지 미리보기 가능

### 도구 생태계
- **Showboat**: 코딩 에이전트가 결과를 데모 문서로 생성
- **Rodney**: CLI 브라우저 자동화 (코딩 에이전트 친화적 `--help`)
- **Chartroom**: CLI 차트 도구

---

## 📖 추가 학습 리소스

- 전체 문서 인덱스: <https://code.claude.com/docs/llms.txt>
- Best Practices 심화: <https://code.claude.com/docs/en/best-practices>
- Common Workflows: <https://code.claude.com/docs/en/common-workflows>
- Sub-agents 가이드: <https://code.claude.com/docs/en/sub-agents>
- Agent Teams: <https://code.claude.com/docs/en/agent-teams>
- Costs 관리: <https://code.claude.com/docs/en/costs>
- Hooks 가이드: <https://code.claude.com/docs/en/hooks-guide>
- Skills 가이드: <https://code.claude.com/docs/en/skills>
- Plugins: <https://code.claude.com/docs/en/plugins>
- Simon Willison 블로그 (claude-code 태그): <https://simonwillison.net/tags/claude-code/>
