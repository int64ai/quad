# OpenClaw 공식 문서 정리 — 설치 & 설정 가이드

> 수집일: 2026-02-21  
> 출처: docs.openclaw.ai, github.com/openclaw/openclaw (README, VISION.md, SECURITY.md)

---

## 1. OpenClaw 개요

OpenClaw은 **개인용 AI 어시스턴트**로, 사용자 소유 디바이스에서 실행되며 기존에 사용하는 메시징 채널(WhatsApp, Telegram, Slack, Discord, Google Chat, Signal, iMessage, Microsoft Teams, WebChat 등)을 통해 응답한다. Gateway가 제어 평면(control plane)이며, 실제 제품은 어시스턴트 그 자체다.

**비전 (VISION.md):**
- "실제로 일을 하는 AI" — 사용자 디바이스, 채널, 규칙 하에 동작
- 우선순위: 보안 및 안전 기본값 > 버그 수정/안정성 > 설치 신뢰성/첫 실행 UX
- TypeScript 기반 (오케스트레이션 시스템에 적합, 해킹 용이)
- 플러그인 API 확장, MCP는 `mcporter`를 통한 브릿지 모델 사용
- 역사: Warelay → Clawdbot → Moltbot → OpenClaw

---

## 2. 지원 OS

| OS | 지원 상태 | 비고 |
|---|---|---|
| **macOS** | ✅ 완전 지원 | macOS 앱 (메뉴바), launchd 서비스, iMessage/BlueBubbles |
| **Linux** | ✅ 완전 지원 | systemd user service, Raspberry Pi 포함 |
| **Windows** | ✅ WSL2 강력 권장 | PowerShell 설치 스크립트 제공, WSL2 내 systemd 서비스 |

> **최소 VPS 요구사항:** 문서에서 구체적 사양은 명시하지 않으나, Node 22+만 있으면 기본 동작.  
> **Raspberry Pi:** 지원됨 (FAQ에 전용 팁 섹션 존재).

---

## 3. 필수 조건 (Prerequisites)

| 항목 | 요구사항 |
|---|---|
| **Node.js** | **22.12.0 이상** (LTS). `node --version`으로 확인 |
| **Docker** (선택) | Docker Desktop 또는 Docker Engine + Docker Compose v2 |
| **pnpm** (소스 빌드) | 소스 빌드 시 권장 |
| **Bun** (실험적) | Gateway 런타임용으로는 **비권장** (WhatsApp/Telegram 버그) |

---

## 4. 설치 방법별 단계

### 4.1 권장: 웹사이트 설치 스크립트 (가장 빠름)

```bash
# macOS / Linux
curl -fsSL https://openclaw.ai/install.sh | bash

# Windows (PowerShell)
iwr -useb https://openclaw.ai/install.ps1 | iex
```

설치 후:
```bash
openclaw onboard --install-daemon
openclaw gateway status
openclaw dashboard
```

> `--install-daemon` 플래그는 launchd(macOS)/systemd(Linux) 서비스를 자동 설치.

### 4.2 npm / pnpm 글로벌 설치

```bash
npm install -g openclaw@latest
# 또는
pnpm add -g openclaw@latest
```

설치 후:
```bash
openclaw onboard --install-daemon
openclaw doctor
openclaw gateway restart
openclaw health
```

**업데이트:**
```bash
npm i -g openclaw@latest
# 또는
pnpm add -g openclaw@latest
openclaw doctor
openclaw gateway restart
```

### 4.3 소스에서 빌드 (From Source)

```bash
git clone https://github.com/openclaw/openclaw.git
cd openclaw

pnpm install
pnpm ui:build   # UI deps 자동 설치
pnpm build

pnpm openclaw onboard --install-daemon

# 개발 루프 (TS 변경 시 자동 리로드)
pnpm gateway:watch
```

> `pnpm openclaw ...`은 TypeScript를 직접 실행 (tsx). `pnpm build`는 Node/패키지 바이너리용 `dist/` 생성.

**소스 업데이트:**
```bash
openclaw update
# 또는 수동:
git pull
pnpm install
pnpm build
pnpm ui:build
openclaw doctor
openclaw health
```

### 4.4 Docker (선택적)

Docker는 **선택 사항**. 컨테이너화된 게이트웨이 또는 Docker 플로우 검증 시에만 사용.

**빠른 시작:**
```bash
./docker-setup.sh
```

이 스크립트가 하는 일:
- Gateway 이미지 빌드
- 온보딩 위저드 실행
- Docker Compose로 Gateway 시작
- Gateway 토큰 생성 → `.env`에 기록

**수동 Docker Compose:**
```bash
docker build -t openclaw:local -f Dockerfile .
docker compose run --rm openclaw-cli onboard
docker compose up -d openclaw-gateway
```

**채널 설정 (Docker):**
```bash
# WhatsApp
docker compose run --rm openclaw-cli channels login
# Telegram
docker compose run --rm openclaw-cli channels add --channel telegram --token "<token>"
# Discord
docker compose run --rm openclaw-cli channels add --channel discord --token "<token>"
```

**Docker 관련 env vars:**
- `OPENCLAW_DOCKER_APT_PACKAGES` — 빌드 시 추가 apt 패키지
- `OPENCLAW_EXTRA_MOUNTS` — 추가 호스트 바인드 마운트
- `OPENCLAW_HOME_VOLUME` — `/home/node` 영속 볼륨

**Docker 보안:**
- 기본 이미지는 `node` 사용자(uid 1000)로 실행 (비root)
- `--cap-drop=ALL` 권장
- 퍼미션 오류 시: `sudo chown -R 1000:1000 /path/to/openclaw-config`

**Agent Sandbox (호스트 Gateway + Docker 도구):**
- `agents.defaults.sandbox` 활성화 시, non-main 세션 도구가 Docker 컨테이너 내에서 격리 실행
- 기본 이미지: `openclaw-sandbox:bookworm-slim`
- 기본 네트워크: `none` (이그레스 없음)
- Scope: `session` | `agent` (기본) | `shared`

### 4.5 Nix

**[nix-openclaw](https://github.com/openclaw/nix-openclaw)** — Home Manager 모듈.

특징:
- Gateway + macOS 앱 + 도구 (whisper, spotify, cameras) 고정
- Launchd 서비스 (리부트 생존)
- `home-manager switch --rollback`으로 즉시 롤백

**Nix 모드 (`OPENCLAW_NIX_MODE=1`):**
- 자동 설치/자기변이 흐름 비활성화
- 누락 의존성에 Nix 전용 해결 메시지 표시
- UI에 읽기 전용 Nix 모드 배너

---

## 5. 설정 파일 위치 & 구조

### 5.1 디렉토리 레이아웃

```
~/.openclaw/                          # 상태 디렉토리 (OPENCLAW_STATE_DIR)
├── openclaw.json                     # 메인 설정 파일 (JSON5)
├── .env                              # 글로벌 환경변수
├── credentials/                      # 인증 정보
│   ├── whatsapp/<accountId>/creds.json
│   ├── <channel>-allowFrom.json      # 페어링 허용 목록
│   └── oauth.json                    # 레거시 OAuth (import 전용)
├── agents/
│   └── <agentId>/
│       ├── agent/
│       │   ├── auth-profiles.json    # OAuth + API 키 (에이전트별)
│       │   └── auth.json             # 런타임 캐시 (자동 관리)
│       └── sessions/                 # 세션 트랜스크립트 (*.jsonl)
├── workspace/                        # 기본 에이전트 워크스페이스
│   ├── AGENTS.md                     # 운영 지침
│   ├── SOUL.md                       # 페르소나, 톤, 경계
│   ├── USER.md                       # 사용자 정보
│   ├── IDENTITY.md                   # 에이전트 이름/바이브/이모지
│   ├── TOOLS.md                      # 로컬 도구 메모
│   ├── HEARTBEAT.md                  # 하트비트 체크리스트 (선택)
│   ├── BOOT.md                       # 시작 체크리스트 (선택)
│   ├── BOOTSTRAP.md                  # 첫 실행 의식 (1회성)
│   ├── MEMORY.md                     # 장기 기억 (선택)
│   ├── memory/YYYY-MM-DD.md          # 일일 메모리 로그
│   ├── skills/                       # 워크스페이스 스킬
│   └── canvas/                       # Canvas UI 파일
├── skills/                           # 관리형 스킬
├── sandboxes/                        # 샌드박스 워크스페이스
└── workspace-<profile>/              # 프로필별 워크스페이스
```

### 5.2 설정 파일 (`~/.openclaw/openclaw.json`)

- **형식:** JSON5 (주석, trailing comma 허용)
- **파일 없으면** 안전 기본값 사용
- **엄격한 검증:** 스키마에 맞지 않는 설정은 Gateway 시작 거부
- **Hot Reload:** Gateway가 설정 파일을 감시, 변경 시 자동 적용 (대부분 재시작 불필요)

**최소 설정 예시:**
```json5
// ~/.openclaw/openclaw.json
{
  agents: { defaults: { workspace: "~/.openclaw/workspace" } },
  channels: { whatsapp: { allowFrom: ["+15555550123"] } },
}
```

**설정 편집 방법:**
1. `openclaw onboard` — 풀 셋업 위저드
2. `openclaw configure` — 설정 위저드
3. `openclaw config set/get/unset` — CLI 원라이너
4. Control UI (`http://127.0.0.1:18789`) — Config 탭
5. 직접 편집 — 파일 저장 시 자동 적용

**`$include`로 설정 분할:**
```json5
{
  gateway: { port: 18789 },
  agents: { $include: "./agents.json5" },
}
```

### 5.3 환경변수

| 변수 | 용도 |
|---|---|
| `OPENCLAW_HOME` | 홈 디렉토리 오버라이드 (모든 내부 경로 해석) |
| `OPENCLAW_STATE_DIR` | 상태 디렉토리 오버라이드 (기본: `~/.openclaw`) |
| `OPENCLAW_CONFIG_PATH` | 설정 파일 경로 오버라이드 |
| `OPENCLAW_PROFILE` | 프로필명 (워크스페이스/서비스 이름 분리) |
| `OPENCLAW_NIX_MODE` | Nix 모드 활성화 |
| `OPENCLAW_LOAD_SHELL_ENV` | 로그인 셸 env 가져오기 |
| `OPENCLAW_GATEWAY_PORT` | Gateway 포트 |

**env 우선순위 (높→낮):**
1. 프로세스 환경 (부모 셸/데몬)
2. cwd의 `.env`
3. `~/.openclaw/.env`
4. 설정 `env` 블록
5. 선택적 로그인 셸 import

---

## 6. 인증 방식

### 6.1 Anthropic (Claude Pro/Max) — Setup Token

```bash
# 1) claude setup-token 실행 (어디서든)
# 2) OpenClaw에 붙여넣기:
openclaw models auth setup-token --provider anthropic
# 또는 수동:
openclaw models auth paste-token --provider anthropic
# 3) 확인:
openclaw models status
```

- 리프레시 토큰 없이 토큰 auth 프로필로 저장
- 위저드: `openclaw onboard` → auth choice `setup-token`

### 6.2 OpenAI Codex (ChatGPT OAuth) — PKCE

1. PKCE verifier/challenge + 랜덤 state 생성
2. `https://auth.openai.com/oauth/authorize?...` 열기
3. `http://127.0.0.1:1455/auth/callback`에서 콜백 캡처 시도
4. Docker/headless에선 리다이렉트 URL을 복사해서 위저드에 붙여넣기
5. `https://auth.openai.com/oauth/token`에서 교환
6. access token에서 `accountId` 추출 → `{ access, refresh, expires, accountId }` 저장

**자동 리프레시:** `expires` 만료 시 자동으로 리프레시 (파일 락 하에)

### 6.3 Gemini CLI OAuth

FAQ에 언급됨 — `openclaw models auth` 흐름으로 설정.

### 6.4 API 키

- 설정 또는 env var로 직접 제공
- `OPENROUTER_API_KEY`, `GROQ_API_KEY` 등

### 6.5 AWS Bedrock

FAQ에 "Is AWS Bedrock supported?" 항목 존재 — 지원됨.

### 6.6 인증 저장소

- **에이전트별:** `~/.openclaw/agents/<agentId>/agent/auth-profiles.json`
- **런타임 캐시:** `~/.openclaw/agents/<agentId>/agent/auth.json`
- **레거시:** `~/.openclaw/credentials/oauth.json` (첫 사용 시 import)

### 6.7 다중 프로필

- 별도 에이전트로 분리 (권장): `openclaw agents add work`
- 동일 에이전트 내 다중 프로필: `auth-profiles.json`에 여러 프로필 ID
  - 전역: `auth.order`로 우선순위
  - 세션별: `/model Opus@anthropic:work`

---

## 7. 채널 설정

모든 채널은 `channels.<provider>` 아래 설정. 채널 섹션이 존재하면 자동 시작 (`enabled: false`로 비활성화 가능).

### 7.1 지원 채널 목록

| 채널 | 설정 키 | 비고 |
|---|---|---|
| WhatsApp | `channels.whatsapp` | Baileys Web, QR 링크, 다중 계정 지원 |
| Telegram | `channels.telegram` | grammY, 봇 토큰, 웹훅/폴링 |
| Discord | `channels.discord` | discord.js, 봇 토큰, 서버별 설정 |
| Slack | `channels.slack` | Bolt, Socket Mode/HTTP Mode |
| Google Chat | `channels.googlechat` | 서비스 계정 JSON |
| Signal | `channels.signal` | signal-cli |
| iMessage | `channels.imessage` | 레거시 imsg |
| BlueBubbles | `channels.bluebubbles` | iMessage (권장) |
| Microsoft Teams | `channels.msteams` | 확장 |
| Matrix | `channels.matrix` | 확장 |
| Mattermost | `channels.mattermost` | 플러그인 |
| IRC | `channels.irc` | 확장 |
| LINE | `channels.line` | 확장 |
| Feishu | `channels.feishu` | 확장 |
| Zalo / Zalo Personal | `channels.zalo` / `channels.zalouser` | 확장 |
| WebChat | Control UI 내장 | Gateway에서 직접 서빙 |

### 7.2 DM 정책 (공통)

```json5
{
  channels: {
    telegram: {
      enabled: true,
      botToken: "123:abc",
      dmPolicy: "pairing",   // pairing | allowlist | open | disabled
      allowFrom: ["tg:123"], // allowlist/open 시에만
    },
  },
}
```

| dmPolicy | 동작 |
|---|---|
| `pairing` (기본) | 미인증 발신자에게 1회용 페어링 코드 → 소유자 승인 |
| `allowlist` | `allowFrom` (또는 paired allow store)에 있는 발신자만 |
| `open` | 모든 인바운드 DM 허용 (`allowFrom: ["*"]` 필요) |
| `disabled` | 모든 DM 무시 |

### 7.3 그룹 정책

| groupPolicy | 동작 |
|---|---|
| `allowlist` (기본) | 설정된 allowlist 그룹만 |
| `open` | 그룹 allowlist 우회 (mention gating은 유지) |
| `disabled` | 모든 그룹/룸 메시지 차단 |

### 7.4 채널 추가 CLI

```bash
openclaw channels add --channel discord --token "<token>"
openclaw channels add --channel telegram --token "<token>"
openclaw channels login  # WhatsApp QR
```

---

## 8. 멀티 인스턴스 / 멀티 에이전트

### 8.1 멀티 에이전트 라우팅 (단일 Gateway)

한 Gateway에서 **여러 격리된 에이전트** (별도 workspace + agentDir + sessions) 운영 가능.

```json5
{
  agents: {
    list: [
      { id: "home", default: true, workspace: "~/.openclaw/workspace-home" },
      { id: "work", workspace: "~/.openclaw/workspace-work" },
    ],
  },
  bindings: [
    { agentId: "home", match: { channel: "whatsapp", accountId: "personal" } },
    { agentId: "work", match: { channel: "whatsapp", accountId: "biz" } },
  ],
}
```

**에이전트 추가:**
```bash
openclaw agents add work
openclaw agents list --bindings
```

**라우팅 우선순위 (가장 구체적 우선):**
1. `peer` 매치 (정확한 DM/그룹/채널 ID)
2. `parentPeer` 매치
3. `guildId + roles`
4. `guildId`
5. `teamId`
6. `accountId` 매치
7. 채널 레벨 매치
8. 기본 에이전트로 폴백

### 8.2 멀티 게이트웨이 (동일 호스트)

**대부분은 단일 Gateway로 충분** — 하나의 Gateway가 여러 메시징 연결과 에이전트를 처리 가능.

더 강한 격리나 중복이 필요하면 별도 프로필/포트로 분리:

```bash
# 메인
openclaw --profile main gateway --port 18789

# 구조용
openclaw --profile rescue gateway --port 19001
```

**격리 체크리스트 (필수):**
- `OPENCLAW_CONFIG_PATH` — 인스턴스별 설정
- `OPENCLAW_STATE_DIR` — 인스턴스별 세션/인증/캐시
- `agents.defaults.workspace` — 인스턴스별 워크스페이스
- `gateway.port` — 고유 포트 (최소 20 포트 간격)

### 8.3 두 인스턴스 연결

FAQ에 "Can two OpenClaw instances talk to each other (local + VPS)?" 항목 존재 — 가능.

---

## 9. 보안 관련 설정

### 9.1 SECURITY.md 핵심 내용

**보고:**
- 보안 이슈: GitHub Security Advisory 또는 security@openclaw.ai
- 버그 바운티 없음 (PR 권장)

**배포 가정:**
- 호스트와 설정 경계는 **신뢰할 수 있는 것**으로 간주
- `~/.openclaw` 수정 가능한 사람 = 신뢰된 운영자
- 상호 비신뢰 운영자가 하나의 Gateway 공유는 **비권장**
- 플러그인/확장은 **인프로세스**로 로드 → 신뢰된 코드로 취급

**Out of Scope:**
- 공개 인터넷 노출
- 문서가 권장하지 않는 방식으로의 사용
- 프롬프트 인젝션 공격

### 9.2 보안 감사

```bash
openclaw security audit
openclaw security audit --deep    # 라이브 Gateway 프로브
openclaw security audit --fix     # 자동 수정
openclaw security audit --json    # JSON 출력
```

**감사 항목:**
- 인바운드 접근 (DM/그룹 정책, allowlist)
- 도구 폭발 반경 (elevated tools + open rooms)
- 네트워크 노출 (Gateway bind/auth, Tailscale)
- 브라우저 제어 노출
- 로컬 디스크 위생 (퍼미션, symlink)
- 플러그인 (explicit allowlist 없는 확장)
- 모델 위생 (소형 모델 + 위험 도구 표면 → 인젝션 리스크)

### 9.3 강화 기준선 (60초)

```json5
{
  gateway: {
    mode: "local",
    bind: "loopback",
    auth: { mode: "token", token: "long-random-token" },
  },
  session: { dmScope: "per-channel-peer" },
  tools: {
    profile: "messaging",
    deny: ["group:automation", "group:runtime", "group:fs", "sessions_spawn", "sessions_send"],
    fs: { workspaceOnly: true },
    exec: { security: "deny", ask: "always" },
    elevated: { enabled: false },
  },
  channels: {
    whatsapp: { dmPolicy: "pairing", groups: { "*": { requireMention: true } } },
  },
}
```

### 9.4 인증 저장 위치 맵

| 항목 | 경로 |
|---|---|
| WhatsApp | `~/.openclaw/credentials/whatsapp/<accountId>/creds.json` |
| Telegram 봇 토큰 | config/env 또는 `channels.telegram.tokenFile` |
| Discord 봇 토큰 | config/env |
| Slack 토큰 | config/env |
| 페어링 허용목록 | `~/.openclaw/credentials/<channel>-allowFrom.json` |
| 모델 auth 프로필 | `~/.openclaw/agents/<agentId>/agent/auth-profiles.json` |
| 레거시 OAuth | `~/.openclaw/credentials/oauth.json` |

### 9.5 Node.js 보안

Node.js **22.12.0 이상** 필수 — 보안 패치 포함:
- CVE-2025-59466: async_hooks DoS
- CVE-2026-21636: Permission model bypass

### 9.6 웹 인터페이스 안전

- Gateway는 **로컬 전용** (`loopback` bind가 기본)
- 공개 인터넷 노출 금지 (`0.0.0.0` 직접 바인드 비권장)
- 원격 접근: SSH 터널 또는 Tailscale Serve/Funnel
- Reverse Proxy 시: `gateway.trustedProxies` 설정 필수

### 9.7 파일시스템 강화

- `tools.exec.applyPatch.workspaceOnly: true` (권장)
- `tools.fs.workspaceOnly: true` (선택)
- `~/.openclaw` 퍼미션: 그룹/월드 읽기 불가로 설정

---

## 10. Workspace / Agent 디렉토리 구조 상세

### 10.1 워크스페이스 파일 맵

| 파일 | 역할 | 로드 시점 |
|---|---|---|
| `AGENTS.md` | 에이전트 운영 지침, 메모리 사용법 | 매 세션 시작 |
| `SOUL.md` | 페르소나, 톤, 경계 | 매 세션 시작 |
| `USER.md` | 사용자 정보 | 매 세션 시작 |
| `IDENTITY.md` | 에이전트 이름/바이브/이모지 | 부트스트랩 시 생성/갱신 |
| `TOOLS.md` | 로컬 도구 메모 (도구 가용성 제어 아님) | 참조용 |
| `HEARTBEAT.md` | 하트비트 체크리스트 | 하트비트 실행 시 |
| `BOOT.md` | 게이트웨이 재시작 시 실행 체크리스트 | Gateway 재시작 |
| `BOOTSTRAP.md` | 1회성 첫 실행 의식 | 최초 1회 |
| `memory/YYYY-MM-DD.md` | 일일 메모리 로그 | 오늘+어제 읽기 권장 |
| `MEMORY.md` | 장기 기억 (큐레이션) | 메인 비공개 세션에서만 |
| `skills/` | 워크스페이스 스킬 | 이름 충돌 시 managed/bundled 오버라이드 |
| `canvas/` | Canvas UI 파일 | 노드 디스플레이용 |

### 10.2 상태 디렉토리 (`~/.openclaw/`)

워크스페이스에 **포함되지 않는** 항목 (커밋 금지):
- `openclaw.json` (설정)
- `credentials/` (OAuth 토큰, API 키)
- `agents/<agentId>/sessions/` (세션 트랜스크립트 + 메타데이터)
- `skills/` (관리형 스킬)

### 10.3 멀티 에이전트 경로

```
~/.openclaw/agents/<agentId>/
├── agent/
│   ├── auth-profiles.json    # 에이전트별 인증
│   └── auth.json             # 런타임 캐시
└── sessions/                 # 에이전트별 세션 저장소
```

- 에이전트별 워크스페이스: `~/.openclaw/workspace-<agentId>` (또는 설정으로 커스텀)
- **agentDir 재사용 금지** (auth/session 충돌 발생)

---

## 11. Gateway 관리

### 11.1 서비스 관리

```bash
openclaw gateway status
openclaw gateway stop
openclaw gateway restart
openclaw gateway install    # 서비스 등록
openclaw logs --follow
```

**OS별 서비스:**
- macOS: `launchctl kickstart -k gui/$UID/bot.molt.gateway`
- Linux: `systemctl --user restart openclaw-gateway[-<profile>].service`
- Windows WSL2: `systemctl --user restart openclaw-gateway[-<profile>].service`

### 11.2 기본 포트

- Gateway: `18789` (기본)
- Browser control: base + 2
- Canvas: Gateway HTTP 서버에서 서빙 (같은 포트)
- Browser CDP: control port + 9 ~ + 108

### 11.3 건강 검사

```bash
openclaw health
openclaw doctor        # 마이그레이션, 감사, 수리
openclaw doctor --fix   # 자동 수리
```

`openclaw doctor` 역할:
- 폐기된 설정 키 마이그레이션
- DM 정책 감사
- Gateway 상태 확인
- 레거시 서비스 마이그레이션
- Linux systemd 사용자 lingering 확인

---

## 12. 업데이트 & 롤백

### 12.1 권장 업데이트

```bash
# 웹사이트 설치 스크립트 재실행 (가장 안전)
curl -fsSL https://openclaw.ai/install.sh | bash

# 또는 openclaw update (소스 설치)
openclaw update

# 채널 전환
openclaw update --channel beta|dev|stable
```

### 12.2 개발 채널

| 채널 | 설명 | npm 태그 |
|---|---|---|
| `stable` | 태그된 릴리스 (vYYYY.M.D) | `latest` |
| `beta` | 프리릴리스 태그 | `beta` |
| `dev` | main 브랜치 HEAD | `dev` |

### 12.3 롤백

```bash
# 글로벌 설치 — 특정 버전 고정
npm i -g openclaw@<version>
openclaw doctor
openclaw gateway restart

# 소스 — 날짜 기준 롤백
git checkout "$(git rev-list -n 1 --before=\"2026-01-01\" origin/main)"
pnpm install && pnpm build
openclaw gateway restart
```

---

## 13. 주요 설정 블록 요약

### 13.1 모델 설정

```json5
{
  agents: {
    defaults: {
      model: {
        primary: "anthropic/claude-sonnet-4-5",
        fallbacks: ["openai/gpt-5.2"],
      },
    },
  },
}
```

**권장:** Anthropic Pro/Max (100/200) + Opus 4.6 — 긴 컨텍스트 강점, 프롬프트 인젝션 저항.

### 13.2 샌드박싱

```json5
{
  agents: {
    defaults: {
      sandbox: {
        mode: "non-main",   // off | non-main | all
        scope: "agent",     // session | agent | shared
        workspaceAccess: "none", // none | ro | rw
      },
    },
  },
}
```

### 13.3 하트비트

```json5
{
  agents: {
    defaults: {
      heartbeat: {
        every: "30m",
        target: "last",
      },
    },
  },
}
```

### 13.4 크론 작업

```json5
{
  cron: {
    enabled: true,
    maxConcurrentRuns: 2,
    sessionRetention: "24h",
  },
}
```

### 13.5 웹훅 (Hooks)

```json5
{
  hooks: {
    enabled: true,
    token: "shared-secret",
    path: "/hooks",
  },
}
```

### 13.6 Hot Reload 모드

| 모드 | 동작 |
|---|---|
| `hybrid` (기본) | 안전한 변경 즉시 적용, 중요 변경은 자동 재시작 |
| `hot` | 안전한 변경만 적용, 재시작 필요 시 경고 |
| `restart` | 모든 변경에 재시작 |
| `off` | 파일 감시 비활성화 |

---

## 14. Onboarding 흐름

### 14.1 CLI 위저드 (권장)

```bash
openclaw onboard --install-daemon
```

위저드가 하는 일:
- 인증 구성 (Anthropic setup-token / OpenAI Codex OAuth / API 키)
- Gateway 설정 (포트, 바인드, 인증)
- 채널 설정 (선택)
- 데몬 서비스 설치

### 14.2 macOS 앱 온보딩

1. macOS 경고 승인
2. 로컬 네트워크 찾기 승인
3. 보안 고지 확인
4. Local vs Remote 선택
5. 권한 요청 (Automation, Notifications, Accessibility, Screen Recording, Microphone, Speech Recognition, Camera, Location)
6. CLI 설치 (선택)
7. 온보딩 채팅 세션

---

## 15. FAQ 핵심 사항

- **빠른 문제 해결:** `openclaw doctor` → 출력 확인 → 수정 적용
- **Raspberry Pi:** 지원, 전용 팁 있음
- **Bun:** Gateway 런타임으로 비권장 (실험적)
- **Claude 구독 없이 API 키만으로 가능?** 예 — API 키 제공하면 됨
- **Claude Max 구독 사용 가능?** 예 — setup-token 흐름
- **로컬 모델:** 캐주얼 대화에는 OK
- **데이터 저장:** 모두 로컬 (`~/.openclaw/`)
- **여러 워크스페이스/에이전트:** 제한 없음
- **설치 소요 시간:** 일반적으로 수분
- **`openclaw update`로 자기 업데이트 가능?** 예

---

## 16. 유용한 링크

- **공식 문서:** https://docs.openclaw.ai
- **GitHub:** https://github.com/openclaw/openclaw
- **Discord 커뮤니티:** https://discord.gg/clawd
- **Getting Started:** https://docs.openclaw.ai/start/getting-started
- **Configuration Reference:** https://docs.openclaw.ai/gateway/configuration-reference
- **Security:** https://docs.openclaw.ai/gateway/security
- **FAQ:** https://docs.openclaw.ai/help/faq
- **Docker:** https://docs.openclaw.ai/install/docker
- **Nix:** https://docs.openclaw.ai/install/nix
- **Updating:** https://docs.openclaw.ai/install/updating
- **Multi-Agent:** https://docs.openclaw.ai/concepts/multi-agent
- **Multiple Gateways:** https://docs.openclaw.ai/gateway/multiple-gateways
- **Agent Workspace:** https://docs.openclaw.ai/concepts/agent-workspace
- **OAuth:** https://docs.openclaw.ai/concepts/oauth
- **VISION.md:** https://github.com/openclaw/openclaw/blob/main/VISION.md
- **SECURITY.md:** https://github.com/openclaw/openclaw/blob/main/SECURITY.md
- **Nix-OpenClaw:** https://github.com/openclaw/nix-openclaw
- **DeepWiki:** https://deepwiki.com/openclaw/openclaw
