# AI 업계 브리핑: 2026년 1월~2월

> 수집일: 2026-02-20 | 범위: 2026-01-01 ~ 2026-02-20 | 실제 발생 사건만 포함

---

## 1. OpenAI, ChatGPT 광고 도입 발표 및 ChatGPT Go 글로벌 출시
- **날짜**: 2026-01-16
- **무슨 일**: OpenAI가 ChatGPT에 광고를 도입하겠다고 공식 발표했다. 무료 및 Go($8/월) 티어 사용자 대상으로 "명확히 구분된" 후원 광고를 대화 하단에 표시할 예정이라고 밝혔다. 동시에 ChatGPT Go 구독을 미국 및 전 세계로 확대 출시했다.
- **핵심 수치**: Go 구독 월 $8, 171개국 출시, GPT-5.2 무료 사용자 5시간당 10개 메시지 제한
- **왜 중요**: AI 챗봇 시장 최초의 본격 광고 수익 모델 도입. 구독 외 수익 다각화로 OpenAI의 비즈니스 모델이 근본적으로 변화하기 시작한 시점.
- **출처**: https://openai.com/index/our-approach-to-advertising-and-expanding-access/

## 2. Anthropic, "Claude는 광고 없이 유지" 선언 및 슈퍼볼 광고
- **날짜**: 2026-02-04
- **무슨 일**: Anthropic이 Claude에 광고를 도입하지 않겠다고 공식 선언하며, OpenAI의 ChatGPT 광고 도입을 겨냥한 슈퍼볼 TV 광고를 공개했다. "Claude는 생각하는 공간"이라는 메시지로 광고 없는 AI 어시스턴트의 가치를 강조했다.
- **핵심 수치**: 슈퍼볼 30초 광고 + 프리게임 1분 광고, 4개의 유튜브 광고 시리즈
- **왜 중요**: AI 업계에서 광고 모델 vs 구독 모델의 철학적 대립이 본격화. Anthropic이 OpenAI와 명확한 차별화 전략을 구축한 상징적 순간.
- **출처**: https://www.anthropic.com/news/claude-is-a-space-to-think

## 3. Anthropic, Claude Opus 4.6 출시
- **날짜**: 2026-02-05
- **무슨 일**: Anthropic이 최고 성능 모델 Claude Opus 4.6을 출시했다. 에이전틱 코딩, 컴퓨터 사용, 도구 활용, 금융 분석 등에서 업계 최고 성능을 기록했다. 1M 토큰 컨텍스트 윈도우(베타)를 Opus급 모델로는 처음 도입했다.
- **핵심 수치**: Terminal-Bench 2.0 1위, Humanity's Last Exam 1위, GDPval-AA에서 GPT-5.2 대비 144 Elo 포인트 우위, 가격 $5/$25 per M tokens
- **왜 중요**: Anthropic이 코딩·에이전트 영역에서 업계 최고 모델 자리를 확보. 엔터프라이즈 AI 시장에서 Anthropic의 경쟁력을 결정적으로 강화한 릴리스.
- **출처**: https://www.anthropic.com/news/claude-opus-4-6

## 4. ChatGPT 광고 테스트 시작 — Best Buy, Expedia 등 첫 광고주 등장
- **날짜**: 2026-02-09
- **무슨 일**: OpenAI가 ChatGPT에서 실제 광고 테스트를 시작했다. Expedia, Qualcomm, Best Buy, Enterprise Mobility 등이 첫 광고주로 참여했으며, Omnicom, WPP, Dentsu 등 대형 광고 홀딩사가 클라이언트를 대거 투입했다.
- **핵심 수치**: 광고주 최소 투자 $200,000, 전체 응답의 약 0.8%에서 광고 노출, Omnicom 30개 이상 클라이언트 참여
- **왜 중요**: AI 챗봇에 광고가 실제로 표시된 역사적 첫 사례. 전통 디지털 광고 생태계가 AI 대화 인터페이스로 확장되는 전환점.
- **출처**: https://www.adweek.com/media/first-ads-on-chat-gpt-best-buy-expedia-qualcomm/

## 5. Anthropic, $300억 시리즈 G 펀딩 — 기업가치 $3,800억
- **날짜**: 2026-02-12
- **무슨 일**: Anthropic이 GIC와 Coatue가 주도한 시리즈 G 라운드에서 $300억을 조달하며 기업가치 $3,800억(포스트머니)을 달성했다. 연간 반복 매출(run-rate revenue)이 $140억에 달하며, 최근 3년간 매년 10배 이상 성장했다고 밝혔다.
- **핵심 수치**: $300억 조달, $3,800억 기업가치, $140억 연간 반복 매출, 매년 10x 성장
- **왜 중요**: AI 스타트업 역사상 최대 규모 펀딩 라운드 중 하나. Anthropic이 OpenAI와 함께 AI 업계의 양대 축임을 재확인한 사건.
- **출처**: https://www.anthropic.com/news

## 6. NPR 전 앵커 David Greene, Google AI 팟캐스트 음성 도용으로 소송
- **날짜**: 2026-02-15
- **무슨 일**: NPR Morning Edition 전 진행자 David Greene이 Google의 NotebookLM AI 팟캐스트 남성 호스트 음성이 자신의 목소리를 불법 복제한 것이라며 소송을 제기했다. Google은 부인했지만, Greene의 동료들은 유사성이 "소름끼칠 정도"라고 증언했다.
- **핵심 수치**: NotebookLM 2023년 출시 이후 수억 건의 AI 팟캐스트 생성
- **왜 중요**: AI 음성 복제와 개인 권리의 법적 충돌이 본격화. AI가 유명인의 음성을 훈련 데이터로 활용한 것에 대한 최초의 주요 소송 중 하나.
- **출처**: https://www.washingtonpost.com/technology/2026/02/15/david-greene-google-ai-podcast/

## 7. OpenAI, ChatGPT 'Lockdown Mode' 및 'Elevated Risk' 라벨 도입
- **날짜**: 2026-02-16
- **무슨 일**: OpenAI가 ChatGPT에 Lockdown Mode를 도입했다. 프롬프트 인젝션 공격으로부터 고위험 사용자를 보호하기 위한 고급 보안 설정으로, 웹 브라우징을 캐시된 콘텐츠로 제한하고 외부 시스템과의 상호작용을 엄격히 통제한다. ChatGPT, Atlas, Codex에 'Elevated Risk' 라벨도 표준화했다.
- **핵심 수치**: Enterprise, Edu, Healthcare, Teachers 플랜 대상, 일부 기능 완전 비활성화
- **왜 중요**: AI 에이전트가 더 많은 도구와 웹에 접근하면서 보안 위협이 현실화됨을 인정한 조치. 엔터프라이즈 AI 보안의 새로운 기준을 제시.
- **출처**: https://openai.com/index/introducing-lockdown-mode-and-elevated-risk-labels-in-chatgpt/

## 8. 미 국방부, Anthropic을 "공급망 리스크"로 지정 검토
- **날짜**: 2026-02-16
- **무슨 일**: Axios 보도에 따르면, 미 국방부가 Anthropic을 "공급망 리스크"로 지정하는 것을 검토 중이다. 지정될 경우, 미군과 거래하려는 모든 기업은 Anthropic과의 관계를 단절해야 한다. 양측은 수개월간 군사적 AI 도구 사용 조건에 대해 협상해왔다.
- **핵심 수치**: 미군 관련 모든 계약자에 영향, 수개월간 협상 진행 중
- **왜 중요**: AI 기업의 안전 중시 정책과 군사적 활용 사이의 근본적 긴장이 표면화. Anthropic의 방위산업 접근에 중대한 장벽이 될 수 있는 사건.
- **출처**: https://www.axios.com/2026/02/16/anthropic-defense-department-relationship-hegseth

## 9. Anthropic, Claude Sonnet 4.6 출시 — 무료 사용자 기본 모델
- **날짜**: 2026-02-17
- **무슨 일**: Anthropic이 Claude Sonnet 4.6을 출시하고 무료 및 Pro 사용자의 기본 모델로 설정했다. 코딩, 컴퓨터 사용, 에이전트 기획, 지식 업무 전반에서 대폭 개선되었으며, 1M 토큰 컨텍스트 윈도우(베타)를 지원한다. Claude Code에서 사용자의 70%가 Sonnet 4.5보다 Sonnet 4.6을 선호했다.
- **핵심 수치**: $3/$15 per M tokens, 1M 토큰 컨텍스트, Claude Code에서 70% 선호율, Opus 4.5 대비 59% 선호
- **왜 중요**: Opus급 성능을 Sonnet 가격으로 제공함으로써 AI 코딩 및 에이전트 시장의 가격/성능 기준을 재정의.
- **출처**: https://www.anthropic.com/news/claude-sonnet-4-6

## 10. Netflix, ByteDance Seedance 2.0에 "즉각 소송" 위협
- **날짜**: 2026-02-18
- **무슨 일**: Netflix가 ByteDance에 3일 내 대응하라는 최후통첩과 함께 "즉각 소송" 위협 서한을 보냈다. Seedance 2.0 AI 비디오 서비스가 Stranger Things, Squid Game, Bridgerton 등의 캐릭터와 세계관을 무단으로 복제하고 있다고 주장했다. Disney, Paramount, Warner Bros.도 유사한 조치를 취했다.
- **핵심 수치**: Netflix 4개 프랜차이즈 침해 주장, 4개 스튜디오가 ByteDance 비난, 3일 시한
- **왜 중요**: AI 비디오 생성 기술이 콘텐츠 산업과 정면 충돌한 최대 규모의 법적 분쟁. AI와 저작권의 경계에 대한 판례를 만들 수 있는 사건.
- **출처**: https://variety.com/2026/tv/news/netflix-bytedance-immediate-litigation-seedance-ai-1236666084/

## 11. Meta, AI 친화 법안 위한 선거 자금 $6,500만 투입 계획
- **날짜**: 2026-02-18
- **무슨 일**: Meta가 AI 관련 법안에 우호적인 정치인을 지원하기 위해 $6,500만을 선거 자금으로 투입할 계획이라고 NYT가 보도했다. 공화당 대상 "Forge the Future Project"와 민주당 대상 "Making Our Tomorrow" 두 개의 새로운 슈퍼 PAC을 설립했다.
- **핵심 수치**: $6,500만 선거 자금, 2개 신규 슈퍼 PAC (양당 대상), 기존 캘리포니아 슈퍼 PAC에 추가
- **왜 중요**: 빅테크의 AI 규제 로비가 선거 직접 개입 수준으로 확대. AI 산업이 미국 정치 지형을 적극적으로 재편하려는 시도.
- **출처**: https://www.nytimes.com/2026/02/18/technology/meta-65-million-election-ai.html

## 12. Epic Games, AI 디지털 휴먼 기업 Meshcapade 인수
- **날짜**: 2026-02-18
- **무슨 일**: Epic Games가 Max Planck 연구소 스핀오프인 Meshcapade를 인수했다. Meshcapade 팀은 Epic의 AI 연구팀에 합류하여 Unreal Engine과 MetaHumans 기술 발전에 기여할 예정이다.
- **핵심 수치**: 게임·영화·엔터테인먼트 전 분야 적용, Unreal Engine + MetaHumans 통합
- **왜 중요**: 게임 엔진 최강자가 AI 기반 디지털 휴먼 기술을 내재화. 게임·영화 산업의 캐릭터 제작 워크플로가 AI로 근본적으로 변화할 전조.
- **출처**: https://www.mpg.de/26082348/max-planck-spin-off-meshcapade-draws-epic-games-to-tuebingen

## 13. Google, Gemini 3.1 Pro 출시 — 추론 성능 2배 이상 향상
- **날짜**: 2026-02-19
- **무슨 일**: Google이 Gemini 3.1 Pro를 출시했다. "단순한 답이 충분하지 않은 작업"을 위해 설계된 모델로, Gemini API, Vertex AI, Gemini 앱, NotebookLM, Google Antigravity, Android Studio 등에 배포되었다. ARC-AGI-2 벤치마크에서 3 Pro 대비 2배 이상의 추론 성능을 달성했다.
- **핵심 수치**: ARC-AGI-2: 77.1% (3 Pro 대비 2배 이상), Gemini API + Vertex AI + Gemini 앱 + NotebookLM 동시 출시
- **왜 중요**: Google이 AI 모델 업데이트 속도를 가속화하며 OpenAI·Anthropic과의 경쟁을 강화. "에이전틱 워크플로"를 위한 범용 모델 경쟁이 심화.
- **출처**: https://blog.google/innovation-and-ai/models-and-research/gemini-models/gemini-3-1-pro/

---

*이 브리핑은 The Verge, Anthropic, OpenAI, Google, Adweek, Variety, Axios 등의 1차 소스를 기반으로 작성되었습니다. 2025년 이전 사건은 포함되지 않았습니다.*
