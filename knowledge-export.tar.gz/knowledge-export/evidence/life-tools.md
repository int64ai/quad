# 개인 라이프 효율화 AI 도구 — 증거 기반 수집
> 수집일: 2026-02-20
> 기준: 실제 유저 증언/데이터 우선. 광고성 주장은 별도 표기.
> 도구 개수: 18개

---

## 1. ChatGPT (OpenAI)

- **이름:** ChatGPT (GPT-4 Turbo / GPT-5)
- **뭘 하는 도구:** 범용 AI 대화 — 글쓰기, 요약, 브레인스토밍, 코딩, 리서치, 일상 질문
- **실제 효과 증거:**
  - 2025년 기준 1.9억 일간 사용자, 주간 8억 활성 사용자 (electroiq.com 통계)
  - 유저당 평균 하루 16분 사용 (electroiq.com)
  - 개인 용도 사용률 83.27%로 1위 (buttercms.com 설문)
  - 사용 패턴: 글쓰기 28.1%, 실용 가이드 28.3%, 정보 탐색 21.3% (Made Visual Daily, 1.1M 메시지 분석)
  - r/productivity 유저: "프리랜서가 이메일 관리에 ChatGPT 활용, 주당 5시간 절약, 200개 미읽음→매일 0개" (aiearnerhub.com Reddit 정리)
  - Peter Yang (Creator Economy 뉴스레터): "ChatGPT Projects로 팟캐스트 후반작업 자동화, 주당 3-5시간 절약"
  - Medium 유저: "PRD 작성 3시간→30분으로 단축 (6x 생산성 향상)" — Claude Code 비교 기사
- **무료/유료:** 무료 (GPT-3.5), $20/월 (Plus), $200/월 (Pro)
- **대체한 것:** 구글 검색, 수동 이메일 초안 작성, 브레인스토밍 메모
- **한계:** 환각(hallucination) 발생, 최신 정보 부족 가능, 프롬프트 엔지니어링에 시간 투자 필요
- **출처 URL:**
  - https://electroiq.com/stats/claude-vs-chatgpt-statistics/
  - https://www.aiearnerhub.com/ultimate-ai-productivity-hacks-from-reddit/
  - https://creatoreconomy.so/p/chatgpt-claude-gemini-the-best-ai-model-for-each-task-2025

---

## 2. Claude (Anthropic)

- **이름:** Claude 3.5 / Claude 4 / Claude Code
- **뭘 하는 도구:** 글쓰기 (스타일 제어 우수), 코딩, 문서 분석, 장문 처리 (200K 토큰)
- **실제 효과 증거:**
  - 월간 활성 사용자 약 3,000만 (2025, SQ Magazine), 만족도 92%
  - Claude Code: 4개월 만에 $500M ARR 달성 (aakashgupta Medium)
  - Medium 유저 후기: "47개 고객 인터뷰 분석 + PRD 작성 + 프로토타입 제작을 하루 오후에 완료"
  - LinkedIn 유저 Nick DC: "ChatGPT에서 Claude로 전환, 출력 품질이 훨씬 우수"
  - 스타일 커스터마이징이 ChatGPT보다 자연스럽다는 다수 증언 (LinkedIn 비교 포스트)
  - r/AIAssisted 유저: "안전성에 초점을 맞춘 점이 좋아서 테스트 중"
- **무료/유료:** 무료 (제한적), $20/월 (Pro), 기업용 별도
- **대체한 것:** ChatGPT 일부 사용 시나리오 (특히 글쓰기, 스타일 제어)
- **한계:** 이미지/비디오 생성 불가, ChatGPT 대비 통합(plugin) 생태계 작음
- **출처 URL:**
  - https://electroiq.com/stats/claude-vs-chatgpt-statistics/
  - https://aakashgupta.medium.com/i-stopped-using-chatgpt-after-discovering-this-ai-tool-and-it-changed-everything-6e67846eacfa
  - https://www.linkedin.com/posts/nickdc_like-many-online-services-chatgpt-is-now-activity-7409458673623658496-F0r6

---

## 3. Perplexity AI

- **이름:** Perplexity AI
- **뭘 하는 도구:** AI 기반 검색 엔진 — 출처 인용 포함 답변, 리서치 가속
- **실제 효과 증거:**
  - 2025년 5월 기준 월 7.8억 쿼리, 전년 대비 3.4배 성장 (aibusinessweekly.net)
  - "리서치 시간 30% 단축" (firstaimovers.com, Gartner 데이터 기반)
  - 연구자 친구 증언: "문헌 검토 시간 절반으로 줄임" (skywork.ai)
  - 학술 컨텐츠 정확도 95%, ChatGPT 89% 대비 우위 (incremys.com)
  - 응답당 20개 이상 웹사이트 검색 — 수동 검색 대비 훨씬 넓은 커버리지
  - LinkedIn Prakash Raj: "딥 리서치, 검증된 소스, 데이터 기반 인사이트에 가장 강력한 도구. 시간 → 분 단위로 절약"
- **무료/유료:** 무료 (하루 제한), $20/월 (Pro)
- **대체한 것:** 구글 검색 + 여러 링크 클릭해서 종합하는 과정
- **한계:** 복잡한 쿼리에 약간 느림, 최신 실시간 정보는 구글이 나을 수 있음, AI 응답 15%까지 오류 가능 (Gartner)
- **출처 URL:**
  - https://aibusinessweekly.net/p/what-is-perplexity-ai-complete-guide-2025
  - https://www.firstaimovers.com/p/perplexity-ai-vs-google-2025-complete-research-guide
  - https://skywork.ai/blog/news/perplexity-vs-google-ai-overviews-2025-which-search-wins/

---

## 4. Cursor (AI 코딩 IDE)

- **이름:** Cursor
- **뭘 하는 도구:** AI 네이티브 코드 편집기 — 멀티파일 리팩토링, 코드 생성, 디버깅
- **실제 효과 증거:**
  - 복잡 태스크 35-45% 빠른 완료 (50명 개발자, 100개 태스크 벤치마크 — localaimaster.com)
  - CRUD 기능 구현: 3.5분 vs 8분(Copilot), +129% 속도 향상
  - 멀티파일 리팩토링: 6분 vs 18분(Copilot), +200% 속도 향상
  - LinkedIn 유저 Jvenu: "Composer 모드로 멀티파일 리팩토링을 병렬 실행, 주니어 개발팀 10배 속도"
  - 물류회사: "레거시 코드 유지보수 시간 45% 감소, 인시던트 대응 50% 개선" (SmartDev 클라이언트 데이터)
  - 1T 토큰 이상 사용한 헤비 유저 증언 (dev.to)
- **무료/유료:** 무료 (제한적), $20/월 (Pro), $40/월 (Ultra)
- **대체한 것:** 일반 VS Code + 수동 코딩
- **한계:** 학습 곡선 1-2주, 니치/레거시 프레임워크에서 환각, 높은 사용량 시 비용 부담
- **출처 URL:**
  - https://localaimaster.com/tools/cursor-vs-github-copilot
  - https://smartdev.com/github-copilot-vs-cursor-vs-custom-ai-copilots/
  - https://www.linkedin.com/posts/jvenu94_cursoride-ai-softwaredevelopment-activity-7409292405843288065-jUPU

---

## 5. GitHub Copilot

- **이름:** GitHub Copilot
- **뭘 하는 도구:** AI 코드 자동완성 — IDE 내 인라인 코드 제안
- **실제 효과 증거:**
  - 2025년 기준 1,500만+ 활성 사용자, Fortune 100 기업 90% 사용 (smartdev.com)
  - 생산성 20-30% 향상, PR 완료 25% 가속, 코드 리뷰 15-20% 단축
  - 첫 시도 정확도 91.2% (Cursor 87.3% 대비 높음)
  - 학습 곡선 2-3일로 짧음
  - 개인 사용률 8.89% (buttercms 설문)
- **무료/유료:** $10/월 (Individual), $19/월 (Business)
- **대체한 것:** 수동 코드 타이핑, Stack Overflow 검색
- **한계:** 단일 파일 중심, 복잡한 멀티파일 작업에서 Cursor 대비 열세, 단순 자동완성에 가까움
- **출처 URL:**
  - https://smartdev.com/github-copilot-vs-cursor-vs-custom-ai-copilots/
  - https://localaimaster.com/tools/cursor-vs-github-copilot

---

## 6. Motion (AI 일정 관리)

- **이름:** Motion
- **뭘 하는 도구:** AI 기반 자동 일정 관리 — 태스크, 캘린더, 프로젝트 관리 통합
- **실제 효과 증거:**
  - r/productivity 유저: "자동으로 하루를 계획하고, 미완료 작업을 재스케줄링"
  - Superhuman 블로그 리뷰: "다음에 뭘 할지 알려줘서 정신적 에너지 낭비 감소"
  - efficient.app 비교: "태스크 입력하면 AI가 최적 시간에 배치, 데드라인 기반 우선순위"
  - Reddit r/UseMotion 유저 Traveler-183: "대안을 찾았지만 Motion만큼 좋은 건 없었다. 다만 가격과 버그가 문제"
  - Reddit r/ExecutiveAssistants: "Motion 시도했지만 마음에 안 들었다" — 호불호 갈림
  - 같은 스레드: "Reclaim.ai: 견고하지만 모바일 앱 없음" — 대안 비교
- **무료/유료:** $29/월 (Individual)부터
- **대체한 것:** 수동 캘린더 관리, 투두 리스트 + 캘린더 번갈아 보기
- **한계:** 개인 사용자에겐 비쌈 ($29/월), 자동화에 의존하다보면 유연성 저하, 버그 보고 있음, 학습 곡선
- **출처 URL:**
  - https://blog.superhuman.com/best-ai-tools-for-productivity/
  - https://efficient.app/compare/motion-vs-reclaim
  - https://www.reddit.com/r/UseMotion/new/

---

## 7. Reclaim.ai (AI 캘린더)

- **이름:** Reclaim.ai
- **뭘 하는 도구:** AI 기반 타임블로킹 — 습관, 포커스 타임, 스마트 미팅 자동 스케줄링
- **실제 효과 증거:**
  - morgen.so 비교: "개인 시간 블로킹에 최고, 습관(운동, 명상, 독서) 자동 스케줄링"
  - efficient.app: "점심시간 놓치는 것에 지쳤다면 → Reclaim이 시간 보호"
  - 무료 플랜 제공 — 유료는 $10/월부터
  - Reddit r/ExecutiveAssistants: "Reclaim.ai: 견고함. 모바일 앱 없음이 단점"
  - 연구: "10-12분 일일 계획이 2시간 절약, 생산성 25% 향상" (Brian Tracy, morgen.so 인용)
- **무료/유료:** 무료 플랜 있음, $10/월 (Starter)부터
- **대체한 것:** 수동 캘린더 + 타이머 + 습관 추적 앱
- **한계:** 2025년 기준 모바일 앱 없음(현재는 불명), Motion 대비 태스크/프로젝트 관리 약함
- **출처 URL:**
  - https://efficient.app/compare/motion-vs-reclaim
  - https://www.morgen.so/blog-posts/motion-vs-reclaim
  - https://www.reddit.com/r/ExecutiveAssistants/comments/1n8j1q1/

---

## 8. Otter.ai (회의 녹취/요약)

- **이름:** Otter.ai
- **뭘 하는 도구:** 실시간 회의 녹취, 화자 식별, 자동 요약, 액션 아이템 추출
- **실제 효과 증거:**
  - 공식 주장: "주 4시간 이상 절약" (otter.ai 홈페이지)
  - Matt Sodnicar (마케팅 매니저): "주당 확실히 몇 시간 절약. 기하급수적 시간 절감"
  - Brandon Savage: "거의 매일 사용… 초능력 같다"
  - 15분 오디오 → 5-6분에 녹취 완료 vs 인간 1시간 (elegantthemes.com)
  - G2 리뷰: "모든 회의 녹화의 단일 진실 소스. AI로 특정 포인트 질문하고, 녹화 기반 이메일 작성"
  - r/productivity 유저: "tl;dv가 Tactiq보다 정확. 원격 근무자에게 진짜 시간 절약" (유사 도구 비교)
  - CNET: "오디오+텍스트 결합이 편리. 다만 녹취 품질은 완벽하지 않음"
- **무료/유료:** 무료 (월 5시간, 회당 30분), Pro $16.99/월
- **대체한 것:** 수동 회의 메모, 녹음 후 재청취
- **한계:** 고급 기능은 유료, 다중 화자 환경에서 정확도 완벽하지 않음, AI 봇이 회의에 참여하는 것이 외부 미팅에서 어색할 수 있음
- **출처 URL:**
  - https://otter.ai/
  - https://www.elegantthemes.com/blog/business/otter-ai
  - https://www.cnet.com/tech/services-and-software/otter-ai-review/

---

## 9. Grammarly (AI 글쓰기 보조)

- **이름:** Grammarly
- **뭘 하는 도구:** 실시간 문법/스타일 교정, AI 기반 글쓰기 제안, 톤 조절
- **실제 효과 증거:**
  - 공식 연구 (450명+ 전문직): "Grammarly 사용 시 오류 20% 감소, 일일 30-70개 오류 줄임"
  - "이메일 작성 중 비활동 시간 71% 감소" — 집중력 유지 효과 (grammarly.com/blog/engineering)
  - "CRM에서 단어/분 40% 증가" (네이티브 맞춤법 검사 없는 도구에서)
  - 기업 데이터: "연간 유저당 20일 절약", "글쓰기/편집 시간 50% 감소"
  - 92% 유저가 "시간 절약" 보고, 76%가 "더 많은 일 완수" (grammarly.com/business)
  - r/productivity Reddit 유저: "영어가 모국어가 아닌 사람으로서, 확장프로그램 설치하면 실시간 교정. 사람들이 내 영어가 좋다고 생각하게 만듦"
  - Reddit 비판: "AI 교정이 내 스타일과 안 맞을 때 있음", "AI 감지 기능은 정확도 부족"
- **무료/유료:** 무료 (기본), $12/월 (Premium), $15/월 (Business)
- **대체한 것:** 수동 교정, 동료에게 리뷰 부탁, 네이티브 스펠체크
- **한계:** AI 제안이 항상 스타일에 맞지 않음, AI 감지 기능 불안정, 무료 버전 제한적
- **출처 URL:**
  - https://www.grammarly.com/blog/engineering/effects-of-ai-at-work/
  - https://www.grammarly.com/business/learn/unlocking-team-efficiency/
  - https://gmelius.com/blog/is-grammarly-ai-good

---

## 10. Notion AI

- **이름:** Notion AI
- **뭘 하는 도구:** 노트/문서 내 AI 요약, 작성, 번역, 데이터베이스 자동화
- **실제 효과 증거:**
  - Superhuman 블로그 테스트 리뷰: "내부 문서 요약에 최적"
  - heyalice.app: "일일 몇 시간 절약 — 정보 검색 개선"
  - lindy.ai 비교표: $12/월부터, Workspace-native 사용
  - Reddit r/AiReviewInsiderHQ: "Notion은 공동작업/대시보드에 강점, 개인 지식관리는 Obsidian이 나음"
  - YouTube (Be Productive): "점점 더 많은 유저가 Notion → Obsidian 이동 중 — 속도, 오프라인, 로컬 파일 선호"
- **무료/유료:** 무료 (제한적 AI), $12/월 (Plus + AI)
- **대체한 것:** Google Docs + 스프레드시트 + 메모앱 조합
- **한계:** 오프라인 불안정, 복잡한 데이터베이스 학습곡선 높음, AI 품질 범용 LLM 대비 제한적
- **출처 URL:**
  - https://blog.superhuman.com/best-ai-tools-for-productivity/
  - https://www.reddit.com/r/AiReviewInsiderHQ/comments/1obj8er/
  - https://photes.io/blog/posts/notion-vs-obsidian-which-note-taking-app-wins-2025

---

## 11. NotebookLM (Google)

- **이름:** Google NotebookLM (Gemini 2.0 기반)
- **뭘 하는 도구:** AI 리서치 어시스턴트 — PDF/문서 분석, 요약, 오디오/비디오 오버뷰 생성
- **실제 효과 증거:**
  - Reddit r/notebooklm (10 스레드, 122 댓글 분석): "긍정 센티먼트" (toksta.com)
  - 유저들이 "세컨드 브레인", "마음의 외골격"으로 묘사 — 인지적 안도감 (Medium 심층 분석)
  - Medium 유저: "2025년 유일하게 선택할 리서치 도구. 기술 콘텐츠 이해 10배 가속"
  - Tom's Guide 테스터: "ChatGPT, Perplexity, Claude를 버리고 NotebookLM — 스마트 후속 질문 제안이 차별점"
  - 연구자용: "마인드맵 → AI 요약 → 원문 바로가기, 3단계 디테일 수준으로 대규모 지식 탐색 용이"
  - 오디오 오버뷰: "두 AI 호스트가 학술 주제를 자연스러운 대화로 토론" — 2025년 가장 바이럴된 기능
  - 소스 기반 접근(Source-grounding): 업로드한 자료만 참조 → 환각 대폭 감소
- **무료/유료:** 무료 (Google 계정)
- **대체한 것:** 수동 문헌 리뷰, 여러 PDF 번갈아 읽기, 스터디 가이드 수동 작성
- **한계:** UX 혼란스러운 부분 있음, 큰 문서 편향 가능, 정확도 검증 필요
- **출처 URL:**
  - https://www.toksta.com/products/notebook-lm
  - https://medium.com/@jimmisound/the-cognitive-engine-a-comprehensive-analysis-of-notebooklms-evolution-2023-2026-90b7a7c2df36
  - https://www.tomsguide.com/ai/i-ditched-chatgpt-perplexity-and-claude-for-notebooklm-research-and-didnt-expect-these-results

---

## 12. Superhuman (AI 이메일)

- **이름:** Superhuman
- **뭘 하는 도구:** AI 기반 이메일 클라이언트 — 키보드 중심 인터페이스, AI 요약, 자동 분류
- **실제 효과 증거:**
  - 공식 주장: "주 4시간 이상 절약", "Inbox Zero 달성"
  - Nick Lafferty (4년 리뷰): "지금까지 사용한 최고의 이메일 클라이언트. 비싸지만 절약하는 시간이 가격을 상쇄"
  - 6년 사용 + 영수증 증거 (nicklafferty.com)
  - Shortwave 비교: "Gmail 대비 Inbox Zero 45% 빠르게 달성" (경쟁사 주장)
  - techpoint.africa 리뷰: "Write with AI, Auto Summarize, Ask AI가 시간과 정신 에너지 절약"
  - toksta.com Reddit 센티먼트: "키보드 단축키와 Split Inbox가 진짜 효율 향상. AI는 부차적"
  - r/AIAssisted 유저: "Gmail AI로 돌아감, Superhuman에서 lol" — 가격 대비 가치 회의
  - 2025년 7월 Grammarly가 인수
- **무료/유료:** $30/월
- **대체한 것:** Gmail, Outlook
- **한계:** 비쌈 ($30/월), 팀 기능 부족, CRM 확장 제한, 개인 용도에는 과잉일 수 있음
- **출처 URL:**
  - https://nicklafferty.com/reviews/superhuman/
  - https://www.toksta.com/products/superhuman
  - https://techpoint.africa/guide/i-tested-superhuman-ai/

---

## 13. Zapier (AI 워크플로우 자동화)

- **이름:** Zapier
- **뭘 하는 도구:** 앱 간 자동화 연결 — 트리거→액션 기반 워크플로우, AI 어시스턴트
- **실제 효과 증거:**
  - 7,000개+ 앱 연동
  - 시카고 마케팅 에이전시: "주 6시간 절약, 소셜미디어 콘텐츠 자동화" (aiworkshop.info)
  - r/productivity 유저: "AI 생성 리포트를 이메일로 자동 발송 — 분 단위로 세팅" (aiearnerhub.com Reddit 정리)
  - 물류/이커머스 사례: "주문→CRM→알림→문서 생성까지 자동화"
  - 무료 플랜: 100 태스크/월
- **무료/유료:** 무료 (100 태스크/월), $19.99/월 (Professional), $69/월 (Team)
- **대체한 것:** 수동 복붙, 앱 간 번갈아 전환, 반복 작업
- **한계:** 스케일업 시 비용 급증, 복잡한 분기 로직은 Make.com이 나음, 에러 핸들링 기본적
- **출처 URL:**
  - https://zapier.com/blog/best-ai-productivity-tools/
  - https://aiworkshop.info/blog/tools/make-vs-zapier-ai-automation/
  - https://www.aiearnerhub.com/ultimate-ai-productivity-hacks-from-reddit/

---

## 14. Make.com (고급 자동화)

- **이름:** Make.com (구 Integromat)
- **뭘 하는 도구:** 비주얼 워크플로우 빌더 — 복잡한 멀티스텝 자동화, AI 모델 연동
- **실제 효과 증거:**
  - 이커머스 사례: "주 12시간 절약, 전환율 35% 향상 — GPT-4 + DALL-E + Shopify 자동화" (aiworkshop.info)
  - 컨설팅 회사: "주 8시간 절약, 클라이언트 응답 40% 가속 — Claude AI 분석 + CRM 자동화"
  - 에러 핸들링: "재시도, 무시, 알림 로직 → 오경보 80% 감소" (이커머스 사례)
  - 무료 플랜: 1,000 오퍼레이션/월 (Zapier 100보다 관대)
  - Zapier 대비 복잡한 분기/데이터 변환에 우수
- **무료/유료:** 무료 (1,000 ops/월), 유료 플랜 별도
- **대체한 것:** Zapier (복잡한 워크플로우의 경우), 수동 데이터 처리
- **한계:** 학습곡선 높음, 오퍼레이션 기반 과금이 예측 어려움, 기술적 이해 필요
- **출처 URL:**
  - https://aiworkshop.info/blog/tools/make-vs-zapier-ai-automation/
  - https://readylogic.co/make-vs-zapier-best-automation-tool-in-2025/

---

## 15. n8n (셀프호스팅 AI 워크플로우)

- **이름:** n8n (node everywhere node)
- **뭘 하는 도구:** 오픈소스 워크플로우 자동화 — 셀프호스팅 가능, 400개+ 통합, AI 에이전트 노드
- **실제 효과 증거:**
  - GitHub self-hosted-ai-starter-kit: 14,100 스타 (2025) — Ollama + Qdrant + PostgreSQL 포함
  - Medium 유저 syrom: "뉴스레터 수집 → AI 요약 → Notion 저장 자동화" (실제 A-Z 워크플로우 가이드)
  - DigitalOcean 튜토리얼: "개발자에게 완전한 통합/데이터 흐름 제어권"
  - 개인이 직접 세팅 가능: Docker Compose로 로컬 AI 환경 구축 (n8n + Ollama)
  - 클라우드 vs 셀프호스팅: 셀프호스팅 $50-500/월 (서버 사양에 따라), 관리형 $25/월부터
  - 프라이버시: 모든 데이터를 자체 서버에 보관 가능
- **무료/유료:** 오픈소스 (무료 셀프호스팅), 클라우드 $25/월부터
- **대체한 것:** Zapier/Make.com (프라이버시/커스터마이징 필요 시), 수동 스크립트
- **한계:** 셀프호스팅은 DevOps 지식 필요, 보안/유지보수 부담, 소규모 팀에겐 과잉
- **출처 URL:**
  - https://github.com/n8n-io/self-hosted-ai-starter-kit
  - https://medium.com/@syrom_85473/a-practical-n8n-workflow-example-from-a-to-z-part-1
  - https://www.digitalocean.com/community/tutorials/how-to-setup-n8n

---

## 16. Fireflies.ai / tl;dv (회의 AI)

- **이름:** Fireflies.ai / tl;dv
- **뭘 하는 도구:** 자동 회의 참석, 녹음, 녹취, 요약, 액션 아이템 추출
- **실제 효과 증거:**
  - eesel.ai 리뷰: "더 이상 메모할 필요 없음, 모든 팀 미팅 검색 가능한 히스토리 생성, 자동 액션 아이템 추출"
  - r/productivity Reddit 유저: "Tactiq에서 tl;dv로 전환 — 더 정확. Tactiq은 채팅에 '메모 중'이라고 표시해서 이상함. 원격 근무자에게 진짜 시간 절약"
  - Zoom, Google Meet 자동 참석
  - 놓친 회의도 캐치업 가능 — 전체 녹화 안 봐도 됨
- **무료/유료:** Fireflies 무료 플랜 있음, Pro $10/월 / tl;dv 무료 플랜 있음
- **대체한 것:** 수동 회의록 작성, 전용 노트테이커 배치
- **한계:** AI 봇이 미팅에 참여하는 것이 클라이언트 미팅에서 어색, 정확도 완벽하지 않음
- **출처 URL:**
  - https://www.eesel.ai/blog/ai-productivity-tools
  - https://www.reddit.com/r/productivity/comments/13k4qgq/7_ai_tools_i_use_to_boost_my_productivity/

---

## 17. CapCut (AI 비디오 편집)

- **이름:** CapCut
- **뭘 하는 도구:** AI 자동 자막 생성, 비디오 편집, TikTok/Shorts 최적화
- **실제 효과 증거:**
  - r/productivity Reddit 유저: "비디오 편집한다면 게임 체인저. 자동으로 음성 인식해서 캡션 생성"
  - TikTok 비디오 대부분의 자막이 CapCut으로 제작
  - 모바일 앱이 웹보다 기능 풍부
- **무료/유료:** 무료 (기본), Pro $9.99/월
- **대체한 것:** 수동 자막 입력, 전문 비디오 편집 소프트웨어
- **한계:** 웹 앱이 모바일 대비 기능 부족, 고급 편집은 여전히 전문 도구 필요
- **출처 URL:**
  - https://www.reddit.com/r/productivity/comments/13k4qgq/7_ai_tools_i_use_to_boost_my_productivity/

---

## 18. Saner.AI / Cal AI (개인 생활 관리)

- **이름:** Saner.AI (메모/태스크), Cal AI (칼로리 추적)
- **뭘 하는 도구:** Saner = 메모+태스크+스케줄 통합 AI 관리, Cal AI = AI 칼로리 추적
- **실제 효과 증거:**
  - r/AIAssisted Reddit 유저: "Saner AI로 메모/태스크/스케줄 관리. 대화로 관리할 수 있어서 좋음"
  - 같은 유저: "Cal AI로 칼로리 섭취 추적. 올해 몸만들기 목표"
  - saner.ai 리뷰: "ADHD, 결정 피로, 압도감에 특히 유용"
  - saner.ai: "뇌를 대체하는 게 아니라 지원하는 것"
- **무료/유료:** Saner AI 무료 플랜 있음 / Cal AI 가격 미확인
- **대체한 것:** 여러 메모앱 + 캘린더 + 투두 앱 조합, 수동 칼로리 기록
- **한계:** 상대적으로 신생 도구, 장기 사용 데이터 부족
- **출처 URL:**
  - https://www.reddit.com/r/AIAssisted/comments/1r2i29q/
  - https://www.saner.ai/blogs/best-ai-personal-assistants

---

## 부록: 핵심 통찰

### 광고 vs 실제 사용 구분
| 도구 | 광고 주장 | 실제 유저 증언 수준 |
|------|----------|-------------------|
| ChatGPT | "범용 AI" | ✅ 매우 풍부 — 수백만 유저, Reddit/LinkedIn 증언 다수 |
| Perplexity | "구글 킬러" | ✅ 풍부 — 연구자/전문직 증언 다수, 데이터 기반 |
| Cursor | "10x 개발" | ✅ 구체적 벤치마크 + 실사용자 증언 |
| Motion | "AI가 하루 계획" | ⚠️ 혼재 — 좋아하는 유저도, 버그/가격 불만도 |
| Superhuman | "4시간 절약" | ⚠️ 혼재 — 장기 유저 만족, 가격 대비 회의적 시각도 |
| Grammarly | "20일/년 절약" | ✅ 학술 연구 기반 데이터 (450명 실험) |
| NotebookLM | "리서치 파트너" | ✅ Reddit 긍정 센티먼트, 학술/리서치 유저 지지 |
| n8n | "오픈소스 자동화" | ✅ GitHub 14K 스타, 실제 워크플로우 가이드 다수 |

### 개인 세팅 가능 vs 기업용만
| 개인 세팅 가능 | 기업용 또는 팀 중심 |
|---------------|-------------------|
| ChatGPT, Claude, Perplexity | Copilot for M365 (기업 라이선스) |
| Cursor, GitHub Copilot | Moveworks (엔터프라이즈 전용) |
| n8n (셀프호스팅) | Appian, Pega (기업 자동화) |
| Zapier, Make.com | Dialpad (비즈니스 커뮤니케이션) |
| NotebookLM, Grammarly | Box AI (기업 콘텐츠 관리) |
| Motion, Reclaim.ai | |
| Otter.ai, Fireflies.ai | |
| CapCut, Saner.AI | |

### 무료로 시작 가능한 도구
- ChatGPT (무료), Claude (무료), Perplexity (무료)
- NotebookLM (무료), Grammarly (무료)
- n8n (오픈소스), Reclaim.ai (무료 플랜)
- CapCut (무료), Zapier (무료 100태스크), Make.com (무료 1,000ops)
- Otter.ai (무료 5시간/월), Fireflies.ai (무료 플랜)
