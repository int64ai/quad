# 패러다임을 깬 AI 제품/사건 증거 모음 (2025-2026)

> 수집일: 2026-02-20
> 원칙: 논리/의견 금지. 오직 증거만. "기존 상식을 뒤집은" 것만.

---

## 1. DeepSeek R1 — "AI 훈련은 수억 달러가 필요하다"는 상식 붕괴

이름/사건: DeepSeek R1 (중국 AI 연구소 DeepSeek)
시기: 2025년 1월 20일 공개
한 줄 설명: 오픈소스 추론 모델이 OpenAI o1급 성능을 훈련비 ~$5.6M으로 달성

깨진 상식: "기존에는 프론티어급 AI 모델을 만들려면 최소 수억 달러와 최첨단 GPU 수만 장이 필요하다고 생각했는데"

증거 (수치):
- 훈련 비용: ~$5.6M (DeepSeek 주장) vs GPT-4 ~$78M vs Gemini Ultra ~$191M (Stanford AI Index 2024)
- GPU: Nvidia H800 2,000장 사용 vs Meta LLaMA 3의 H100 16,000장
- AIME 수학 벤치마크: 15.6% → 71.0% (순수 RL로), majority voting 시 86.7%
- OpenAI o1 대비 70% 낮은 비용으로 동등 성능 달성
- 공개 후 수일 내 미국 앱스토어 1위, 700개 이상 오픈소스 파생 모델 생성
- Microsoft, AWS, Nvidia AI 플랫폼에 즉시 온보딩

파급효과:
- Nvidia 주가 1일 만에 17% 폭락, 시가총액 ~$560B(역대 최대 단일일 손실) 증발
- Jensen Huang 개인 자산 ~$21B 감소
- Nasdaq 3.07% 하락, "AI 거품 붕괴" 우려 확산
- 중국 AI 업계 가격 전쟁 촉발 → OpenAI 가격 정책에까지 영향
- "AI Sputnik Moment"로 명명됨
- 전 세계 AI 투자 전략 재검토 촉발

이걸 예측한 사람이 있었나? 거의 없음. Bain & Company: "Avoid overreaction, but prepare for cost disruption." 대부분 분석가는 중국이 미국 GPU 수출 제한 하에서 이 수준을 달성할 것으로 예상하지 못함.

출처 URL:
- https://source.washu.edu/2025/02/washu-expert-how-deepseek-changes-the-ai-industry/
- https://www.bain.com/insights/deepseek-a-game-changer-in-ai-efficiency/
- https://www.cnbc.com/2025/01/27/nvidia-sheds-almost-600-billion-in-market-cap-biggest-drop-ever.html
- https://www.visualcapitalist.com/deepseek-tanks-stock-market-nvidia/
- https://www.ig.com/en/news-and-trade-ideas/why-nvidia-s-share-price-dropped-17--after-deepseek-news-250128

---

## 2. 테스트 타임 컴퓨트 (Test-Time Compute) — "모델을 더 크게 만들어야 똑똑해진다"는 스케일링 상식 역전

이름/사건: Test-Time Compute / Inference-Time Scaling 패러다임
시기: 2024년 말 (o1) ~ 2025년 전반 (o3, DeepSeek R1)
한 줄 설명: 훈련 때 더 크게 만드는 대신, 추론 때 더 오래 "생각"하게 하면 작은 모델도 큰 모델을 이김

깨진 상식: "기존에는 AI를 더 똑똑하게 만들려면 파라미터 수를 늘리고 더 많은 데이터로 더 오래 훈련해야 한다고 생각했는데"

증거 (수치):
- arXiv 2408.03314: 10초 동안 "생각"하게 한 작은 모델이 14배 큰 모델의 즉답보다 우수
- DeepSeek R1: 순수 RL로 AIME 15.6% → 71.0% (자기 검증 학습만으로)
- OpenAI o3 (2025년 초): AIME 96.7%, Frontier Math 25.2%
- 분석가 전망: 2030년까지 추론이 전체 AI 컴퓨트의 75% 차지 예상
- Karpathy 정의: "RLVR(Reinforcement Learning from Verifiable Rewards)가 2025년 사실상의 새 훈련 단계로 자리 잡음"

파급효과:
- 파라미터 군비 경쟁에서 "추론 시간 최적화" 경쟁으로 전환
- "가장 중요한 아키텍처 전환은 Transformer 이후 TTC"라는 평가 (Medium, Data Science Collective)
- 프리트레이닝 컴퓨트 예산이 RLVR 쪽으로 재배분

이걸 예측한 사람이 있었나? OpenAI가 o1(2024 말)으로 처음 시연했으나, 업계 대부분은 이것이 스케일링의 주 축이 될 것으로 예상하지 못함.

출처 URL:
- https://medium.com/data-science-collective/test-time-compute-stop-training-bigger-models-start-giving-them-time-to-think-b40e41678ee7
- https://introl.com/blog/inference-time-scaling-research-reasoning-models-december-2025
- https://karpathy.bearblog.dev/year-in-review-2025/

---

## 3. Cursor — "IDE는 점진적으로 진화한다"는 상식을 깨고 SaaS 역사상 최고속 성장

이름/사건: Cursor (AI-네이티브 코드 에디터)
시기: 2023년 출시 → 2025년 폭발 성장
한 줄 설명: AI-네이티브 IDE가 16개월 만에 $0 → $1B ARR, SaaS 역대 최고속 성장 기록

깨진 상식: "기존에는 개발자 도구 시장은 점진적으로 성장하며, IDE 시장은 VS Code/JetBrains가 굳건히 장악한다고 생각했는데"

증거 (수치):
- 2023: ~$1M ARR
- 2024 말: $100M ARR (100배 성장)
- 2025년 1월: 전 세계 100만+ 유저, 유료 ~360,000명
- 2025년 3월: $200M ARR
- 2025년 4월: $300M ARR
- 2025년 5월: $500M ARR
- 2025년 11월: $1B ARR (역대 $1M → $500M 최고속 SaaS)
- 밸류에이션: $29.3B (5개월 전 $9.9B의 3배)
- 2025년 자금 조달: $2.3B (Series 규모)
- 자체 모델(Composer, 2025년 11월)로 전환 후 API 비용 월 <$0.5M, 마진 55-72%로 개선
- Jensen Huang: "my favorite enterprise AI service"
- Collins Dictionary 2025 올해의 단어: "vibe coding"

파급효과:
- "Cursor for X" 패턴 탄생 — 모든 산업에 AI-네이티브 앱 레이어 개념 확산
- VS Code 기반이지만 완전히 다른 카테고리 생성
- 개발자 워크플로우의 근본적 재편
- Lovable(바이브 코딩 도구): 1년 만에 $200M+ ARR, $6.6B 밸류에이션 달성

이걸 예측한 사람이 있었나? 일부 YC/AI 투자자들이 "AI-네이티브 IDE" 시장을 예견했으나, 이 속도의 성장은 누구도 예상 못 함.

출처 URL:
- https://sacra.com/c/cursor/
- https://finance.yahoo.com/news/startup-cursor-rides-ai-coding-123000453.html
- https://www.linkedin.com/posts/yrebryk_cursor-just-raised-23b-at-a-293b-valuation

---

## 4. 바이브 코딩 (Vibe Coding) — "소프트웨어 개발에는 코딩 능력이 필수"라는 상식 붕괴

이름/사건: Vibe Coding (Andrej Karpathy 명명)
시기: 2025년 초 ~ 연중 확산
한 줄 설명: 영어(자연어)만으로 프로그램을 만드는 것이 실제로 가능해짐. 코드를 읽지도 않음.

깨진 상식: "기존에는 소프트웨어를 만들려면 프로그래밍 언어를 알아야 하고, 코드를 읽고 이해해야 한다고 생각했는데"

증거 (수치):
- Collins Dictionary 2025 올해의 단어 선정
- GitHub Copilot: 1,500만+ 유저 (전년 대비 4배 증가)
- Stack Overflow 2025 설문: 개발자 84%가 AI 사용, 31%가 코딩 에이전트 사용
- Google CEO Sundar Pichai: "구글 신규 코드의 30% 이상이 AI에서 나옴"
- Y Combinator 스타트업 중 다수가 vibe coding으로 제품 개발
- Dave Clark(전 Amazon Consumer CEO): Claude Code로 72시간 만에 CRM 시스템 구축
- AI 코드 도구 시장: 2024년 $6.21B → 2025년 $7.7B → 2029년 $18.16B 전망
- Karpathy: "코드가 갑자기 무료, 가변적, 일회용이 됨"

파급효과:
- 비개발자의 소프트웨어 창작 진입 장벽 극적 하락
- "coder"와 "non-coder" 구분 흐려짐
- 기술 부채 우려 증가 (보안, 유지보수 문제)
- Cursor CEO 자신이 vibe coding 과의존 경고

이걸 예측한 사람이 있었나? Karpathy가 명명자. 일부 AI 연구자가 "자연어 프로그래밍"을 오래전부터 논의했으나, 2025년에 이 정도 수준으로 실현될 것은 예상 못 함.

출처 URL:
- https://karpathy.bearblog.dev/year-in-review-2025/
- https://www.ibm.com/think/topics/vibe-coding
- https://technologymagazine.com/news/vibe-coding-the-future-of-code-or-just-a-short-term-con

---

## 5. Claude Code — "AI 에이전트는 아직 실용적이지 않다"는 상식 붕괴

이름/사건: Claude Code (Anthropic)
시기: 2025년 2월 공개 → 2025년 9월(Sonnet 4.5) 이후 폭발적 인식
한 줄 설명: 최초의 실용적 AI 에이전트. 터미널에서 코드베이스 전체를 읽고, 계획하고, 실행함.

깨진 상식: "기존에는 AI 에이전트는 데모에서는 멋져 보이지만 실제 업무에서는 쓸 수 없다고 생각했는데"

증거 (수치):
- SemiAnalysis: "Claude Code is the Inflection Point" (인플렉션 포인트)
- Sonnet 4.5 (2025년 9월): 복잡한 소프트웨어 작업에서 자율적 계획→도구 사용→테스트→반복 가능
- Anthropic의 Cowork 도 Claude Code가 코드 전체를 작성
- Citywire: "Rubicon이 건너졌다(Rubicon had been crossed)"
- Cowork: 하루 50p(~700원)에 "기능하는 AI 직원" — 인턴/신입보다 높은 비자율적 작업 완수율
- Karpathy 평가: "CC가 LLM Agent의 첫 번째 설득력 있는 시연"
- OpenAI가 클라우드 컨테이너 방식으로 갔으나 Anthropic은 로컬 컴퓨터 방식 선택 → 이것이 맞았음

파급효과:
- "AI가 내 컴퓨터에 산다"는 새로운 상호작용 패러다임
- 클라우드 vs 로컬 에이전트 아키텍처 논쟁에서 로컬이 우위
- 코딩을 넘어 일반 지식 노동(법률, 스프레드시트, 웹 작업)으로 확장
- 에이전틱 시대(Agentic Era)의 시작점으로 평가

이걸 예측한 사람이 있었나? 2024년 9월 일부 투자자가 "에이전틱 AI가 다음 패러다임 전환"이라 예측. 그러나 2025년 H1까지는 실제 브레이크스루 미발생. H2에서야 실현.

출처 URL:
- https://newsletter.semianalysis.com/p/claude-code-is-the-inflection-point
- https://citywire.com/ria/news/the-secret-tech-investor-the-agentic-breakthrough-is-here/a2484001
- https://karpathy.bearblog.dev/year-in-review-2025/

---

## 6. AI 추론 비용 280배 붕괴 — "AI는 비싸다"는 상식의 종말

이름/사건: AI 추론(Inference) 비용 초고속 하락
시기: 2022년 11월 ~ 2024년 10월 (2025년에 공식 수치화)
한 줄 설명: GPT-3.5 수준 성능의 추론 비용이 2년 만에 $20 → $0.07 (280배 하락)

깨진 상식: "기존에는 고성능 AI를 운영하려면 엄청난 인프라 비용이 필요하다고 생각했는데"

증거 (수치):
- Stanford AI Index Report 2025: GPT-3.5 수준 추론 비용 $20.00/M tokens(2022.11) → $0.07/M tokens(2024.10) = 280배 하락
- 1달러로 1,400만 토큰 생성 가능
- 하드웨어 비용: 연 30% 하락, 에너지 효율: 연 40% 개선
- 오픈웨이트 vs 클로즈드 모델 성능 차이: 8% → 1.7% (1년 만에)
- OpenAI o1: $60/M tokens vs DeepSeek R1: $2.19/M tokens (27배 차이)
- DeepSeek: 2025년 말 API 가격 50%+ 추가 인하
- GPT-5: $1.25/M input tokens (2025년 8월)
- MIT 연구: 오픈모델 최적 배분 시 글로벌 AI 경제 연 ~$25B 절약 가능

파급효과:
- "인텔리전스의 가격이 역사상 가장 빠르게 하락 중" (WisdomTree)
- 전기·브로드밴드처럼 AI가 "유비쿼터스 유틸리티"로 전환
- 소규모 스타트업도 프론티어 AI 활용 가능
- AI-네이티브 앱의 대량 출현

이걸 예측한 사람이 있었나? 비용 하락 추세 자체는 예상되었으나, 280배라는 속도와 규모는 대부분 예상 초과.

출처 URL:
- https://www.wisdomtree.com/investments/blog/2025/05/19/280x-cheaper-the-real-ai-revolution-is-accessibility
- https://blogs.nvidia.com/blog/ai-inference-economics/
- https://www.joincerulean.com/blog/the-decreasing-cost-of-intelligence

---

## 7. 중국 오픈소스 모델 삼국지 (Kimi K2, Qwen 3, GLM 4.5) — "오픈소스는 상용 모델을 이길 수 없다"는 상식 붕괴

이름/사건: Kimi K2 (Moonshot AI), Qwen 3 Coder (Alibaba), GLM 4.5 (Zhipu AI)
시기: 2025년 7월 연쇄 출시
한 줄 설명: 중국 오픈소스 모델들이 SWE-bench에서 GPT-4.1을 압도, 비용은 10-100배 저렴

깨진 상식: "기존에는 오픈소스 모델은 상용 프론티어 모델에 비해 항상 한 세대 뒤처진다고 생각했는데"

증거 (수치):
- SWE-bench Verified: Qwen 3 Coder 67%, Kimi K2 65.8% vs GPT-4.1 54.6%
- 비용: 서구 모델 대비 50-90% 절약 (GLM 4.5: $0.60/M tokens)
- GLM 4.5: 355B 파라미터 중 32B만 활성(MoE) — 8개 칩에서 구동 가능
- 컨텍스트 윈도우: Qwen 3 Coder 256K (1M까지 확장)
- 2024년 초 GPT-4는 SWE-bench에서 2%만 해결 → 2025년 중국 모델 64-67% 해결
- 모두 Apache 2.0 등 오픈소스 라이선스
- Kimi K2: 1조 파라미터 MoE, 네이티브 MCP 지원

파급효과:
- "오픈소스 AI 모델의 조용한 장악" 현상
- 서구 AI 기업(OpenAI, Anthropic)의 가격 압박 심화
- 2주 단위로 "최고 오픈소스 모델" 왕좌 교체
- 개발자들의 자체 호스팅 AI 코딩 어시스턴트 현실화

이걸 예측한 사람이 있었나? Meta가 LLaMA로 오픈소스 경쟁을 시작했으나, 중국 모델이 이 정도 속도로 상용 모델을 능가할 것은 예상 못 함.

출처 URL:
- https://www.digitalapplied.com/blog/chinese-ai-models-kimi-k2-qwen-3-coder-glm-4-5
- https://www.clarifai.com/blog/kimi-k2-vs-qwen-3-vs-glm-4.5
- https://aarambhdevhub.medium.com/open-source-ai-vs-paid-ai-for-coding-the-ultimate-2026-comparison-guide-ab2ba6813c1d

---

## 8. Klarna AI → 실패 → 하이브리드 — "AI가 인간 고객 서비스를 대체할 수 있다"는 상식의 시험과 반전

이름/사건: Klarna AI 고객 서비스 대체 실험 및 역전
시기: 2024~2025년
한 줄 설명: AI가 700명의 고객 서비스 직원을 대체 → 고객 만족도 하락 → 다시 인간 채용

깨진 상식: "기존에는 AI가 고객 서비스를 완전히 대체해 비용을 혁신적으로 절감할 수 있다고 생각했는데" (두 번째 반전: "하지만 결국 인간 없이는 불가능했다")

증거 (수치):
- AI가 대체한 인력: 700 FTE → 이후 853 FTE로 확대
- 전체 인원: 5,527명(2022) → 2,907명(2025.11), 주로 자연 감소
- 매출 108% 증가, 운영 비용은 동결 — CEO "전례 없는 수치"
- $40M 연간 이익 개선 주장
- 해결 시간: 11분 → 2분 (5배 단축)
- BUT: 고객 불만 증가, 만족도 하락, 복잡한 문제 처리 실패
- CEO Siemiatkowski 공개 인정: "비용이 너무 지배적인 평가 요소였다" / "너무 과했다(went too far)"
- 2025년: 인간 고객 서비스 재채용 시작 (학생, 농촌 노동자 대상 파일럿)
- Gartner: CX 리더 321명 조사 중 AI로 인원 감축한 곳은 20%만
- Forrester: AI 해고의 55%가 후회, 2027년까지 절반 복귀 전망
- 하이브리드 모델 정착: 단순 문의→AI, 복잡/감정적 문의→인간

파급효과:
- "AI 대체" 내러티브에 대한 현실 점검
- 2025년 "AI 이유" 해고 55,000건 — Brookings: 상당수 "AI 워싱"
- 대기업(Ford, Amazon, Salesforce, JP Morgan) CEO들이 백색 칼라 직종 감축 예고

이걸 예측한 사람이 있었나? Klarna가 초기 "성공"을 대대적으로 홍보했으므로, 실패/역전은 대부분 예상 못 함.

출처 URL:
- https://www.theguardian.com/business/2025/nov/18/buy-now-pay-later-klarna-ai-helped-halve-staff-boost-pay
- https://mlq.ai/news/klarna-ceo-admits-aggressive-ai-job-cuts-went-too-far-starts-hiring-again-after-us-ipo/
- https://solutionsreview.com/klarnas-ai-layoffs-exposed-the-missing-piece-empathy/
- https://hbr.org/2026/01/companies-are-laying-off-workers-because-of-ais-potential-not-its-performance

---

## 9. AI 비디오 생성 — "영화 수준 영상은 헐리우드 예산이 필요하다"는 상식 붕괴

이름/사건: Sora 2, Kling AI, Veo 3, Runway Gen-4 등 AI 비디오 생성 도구
시기: 2025년 전반
한 줄 설명: 텍스트 프롬프트만으로 4K 영상 생성, 95%가 진짜와 구분 불가. 비용 $0.07~$0.40/초.

깨진 상식: "기존에는 사실적인 영상을 만들려면 전문 장비, 촬영팀, 후반 작업이 필요하다고 생각했는데"

증거 (수치):
- 2025년 총 800만+ AI 생성 영상
- 95%의 사람이 고품질 AI 영상과 실제 영상을 구분 못함
- Sora 2: 4K 해상도, 60초 영상, 동기화된 오디오 생성 (~$4/영상)
- Kling AI 1.6: 1080p, 60초+, $0.35/영상 (가성비 최고)
- Veo 3: 풀 사운드 디자인 포함
- Kling 3.0 (2026년 2월): 멀티숏 시퀀스, 캐릭터 일관성 유지, 네이티브 오디오
- 2026년 최대 돌파: 네이티브 오디오 생성 (더 이상 무음 영상이 아님)
- Coca-Cola, McDonald's 등 대기업이 AI 영상으로 광고 캠페인 진행
- 소규모 사업자도 독립적으로 짧은 광고 제작 가능

파급효과:
- 광고/마케팅 산업 워크플로우 근본 변화
- 딥페이크 탐지 기술과의 군비 경쟁 심화
- 2026년 Super Bowl: AI로 만든 광고와 AI 제품 광고가 동시 출현

이걸 예측한 사람이 있었나? Sora 1이 2024년에 발표되어 기대감은 있었으나, 실제 품질과 비용 수준은 예상을 크게 초과.

출처 URL:
- https://www.aivideodetector.org/blog/ai-video-generation-tools-comparison-2025
- https://www.teamday.ai/blog/best-ai-video-models-2026
- https://higgsfield.ai/blog/Kling-2.6-is-Here-Whats-New

---

## 10. AI 코딩 에이전트의 실용화 — "AI는 코드 완성 도우미 수준"이라는 상식 붕괴

이름/사건: 자율 코딩 에이전트 (Devin, Claude Code, Refact.ai 등)
시기: 2024년 3월 (Devin 발표) → 2025년 전반 실용화
한 줄 설명: AI가 환경 설정, 계획 수립, 코드 작성, 테스트, PR 제출까지 자율 수행

깨진 상식: "기존에는 AI는 코드 자동완성이나 스니펫 생성 정도만 가능하고, 실제 소프트웨어 엔지니어링은 인간만 할 수 있다고 생각했는데"

증거 (수치):
- Devin AI (2024년 3월): 최초 AI 소프트웨어 엔지니어, SWE-bench 13.86% 해결
- 2025년 말 최고 AI 솔루션: SWE-bench Verified에서 70%+ 해결
- 2024→2025: SWE-bench 성능 14% → 70%+ (1년 만에 5배 개선)
- Refact.ai: SWE-bench Multimodal에서 35.59% (pass@1, 단일 시도)
- LinkedIn 2026 보고서: "코딩 에이전트가 실험에서 필수(essential)로 이동"
- 개발자 AI 사용: ~60% 업무에 AI 활용, 다만 완전 위임은 0-20%
- The New Stack: "2023년에 AI 에이전트는 농담이었다. 2025년에는 가장 큰 개발 이야기"
- MCP(Model Context Protocol)가 2025년 "웹 서버만큼 보편화"

파급효과:
- 소프트웨어 엔지니어링 직업의 본질 변화 논의
- 주니어 개발자 역할 재정의 (AI가 주니어 수준 작업 처리)
- "Software Engineering 3.0" 개념 등장

이걸 예측한 사람이 있었나? Devin이 2024년 발표 시 회의론 많았음. 1년 만에 5배 성능 향상은 예상 초과.

출처 URL:
- https://arxiv.org/html/2507.15003v1
- https://thenewstack.io/ai-engineering-trends-in-2025-agents-mcp-and-vibe-coding/
- https://refact.ai/blog/2025/1-agent-on-swe-bench-verified-using-claude-4-sonnet/

---

## 11. Profluent Bio OpenCRISPR-1 — "분자 설계는 자연의 영역"이라는 상식 붕괴

이름/사건: OpenCRISPR-1 (Profluent Bio)
시기: 2025년 (발표/보도)
한 줄 설명: 생성형 AI가 자연에 존재하지 않는 CRISPR 유전자 편집 효소를 처음부터 설계

깨진 상식: "기존에는 유전자 편집 도구는 자연에서 발견하거나, 자연 단백질을 약간 변형하는 것이 최선이라고 생각했는데"

증거 (수치):
- OpenCRISPR-1: 자연에 알려진 어떤 단백질과도 수백 개 돌연변이 차이
- 단백질 언어 모델로 대규모 데이터셋 학습 → 완전 새로운 효소 생성
- 실제로 작동하는 게놈 편집 정밀도 확인
- "분자생물학의 오래된 장벽을 부순" 것으로 평가 (etcjournal)
- AI가 신물질, 의약품, 과학적 지식을 인간 연구소 불가능 속도로 생성 가능성 시연

파급효과:
- "기계가 발명하는 생명공학" 시대 개막
- AI 주도 과학 연구(자율 연구실)의 윤리/규제 논의 촉발
- 신약 개발 기간: 수년 → 수일 가능성 제시

이걸 예측한 사람이 있었나? AlphaFold가 단백질 구조 예측에 성공한 이후 이 방향에 대한 기대감은 있었으나, "완전히 새로운 기능 효소를 AI가 창조"하는 수준은 예상보다 빠름.

출처 URL:
- https://etcjournal.com/2025/08/13/three-biggest-ai-stories-in-august-2025/

---

## 12. NotebookLM — "AI 팟캐스트가 바이럴이 될 수 있다"는 예상 밖의 제품-시장 핏

이름/사건: Google NotebookLM (Audio Overviews)
시기: 2024년 말 바이럴 → 2025년 기능 확장
한 줄 설명: 문서를 업로드하면 AI가 팟캐스트 형태 대화로 변환. 아무도 예상 못 한 킬러 기능.

깨진 상식: "기존에는 AI 연구 도구는 요약/QA 기능 위주이고, AI 생성 오디오 콘텐츠는 소비자에게 매력적이지 않다고 생각했는데"

증거 (수치):
- "surprise hit of the year" (The Verge)
- 인터랙티브 모드: 사용자가 AI 팟캐스트 호스트에게 "전화 참여" 가능
- AI 호스트가 인간 참여자에게 짜증을 내는 버그까지 발견 ("I was getting to that")
- 2025년 추가 기능: 인터랙티브 마인드 맵, 다국어 오디오 오버뷰, AI 비디오 오버뷰
- 사용자 업로드 소스에만 기반 → 환각(hallucination) 최소화
- NotebookLM Plus 구독 서비스 출시 (기업/교육용)
- 학습, 연구, 콘텐츠 소비 방식의 근본적 전환

파급효과:
- "AI 제품의 킬러 기능은 예측할 수 없다"는 교훈
- 오디오 기반 AI 인터페이스의 가능성 입증
- 교육/연구 분야 워크플로우 변화

이걸 예측한 사람이 있었나? Google 내부에서도 Audio Overviews가 이 정도로 인기를 끌 것을 예상하지 못함.

출처 URL:
- https://www.theverge.com/2024/12/13/24318099/google-notebooklm-audio-overviews-talk-plus
- https://techcrunch.com/2025/01/14/googles-notebooklm-had-to-teach-its-ai-podcast-hosts-not-to-act-annoyed-at-humans/

---

## 13. AI 일자리 대체의 현실 — "AI는 서서히 일자리에 영향을 준다"는 상식 vs 실제 속도

이름/사건: AI 기반 대규모 해고/채용 동결
시기: 2025~2026년
한 줄 설명: 2025년 55,000건의 AI 명시 해고. 그러나 AI의 "잠재력"에 의한 해고이지, "성과"에 의한 것이 아님.

깨진 상식: 두 가지 동시 붕괴 —
(1) "AI로 인한 일자리 변화는 천천히 올 것이다"
(2) "AI가 실제로 그 일을 할 수 있기 때문에 해고한다"

증거 (수치):
- Challenger, Gray and Christmas: 2025년 AI 명시 해고 55,000건 (2년 전 대비 12배)
- Amazon: 16,000명 감축 (2026년 1월)
- CrowdStrike: 500명 감축, AI 전환 명시
- Ford, Salesforce, JP Morgan Chase CEO: 백색 칼라 직종 대규모 감축 예고
- HBR(2026.01): "AI의 성과가 아니라 잠재력 때문에 해고"
- Forrester: AI 해고의 55%가 후회
- Brookings: "AI 워싱" — 재정적 동기 해고를 AI 탓으로 위장
- 기술/미디어 섹터: 80%+ 경영진이 24개월 내 채용 감소 예상
- 의료: AI 해고 없음, 채용 감소 예상 없음
- CBS News(2026.02): AI 해고 트렌드 가속화 보도

파급효과:
- "AI 대체" 담론 vs 현실 괴리 심화
- 번역가 등 특정 직종에서는 실질적 영향 시작
- 화이트칼라의 자발적 직업 전환 시작
- 입사 경쟁에서 AI 리터러시가 핵심 역량화

이걸 예측한 사람이 있었나? 일반적 "AI가 일자리를 뺏을 것" 전망은 많았으나, "AI 워싱" 현상과 해고 후 후회 역전 패턴은 예상 못 함.

출처 URL:
- https://www.cbsnews.com/news/ai-layoffs-2026-artificial-intelligence-amazon-pinterest/
- https://hbr.org/2026/01/companies-are-laying-off-workers-because-of-ais-potential-not-its-performance
- https://tech.co/news/companies-replace-workers-with-ai
- https://www.theguardian.com/technology/2026/feb/11/big-ai-job-swap-white-collar-workers-ditching-their-careers

---

## 요약: 깨진 상식 목록

| # | 깨진 상식 | 뒤집은 증거 |
|---|----------|-----------|
| 1 | "프론티어 AI는 수억 달러 필요" | DeepSeek R1: $5.6M으로 o1급 달성 |
| 2 | "모델을 크게 만들어야 똑똑해진다" | TTC: 작은 모델이 14x 큰 모델 능가 |
| 3 | "개발자 도구 시장은 점진적" | Cursor: $1M→$1B ARR in ~2년 |
| 4 | "소프트웨어에는 코딩 능력 필수" | Vibe coding: 자연어만으로 앱 개발 |
| 5 | "AI 에이전트는 아직 실용 불가" | Claude Code: 실제 코드베이스에서 자율 작업 |
| 6 | "AI 운영은 비싸다" | 추론 비용 280배 하락 (2년) |
| 7 | "오픈소스는 상용보다 한 세대 뒤" | 중국 OS 모델이 SWE-bench에서 GPT-4.1 압도 |
| 8 | "AI가 고객서비스 완전 대체 가능" | Klarna: 대체 후 품질 하락 → 재채용 |
| 9 | "사실적 영상은 할리우드 예산 필요" | AI 영상: $0.07/초, 95% 구분 불가 |
| 10 | "AI는 코드 자동완성 수준" | 코딩 에이전트: SWE-bench 14%→70%+ (1년) |
| 11 | "분자 설계는 자연의 영역" | OpenCRISPR-1: AI가 새 효소 창조 |
| 12 | "AI 오디오는 소비자에 매력 없음" | NotebookLM: AI 팟캐스트가 킬러 기능 |
| 13 | "AI 일자리 영향은 서서히" | 2025년 55,000건 AI 해고, 동시에 55% 후회 |
