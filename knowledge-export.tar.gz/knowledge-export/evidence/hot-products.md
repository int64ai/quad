# 2025-2026 AI 제품 증거 수집 — "터진 것들"

> 수집일: 2026-02-20
> 기준: 2025년 1월 ~ 2026년 2월
> 원칙: 논리나 의견 금지. 오직 증거(수치)만.

---

## 1. Cursor (Anysphere)

- **출시일:** 2023 (AI 코드 에디터), 폭발 시점 2024말~2025
- **한 줄 설명:** AI 네이티브 코드 에디터. VS Code 기반, LLM으로 코드 작성/편집/디버깅
- **증거 (수치):**
  - ARR: $1M (2023.12) → $100M (2025.01) → $300M (2025.04) → $500M (2025.06) → **$1B (2025.11)** — 24개월 만에 $0→$1B
  - 밸류에이션: $400K (2022) → $2.6B (2024.12) → $9.9B (2025.06) → **$29.3B (2025.11)**
  - 시리즈D $2.3B 유치 (Accel, Coatue, Thrive, a16z, Google, NVIDIA)
  - $100M ARR까지 마케팅 비용 $0 (완전 바이럴/바텀업)
  - 전환율 36% (프리→유료)
  - 자체 모델(Composer) 전환 후 API 지출 월 <$0.5M, 총마진 55-72%로 반등
- **뭘 깼나:** 기존: IDE + 별도 AI 도구(GitHub Copilot 플러그인 형태). Cursor: AI가 에디터 자체에 내장. 개발자가 VS Code를 버리고 전환. "Cursor for XYZ"가 카테고리명이 됨.
- **출처 URL:**
  - https://aifundingtracker.com/cursor-revenue-valuation/
  - https://sacra.com/c/cursor/
  - https://www.saastr.com/cursor-hit-1b-arr-in-17-months-the-fastest-b2b-to-scale-ever-and-its-not-even-close/
  - https://www.reuters.com/technology/code-gen-startup-cursor-valuation-nearly-triples-30-billion-latest-funding-round-2025-11-13/
- **카테고리: A**
  - 판단 근거: 창업팀 4명(MIT 학생), VS Code 포크로 시작. 초기 제품은 개인/소규모 팀이 만들 수 있는 규모. 단, 현재 스케일은 대기업급.

---

## 2. Lovable (구 GPT Engineer)

- **출시일:** 2024말 리브랜딩, 2025년 본격 폭발
- **한 줄 설명:** 코딩 경험 없이 텍스트 프롬프트로 웹/앱 빌드하는 "바이브 코딩" 도구
- **증거 (수치):**
  - ARR: $0 → $100M (8개월) → **$200M (12개월, 2025.12)** — 소프트웨어 역사상 가장 빠른 $0→$200M
  - 밸류에이션: $1.8B (2025.07) → **$6.6B (2025.12)** — 5개월 만에 3.7x
  - 2025년 총 $500M+ 유치 (CapitalG, Menlo, Accel, Khosla, NVentures, Salesforce, Databricks, Atlassian, DST)
  - 직원 15명으로 이 매출 달성
  - 스웨덴 창업자 2명 각각 ~$1.6B 자산가
- **뭘 깼나:** 기존: 앱 만들려면 개발자 필요. Lovable: 텍스트로 설명하면 풀스택 앱 생성. 비개발자가 소프트웨어를 만드는 시대 개막. "바이브 코딩" 카테고리 자체를 만듦.
- **출처 URL:**
  - https://aifundingtracker.com/lovable-vibe-coding-revenue/
  - https://www.entrepreneur.com/business-news/how-ai-startup-lovable-hit-a-66b-valuation/501077
  - https://www.cnbc.com/2025/12/18/google-and-n.html
  - https://lovable.dev/blog/series-b
- **카테고리: A**
  - 판단 근거: 스웨덴 스타트업, 15명으로 $200M ARR 달성. 개인/소규모 팀 스케일에서 시작. 바이브 코딩 도구 자체가 소규모 팀이 만들 수 있는 제품 유형.

---

## 3. DeepSeek

- **출시일:** R1 모델 2025년 1월 20일 공개
- **한 줄 설명:** 중국산 오픈 웨이트 AI 모델. $6M 학습비로 미국 프론티어 모델과 동급 성능 달성
- **증거 (수치):**
  - 웹사이트 트래픽: 312% 증가 (2025.01, R1 출시 후)
  - 일일 방문자: 7,475명 (2024.08) → **22.15M DAU** (2025.01)
  - 앱 다운로드: 1월 20일 78K → 1월 27일 1.86M → 총 **57.2M 다운로드** (2025.05)
  - MAU: **96.88M** (2025.04), **145M** (2025말 추정)
  - 앱스토어 156개국 1위 달성, ChatGPT를 제치고 미국 iOS 1위 (2025.01.27)
  - R1 출시 여파로 Nvidia 주가 17% 하락, Nasdaq 3% 하락
  - 학습비 ~$6M (경쟁사 대비 1/100 수준)
  - 토큰 가격 $0.55/1M 입력 (경쟁사 대비 극도로 저렴)
  - 다운로드 시장 점유율: 17.59% (ChatGPT 40.52% 다음 2위)
- **뭘 깼나:** 기존: 프론티어 AI 모델은 수억~수십억 달러 학습비 필요, 미국 빅테크만 가능. DeepSeek: $6M으로 동급 성능. 오픈 웨이트 공개. "AI에 꼭 수십억 달러가 필요한가?"라는 근본 질문 제기. 스케일링 법칙 패러다임에 타격.
- **출처 URL:**
  - https://electroiq.com/stats/deepseek-ai-statistics/
  - https://alloutseo.com/deepseek-stats/
  - https://backlinko.com/deepseek-stats
  - https://en.wikipedia.org/wiki/DeepSeek_(chatbot)
- **카테고리: B**
  - 판단 근거: 모회사 High-Flyer(헤지펀드). GPU 클러스터, 대규모 학습 인프라 필요. 비록 학습비가 저렴했지만, 기반 인프라와 연구팀은 대기업급.

---

## 4. OpenAI / ChatGPT

- **출시일:** 2022.11 (ChatGPT), 2025년 내내 폭발적 성장 지속
- **한 줄 설명:** 세계 1위 AI 챗봇 플랫폼
- **증거 (수치):**
  - ARR: $6B (2024) → **$20B (2025)** — 3.3x YoY 성장
  - 주간 활성 사용자(WAU): 200M (2024.10) → 800M (2025.10) — 1년 만에 **4x**
  - 월 방문: chatgpt.com **5.4B 월방문** (세계 5위 웹사이트)
  - 기업 고객: **100만 기업** 유료 사용
  - Ghibli 이미지 생성 바이럴 (2025.03): 7억 이미지 생성, 4600만 다운로드 (월 28% 증가), 1시간에 100만 유저 유입 (Sam Altman 발언)
  - 시장 점유율: AI 도구 다운로드의 40.52%
  - $6.6B 유치 (2024.10, $157B 밸류에이션), $300B 밸류에이션 (2025말)
  - GPT-5, GPT-4o 이미지 생성, Sora 2 등 연이어 출시
- **뭘 깨고 있나:** 기존 검색(구글), 기존 이미지 편집(Photoshop), 기존 교육 방식 등 모든 것을 챗 인터페이스로 대체 시도. 세계에서 가장 빠르게 성장한 소비자 앱에서 이제 플랫폼으로 진화.
- **출처 URL:**
  - https://finance.yahoo.com/news/openai-cfo-says-annualized-revenue-173519097.html
  - https://finance.yahoo.com/news/openai-is-the-2025-yahoo-finance-company-of-the-year-120054312.html
  - https://www.saastr.com/openai-crosses-12-billion-arr-the-3-year-sprint-that-redefined-whats-possible-in-scaling-software/
  - https://www.paddle.com/news/industry/chatgpt-tops-global-app-downloads-march-2025
  - https://www.reuters.com/technology/artificial-intelligence/ghibli-effect-chatgpt-usage-hits-record-after-rollout-viral-feature-2025-04-01/
- **카테고리: B**
  - 판단 근거: 수만 명 직원, 수십억 달러 인프라 투자 필요. 개인이 절대 만들 수 없는 규모.

---

## 5. Anthropic / Claude

- **출시일:** Claude 2023.03, Claude Code 2025.05 (퍼블릭)
- **한 줄 설명:** AI 안전 중심의 LLM 및 코딩 에이전트 플랫폼
- **증거 (수치):**
  - ARR: $1B (2025.01) → $5B (2025.08) → $9B (2025.12) → **$14B (2026.02)** — 14개월 만에 14x
  - Claude Code: 출시 9개월 만에 **$2.5B ARR** (2026초), 1월 이후 2배 성장
  - GitHub 퍼블릭 커밋의 **4%가 Claude Code로 작성** (20%+ 예측)
  - 밸류에이션: $183B (2025.09 시리즈F) → **$380B (2026.02 시리즈G)**
  - 시리즈G: **$30B 유치** — 2026년 최대, 역사상 2번째 대규모 VC 딜
  - 매출의 80%가 기업 고객
  - 직원: 2,300~3,000명
- **뭘 깼나:** 기존: AI 코딩 도구는 자동완성 수준(Copilot). Claude Code: 에이전틱 코딩 — 멀티파일 편집, 자율 디버깅, 프로덕션 코드 작성. 엔터프라이즈 AI 코딩의 기준을 바꿈. 안전/해석가능성 강조로 기업 시장 장악.
- **출처 URL:**
  - https://www.saastr.com/anthropic-just-hit-14-billion-in-arr-up-from-1-billion-just-14-months-ago/
  - https://www.anthropic.com/news/anthropic-raises-series-f-at-usd183b-post-money-valuation
  - https://cryptorank.io/news/feed/bdcc3-biggest-funding-rounds-anthropic-leads-ai-robotics
- **카테고리: B**
  - 판단 근거: 전 OpenAI 임원 창업, 수천 명 직원, 수백억 달러 인프라. 프론티어 모델 개발은 대기업급 리소스 필요.

---

## 6. Perplexity AI

- **출시일:** 2022, 2025년 폭발적 성장
- **한 줄 설명:** AI 네이티브 검색 엔진. 실시간 웹 검색 + LLM 결합, 출처 인용 답변
- **증거 (수치):**
  - MAU: 15M (2024) → **22~30M** (2025말~2026초) — 50%+ 성장
  - ARR: $10M (2023) → $80M (2024) → **$148~200M** (2025) — 매년 100%+ 성장
  - 월 쿼리: 500M (2023) → **780M** (2025.05)
  - 일 쿼리: 3,000 (2022) → **30M** (2025)
  - 월 방문: **189M** 글로벌
  - 밸류에이션: **$20~28B** (2025말~2026초)
  - 유저 리텐션: **85%**
  - 다이렉트 트래픽: 82% (강한 브랜드)
  - Comet 브라우저 출시 (2025.10), Chrome 인수 $34.5B 입찰 (2025.08)
  - 검색 시장 AI 점유율: 6.4~8% (2025말)
- **뭘 깼나:** 기존: 구글 검색 → 링크 10개 → 클릭해서 읽기. Perplexity: 질문 → 출처 달린 직접 답변. "검색"이라는 행위 자체를 재정의. 구글의 20년 패권에 최초로 의미있는 도전.
- **출처 URL:**
  - https://www.demandsage.com/perplexity-ai-statistics/
  - https://www.pminsights.com/companies/perplexity-ai
  - https://tsginvest.com/perplexity-ai/
  - https://www.incremys.com/en/resources/blog/perplexity-statistics
- **카테고리: B**
  - 판단 근거: 전 Google/OpenAI/Meta 연구원 창업. 대규모 인프라, 실시간 웹 크롤링, 다중 LLM 통합 필요. 독립 개인이 만들기 어려운 규모.

---

## 7. ElevenLabs

- **출시일:** 2022, ARR 폭발 2024~2025
- **한 줄 설명:** AI 음성 합성 및 음성 AI 에이전트 플랫폼
- **증거 (수치):**
  - ARR: $0→$100M (20개월) → $200M (+10개월) → **$330M** (+5개월, 2025말)
  - 밸류에이션: $100M (2023.06) → $1.1B (2024.01) → $3.3B (2025.01) → $6.6B (2025.09) → **$11B** (2026초, 시리즈D $500M)
  - 2.5년 만에 밸류 **66x** 상승 (시리즈A→세컨더리)
  - Sequoia, a16z, ICONIQ 등 투자
  - 기업 고객 급증 — ElevenAgents(대화형 AI 에이전트) 런칭으로 콜센터/세일즈 진출
- **뭘 깼나:** 기존: TTS는 로봇 같은 음성, 성우 고용 필수. ElevenLabs: 자연스러운 감정 표현, 음성 클로닝, 29개 언어 지원. 성우 산업, 오디오북 산업, 콜센터 산업을 한꺼번에 위협.
- **출처 URL:**
  - https://www.saastr.com/elevenlabs-just-hit-330m-arr-it-took-twilio-8-years-to-get-there/
  - https://mlq.ai/news/elevenlabs-lands-500m-series-d-round-at-11-billion-valuation/
  - https://sacra.com/c/elevenlabs/
- **카테고리: A → B 전환 중**
  - 판단 근거: 2명이 시작(전 구글 엔지니어), 초기 제품은 소규모 팀으로 가능. 현재는 $11B 기업으로 성장. 초기 아이디어/MVP는 개인 스케일이었으나, 현재 인프라는 대기업급.

---

## 8. Replit

- **출시일:** 2018, AI Agent 출시 2025년 폭발
- **한 줄 설명:** 브라우저 기반 AI 코딩 환경. AI Agent로 앱 빌드
- **증거 (수치):**
  - 매출: **$2.8M** (2024) → **$150M ARR** (2025.09) → **$240M** (2025말) — AI Agent 출시 후 폭발
  - 2026년 $1B 매출 목표 (CEO Amjad Masad 발언)
  - 유저: **40M** 총 유저, 150K+ 유료 고객 (2025.06)
  - $250M 유치, **$3B 밸류에이션** (2025.09)
  - Duolingo, Zillow 등 기업 고객 확보
  - 기업 마진 ~80%
  - ARPU 지난 1년간 3x 증가
- **뭘 깬다:** 기존: 코딩은 IDE 설치 → 환경설정 → 로컬 개발. Replit: 브라우저에서 AI에게 말하면 앱 완성. "1B 개발자" 비전 — 코딩을 모르는 사람도 개발자가 되는 세상.
- **출처 URL:**
  - https://www.businessinsider.com/replit-projects-1-billion-revenue-by-2027-ai-coding-boom-2025-10
  - https://www.saastr.com/the-day-ai-agents-stopped-being-tools-and-became-my-team-125-days-of-vibe-coding-at-750000-uses/
- **카테고리: B**
  - 판단 근거: 2018년부터 운영된 플랫폼. 클라우드 인프라, 브라우저 IDE 인프라 필요. 현재 $3B 기업.

---

## 9. Vercel / v0

- **출시일:** v0 2023, 2025년 급성장
- **한 줄 설명:** AI 프론트엔드 에이전트. 자연어로 풀스택 앱 UI 생성
- **증거 (수치):**
  - v0 유저: **3.5M 고유 유저** (2025.09)
  - Teams & Enterprise가 v0 매출의 **50% 이상**
  - Vercel 전체 ARR: $144M (2024말) → **$200M** (2025.05)
  - 밸류에이션: $3.25B (2024.05) → **$9.3B** (2025.09) — $300M 시리즈F
  - 15개월 만에 ARR 2x ($100M→$200M)
- **뭘 깨고 있나:** 기존: UI 만들려면 디자이너+프론트엔드 개발자 필요. v0: 프롬프트로 React 컴포넌트 즉시 생성. 프론트엔드 개발의 시작점을 바꿈.
- **출처 URL:**
  - https://sacra.com/c/vercel/
  - https://www.businesswire.com/news/home/20250930898216/en/Vercel-Closes-Series-F-at-%249.3B-Valuation-to-Scale-the-AI-Cloud
  - https://www.gic.com.sg/newsroom/all/vercel-closes-series-f-at-9-3b-valuation-to-scale-the-ai-cloud/
- **카테고리: B**
  - 판단 근거: Vercel은 2015년부터 운영된 프론트엔드 클라우드 플랫폼. v0는 기존 인프라 위에 구축. 대규모 팀 필요.

---

## 10. Windsurf (구 Codeium)

- **출시일:** Codeium 2021, Windsurf IDE 2024.11 출시
- **한 줄 설명:** AI 네이티브 IDE. Cascade 에이전트로 멀티파일 편집, 터미널 명령, 디버깅
- **증거 (수치):**
  - 매출: $40M (2024) → **$80M** (2025) — 100% YoY
  - 유저: 1K (2023초) → 1M 다운로드 (2024.02) → Windsurf 출시 2일 만에 10K 가입
  - 주간 활성 개발자: **50,000+** (2025초)
  - 밸류에이션: $1.25B (2023) → **$3B 목표** (2025)
  - **OpenAI가 $3B에 인수** (2025)
  - Gartner 2025 AI 코딩 어시스턴트 매직 쿼드런트 리더 선정
  - 8,000% YoY 성장 (Codeium 기준, 소비자 지출)
- **뭘 깼나:** 기존: AI 코딩은 자동완성(Copilot 스타일). Windsurf: "Flows" — AI가 개발자의 의도를 이해하고 함께 흐름을 타며 개발. 반응형이 아닌 선제적 AI.
- **출처 URL:**
  - https://smythos.com/ai-trends/openai-spent-3-billion-on-windsurf/
  - https://getlatka.com/companies/codeium
  - https://sacra.com/c/codeium/
  - https://research.contrary.com/company/windsurf
- **카테고리: A**
  - 판단 근거: 2명(Varun Mohan, Douglas Chen)이 Exafunction에서 피벗하여 창업. 초기 무료 개발자 도구에서 시작. 소규모 팀이 만들 수 있었던 규모.

---

## 11. NotebookLM (Google)

- **출시일:** 2023 실험, 2024말~2025 바이럴 폭발
- **한 줄 설명:** 문서 업로드 → AI 요약 + "딥 다이브" 팟캐스트 자동 생성
- **증거 (수치):**
  - 유저: 20M (2025초) → **120M** (2025말) — 1년간 6x 성장
  - Audio Overview ("딥 다이브 팟캐스트") 기능이 바이럴 폭발 주도
  - 2025.02: Google Workspace 코어 서비스로 편입 (엔터프라이즈급 데이터 보호)
  - 2025.04: 50개+ 언어 지원
  - 2025.09: NotebookLM Plus 런칭 (Google One AI Premium $19.99/월)
  - 소스 제한: 50 → 400개로 8x 확장
  - 인터랙티브 오디오: 사용자가 팟캐스트에 참여하여 질문 가능
- **뭘 깼나:** 기존: 논문/문서 → 직접 읽어야 함. NotebookLM: 수백 페이지 → 10~15분 AI 팟캐스트로 변환. "TL;DR 문제"를 오디오로 해결. 학습 방식 자체를 바꿈.
- **출처 URL:**
  - https://www.linkedin.com/posts/wyndomitrabuwana_notebooklm-went-from-20m-to-120m-users-in-activity-7409548686407540736-75iT
  - https://markets.financialcontent.com/wral/article/tokenring-2026-2-5-the-audio-revolution-how-googles-notebooklm-turned-the-research-paper-into-a-viral-podcast
  - https://automatetodominate.ai/blog/google-notebooklm-2025-updates-complete-guide
- **카테고리: B**
  - 판단 근거: Google 내부 프로젝트. Google의 Gemini 모델, TTS 인프라, Workspace 통합 필요. 개인이 동일 품질로 만들기 불가능.

---

## 12. Doubao (豆包, ByteDance)

- **출시일:** 2024, 2025년 중국 1위 AI 앱
- **한 줄 설명:** ByteDance의 AI 어시스턴트 앱. 중국 내 ChatGPT 대항마
- **증거 (수치):**
  - 주간 활성 유저(WAU): **155M** (2025.12, QuestMobile) — DeepSeek(81.6M)의 거의 2배
  - MAU: **170M+** (2025.10, 중국 내)
  - AI 앱 다운로드 시장 점유율: **8.89%** (글로벌 4위)
  - Doubao 2.0 출시로 멀티모달 기능 강화
  - ByteDance Seed 연구소 + TikTok 영상 데이터로 학습
- **뭘 깼나:** 기존: 중국 AI 챗봇 시장은 파편화. Doubao: TikTok/Douyin 생태계 + ByteDance 클라우드 인프라를 무기로 중국 시장 1위 석권. 멀티모달(영상→텍스트→음성) 통합으로 슈퍼앱화.
- **출처 URL:**
  - https://www.tekedia.com/bytedance-unveils-doubao-2-0-as-chinas-leading-ai-app-seeks-to-defend-dominance-ahead-of-lunar-new-year/
  - https://brief.bismarckanalysis.com/p/ai-2026-chinas-super-app-giant-bytedance
- **카테고리: B**
  - 판단 근거: ByteDance(틱톡 모회사)의 AI 제품. 대규모 인프라, 연구팀, 데이터 파이프라인 필요.

---

## 13. Manus AI

- **출시일:** 2025년 3월 6일 (퍼블릭 데모)
- **한 줄 설명:** 범용 AI 에이전트. 자율적으로 웹 탐색, 데이터 분석, 웹사이트 제작, 여행 계획 수행
- **증거 (수치):**
  - 데모 영상: 20시간 만에 **20만 뷰**
  - 웨이트리스트: 수주 내 **200만 명** 등록
  - GAIA 벤치마크: Level-1 86.5%, Level-2 ~70% — OpenAI Deep Research 초과
  - "DeepSeek 이후 두 번째 디스럽터"로 불림
  - Meta가 인수 (2025년 중)
  - Browser Use(Manus 핵심 도구) 역시 바이럴 — ETH Zurich 학생 프로젝트에서 시작
- **뭘 깼나:** 기존: AI는 질문에 답하는 챗봇. Manus: 자율적으로 계획→실행→검증하는 에이전트. "AI 에이전트의 GPT 모먼트"로 평가. 에이전틱 AI 붐의 도화선.
- **출처 URL:**
  - https://www.technologyreview.com/2025/06/05/1117958/china-ai-agent-boom/
  - http://wicinternet.org/2025-03/08/c_1078014.htm
  - https://techcrunch.com/2025/03/12/browser-use-one-of-the-tools-powering-manus-is-also-going-viral/
  - https://electroiq.com/stats/manus-ai-statistics/
- **카테고리: A**
  - 판단 근거: 소규모 중국 팀(Monica/Butterfly Effect AI)에서 개발. Browser Use는 ETH Zurich 학생 2명이 4일 만에 MVP 제작. 에이전트 프레임워크 자체는 개인/소규모 팀이 만들 수 있는 유형.

---

## 14. PixVerse

- **출시일:** 2023, 2025년 급성장
- **한 줄 설명:** AI 비디오 생성 도구. 텍스트/이미지 → 비디오 변환
- **증거 (수치):**
  - ARR: **$50M** (2025.10)
  - 등록 유저: **100M+** (글로벌)
  - 실제 활성 유저: ~1M
  - 27명 팀으로 운영
  - 시리즈B: **$60M** 유치 (알리바바 투자)
  - AI 앱 다운로드 점유율: **6.19%** (글로벌 6위)
  - Sora(OpenAI)가 적자 운영 중인데, PixVerse는 수익성 입증
- **뭘 깼나:** 기존: 비디오 제작은 촬영팀+편집자+후반작업 필요. PixVerse: 텍스트 한 줄로 비디오 생성. 27명으로 $50M ARR 달성하며 AI 비디오의 수익성 가능성 입증.
- **출처 URL:**
  - https://www.facebook.com/techinasia/posts/-pixverse-proves-ai-video-can-be-profitable-its-hit-us50-million-in-arr-and-has-/1218701633626174/
  - https://www.cnbc.com/2026/01/13/alibaba-backed-pixverse-real-time-ai-video-generation-tool-investors-startup-openai-sora.html
  - https://www.linkedin.com/posts/pulse2news_pixverse-60-million-series-b-raised-for-activity-7371748871779254272-XeWP
- **카테고리: A**
  - 판단 근거: 27명 팀, 상대적 소규모 투자로 $50M ARR 달성. 비디오 AI 모델은 리소스 집약적이지만, 팀 규모로 보면 스타트업 스케일.

---

## 15. Kling AI (Kuaishou/快手)

- **출시일:** 2024, 2025년 수익화 본격화
- **한 줄 설명:** AI 비디오 생성 도구. "Motion Control" 기능으로 SNS 바이럴
- **증거 (수치):**
  - MAU: **12M+** (2025말)
  - 매출: **~$100M** (2025년 3분기까지 누적, Q1만 RMB 150M ≈ $21M)
  - 2025년 가이던스: **$140M** 매출
  - 매출의 70%가 구독 기반
  - "Motion Control" 댄스 비디오가 한국, 러시아 등에서 바이럴 → 매출 급증
  - 모회사 Kuaishou 주가 84% 급등 (Kling 영향)
  - v2.6 출시 (2025.12)
- **뭘 깼나:** 기존: SNS 콘텐츠는 촬영/편집 필요. Kling: AI로 댄스 비디오 등 생성 → SNS 공유 → 바이럴. 콘텐츠 제작 비용을 제로에 가깝게 낮춤. 해외 시장에서 C2C 바이럴 성공.
- **출처 URL:**
  - https://www.itiger.com/news/1196030146
  - https://www.techinasia.com/news/kuaishous-kling-ai-video-tool-drives-84-surge-shares
  - https://finance.yahoo.com/news/evaluating-kuaishou-technology-valuation-kling-111312618.html
- **카테고리: B**
  - 판단 근거: Kuaishou(중국 2위 숏폼 플랫폼) 자회사. 대규모 GPU 인프라, 비디오 모델 학습에 대기업급 리소스 필요.

---

## 16. Figure AI

- **출시일:** 2022 설립, 2025년 상업화 가속
- **한 줄 설명:** AI 휴머노이드 로봇. 범용 자율 로봇 개발
- **증거 (수치):**
  - 시리즈C: **$1B+** 유치, **$39B** 밸류에이션 (2025.09)
  - BotQ 공장 발표 (2025.03): 연간 12,000대 휴머노이드 생산 목표
  - 2029년까지 200,000대 배치 계획
  - BMW 클라이언트로 제조 현장 프로토타입 테스트
  - Amazon 파트너십 → 상업적 실행 가능성 검증
  - Helix (차세대 휴머노이드) 발표 (2025.02)
  - Intel, Nvidia, Qualcomm 등 투자
- **뭘 깨려 하나:** 기존: 산업 로봇은 특정 작업만 수행(용접 로봇 등). Figure: 범용 휴머노이드 — 인간과 같은 공간에서 다양한 작업 수행. 노동력의 근본적 대체를 시도.
- **출처 URL:**
  - https://www.intelcapital.com/figure-exceeds-1b-in-series-c-funding-at-39b-post-money-valuation/
  - https://en.wikipedia.org/wiki/Figure_AI
- **카테고리: B**
  - 판단 근거: 하드웨어+소프트웨어+AI 통합. 공장, 대규모 엔지니어링 팀, 수십억 달러 투자 필요. 개인 불가능.

---

## 17. Databricks

- **출시일:** 2013 설립, 2025년 AI 시대에 재점화
- **한 줄 설명:** 통합 데이터+AI 플랫폼. 엔터프라이즈 데이터 인텔리전스
- **증거 (수치):**
  - ARR: **$4.8B** 이상 런레이트 (55% YoY 성장)
  - 밸류에이션: $100B (2025 중반) → **$134B** (2025.12, 시리즈L $4B)
  - 총 유치: **$10B+**
  - 직원: 8,000+
  - IPO 비밀 신청 (2026.01.15 확인)
- **뭘 깬다:** 기존: 데이터 레이크 + 데이터 웨어하우스 별도 운영. Databricks: 레이크하우스 아키텍처로 통합. AI 시대에 기업 데이터를 AI 학습/추론에 직접 연결. 엔터프라이즈 AI 인프라의 핵심 계층이 됨.
- **출처 URL:**
  - https://wellows.com/blog/ai-startups/
- **카테고리: B**
  - 판단 근거: 8,000+ 직원, $134B 기업. 대규모 엔터프라이즈 플랫폼.

---

## 18. Google Gemini

- **출시일:** 2023.12, 2025년 Gemini 3 출시로 반격 성공
- **한 줄 설명:** Google의 AI 모델 및 앱. 검색, 코딩, 이미지 생성 등 20개+ 서비스에 통합
- **증거 (수치):**
  - AI 앱 다운로드 점유율: **9.6%** (글로벌 3위)
  - 알파벳 시가총액: **$4조** 돌파 (2026.01, Apple 추월)
  - 알파벳 주가: 2025년 한 해 **65% 급등**
  - Gemini 3 Pro: Humanity's Last Exam 벤치마크에서 GPT-5.2 능가
  - Nano Banana(이미지 편집 모델): 바이럴 → 첫 주 **1000만 신규 유저** 유입, 2억 건+ 이미지 편집
  - AI Studio, Stitch(UI 디자인), Jules(코딩 에이전트), NotebookLM 등 20개+ AI 서비스 동시 운영
- **뭘 깼나:** 기존: Google은 "AI 후발주자" 평가. 2025: Gemini 3으로 벤치마크 역전, 검색/워크스페이스/픽셀 등 전 제품에 AI 통합. "검색의 왕"에서 "AI의 왕"으로 재평가.
- **출처 URL:**
  - https://blog.google/innovation-and-ai/products/2025-research-breakthroughs/
  - https://www.koreadaily.com/article/20260219140045797
  - https://blog.google/innovation-and-ai/products/google-ai-news-recap-2025/
  - https://explodingtopics.com/blog/ai-statistics
- **카테고리: B**
  - 판단 근거: Google(알파벳) — 세계 최대 IT 기업 중 하나.

---

# 요약 테이블

| # | 제품 | 핵심 수치 (2025~2026) | 카테고리 |
|---|------|----------------------|---------|
| 1 | Cursor | $0→$1B ARR (24개월), $29.3B 밸류 | A |
| 2 | Lovable | $0→$200M ARR (12개월), 15명, $6.6B 밸류 | A |
| 3 | DeepSeek | 96.88M MAU, 57.2M 다운로드, $6M 학습비 | B |
| 4 | OpenAI/ChatGPT | $20B ARR, 800M WAU, $300B 밸류 | B |
| 5 | Anthropic/Claude | $14B ARR (14개월만에 14x), $380B 밸류 | B |
| 6 | Perplexity | $148~200M ARR, 22~30M MAU, $20~28B 밸류 | B |
| 7 | ElevenLabs | $330M ARR, $11B 밸류, 20개월에 $100M 달성 | A→B |
| 8 | Replit | $2.8M→$240M 매출, 40M 유저, $3B 밸류 | B |
| 9 | Vercel/v0 | $200M ARR, 3.5M v0 유저, $9.3B 밸류 | B |
| 10 | Windsurf | $80M 매출, OpenAI $3B 인수, 50K+ 주간 개발자 | A |
| 11 | NotebookLM | 20M→120M 유저 (1년), 팟캐스트 바이럴 | B |
| 12 | Doubao | 155M WAU, 170M MAU (중국 1위 AI앱) | B |
| 13 | Manus | 200만 웨이트리스트, GAIA 벤치마크 1위 | A |
| 14 | PixVerse | $50M ARR, 100M 등록, 27명 팀 | A |
| 15 | Kling AI | 12M MAU, ~$100M 매출, SNS 바이럴 | B |
| 16 | Figure AI | $1B+ 유치, $39B 밸류, BMW 파트너십 | B |
| 17 | Databricks | $4.8B ARR, $134B 밸류, IPO 준비 | B |
| 18 | Google Gemini | 글로벌 3위 AI앱, 알파벳 $4조 시총 | B |

---

# 카테고리 분석

## A (개인/소규모 팀이 만들 수 있는 규모에서 시작): 6개
- Cursor, Lovable, ElevenLabs(초기), Windsurf, Manus, PixVerse
- 공통점: 2~15명으로 시작, 기존 LLM API 활용, 바이럴/바텀업 성장, 마케팅 비용 최소

## B (대기업/큰 팀이어야 가능): 12개
- DeepSeek, OpenAI, Anthropic, Perplexity, Replit, Vercel, NotebookLM, Doubao, Kling, Figure AI, Databricks, Google Gemini
- 공통점: 대규모 인프라, 자체 모델 학습, 수천 명 팀, 수십~수백억 달러 투자 필요

---

# 메가 트렌드 (증거 기반)

1. **바이브 코딩 폭발**: Cursor($1B), Lovable($200M), Replit($240M), Windsurf($80M) — 합산 밸류에이션 **$48B+**
2. **AI 앱 시장 급성장**: 2025년 모바일 AI앱 약 40억 다운로드, $4.8B 인앱 매출, 43B 시간 사용 (Sensor Tower)
3. **AI 투자 역대 최대**: 2025년 AI 펀딩 **$238B** (전체 VC의 47%), 12건이 $1B 초과
4. **중국 AI 폭발**: DeepSeek(96.88M MAU), Doubao(155M WAU), Kling($100M 매출), PixVerse($50M ARR)
5. **$1B ARR 최단 달성 경쟁**: Cursor 24개월, ChatGPT ~12개월, Claude Code ~9개월(추정)
