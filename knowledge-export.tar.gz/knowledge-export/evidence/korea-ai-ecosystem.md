# 한국 AI 서비스 생태계 (2023~2026.02)

> 조사 일자: 2026-02-21
> 범위: 한국에서 만들어지거나 한국 시장에서 유의미한 AI 서비스/제품
> 총 서비스/제품: 30+개

---

## 목차
1. [연도별 타임라인](#연도별-타임라인)
2. [서비스/제품 상세 테이블](#서비스제품-상세-테이블)
3. [분야별 정리](#분야별-정리)
4. [정책/규제 흐름](#정책규제-흐름)
5. [출처 목록](#출처-목록)

---

## 연도별 타임라인

### 2023: ChatGPT 충격 이후 한국 대응 원년

| 시기 | 사건 |
|------|------|
| 2023.01 | DeepL, 한국어 지원 추가 — 한국 번역 시장 진입 |
| 2023.03 | 네이버, HyperCLOVA X 개발 발표 (내부 테스트 시작) |
| 2023.05 | 업스테이지, 새로운 AI 서비스 공개 (Korea Times 보도) |
| 2023.06 | SKT, AI 비서 '에이닷(A.)' 대규모 업데이트 — LLM 통합 |
| 2023.07 | 삼성전자, Bixby AI 커스텀 보이스 크리에이터 출시 |
| 2023.08 | 네이버, CLOVA X (HyperCLOVA X 기반 챗봇) 베타 공개 |
| 2023.09 | 뤼튼(Wrtn), GPT 기반 무료 AI 서비스로 급성장 — 한국판 ChatGPT 포지셔닝 |
| 2023.10 | LG AI Research, EXAONE 1.0 모델 공개 |
| 2023.11 | Lunit, KOSDAQ IPO 후 글로벌 확장 가속 |
| 2023.12 | 업스테이지, Solar 10.7B 소형 언어모델 공개 |
| 2023.12 | 카카오, AI 전략 발표 — 자체 LLM 'Kanana' 개발 착수 |
| 2023년 전반 | Riiid, AI 교육 B2B 피봇. QANDA(매스프레소), 글로벌 AI 튜터 확장 |

### 2024: 자체 LLM 경쟁, 글로벌 서비스 한국 진출

| 시기 | 사건 |
|------|------|
| 2024.01 | 삼성, Galaxy S24와 함께 **Galaxy AI** 공식 출시 — 실시간 통번역, AI 사진편집 등 |
| 2024.01 | 업스테이지, Solar를 카카오톡 AI 서비스에 탑재 (KED Global 보도) |
| 2024.01 | 리벨리온(Rebellions), Series B $1.24억 투자 유치 (KT 리드) |
| 2024.02 | 네이버, CLOVA X 정식 서비스 오픈 |
| 2024.03 | 카카오, Kanana 1.0 모델 내부 공개 — KakaoTalk 연동 시작 |
| 2024.04 | 업스테이지, Series B 1000억원($7200만) 투자 유치 — SoftBank Ventures, KDB 등 |
| 2024.06 | 과기정통부, '독자 AI 파운데이션 모델 프로젝트' 정예팀 공모 시작 |
| 2024.07 | 삼성전자, LLM 기반 차세대 Bixby 발표 예고 |
| 2024.08 | LG AI Research, EXAONE 2.0 공개 — 멀티모달 지원 |
| 2024.09 | SKT, 에이닷 '에이전트' 기능 확장 — 전화·일정·쇼핑 등 자동화 |
| 2024.10 | 뤼튼, 월간 사용자 수 수백만 돌파 — 한국 AI 플랫폼 1위 스타트업 |
| 2024.12 | **AI 기본법** 국회 통과 — 세계 두 번째 AI 기본법 제정 |
| 2024.12 | 리벨리온-사페온(Sapeon) 합병 — 한국 최초 AI 칩 유니콘 탄생 |
| 2024년 전반 | Lunit, AstraZeneca 파트너십 체결; 전 세계 1만개 의료기관 도입 달성 |
| 2024년 전반 | VUNO (뷰노), AI 의료 영상 솔루션 확대 — 식약처 인허가 다수 획득 |
| 2024년 전반 | 마음AI (구 마인즈랩), 음성AI·대화AI B2B 사업 지속 |

### 2025: 에이전트 시대 진입, 정책 변화

| 시기 | 사건 |
|------|------|
| 2025.01 | 삼성, Galaxy S25 + One UI 7 발표 — Bixby 대신 **Google Gemini**가 기본 음성비서로 전환 |
| 2025.01 | AI 기본법 시행 준비 — 하위법령 마련, 국가AI전략위원회 법정위원회로 격상 |
| 2025.01 | 국가대표 AI 프로젝트 1차 평가: LG AI연구원, SKT, 업스테이지 3팀 통과; 네이버클라우드, NC AI 탈락 |
| 2025.07 | 업스테이지, **Solar Pro 2** 출시 — 한국 최초 프런티어급 LLM, GPT-4.1·DeepSeek V3 능가 (FT, DigiTimes 보도) |
| 2025.07 | 삼성, One UI 8 + Galaxy AI 업데이트 — Now Bar, Gemini Live 통합 |
| 2025.08 | 업스테이지, FT "South Korea's Upstage enters global AI race" 기사 |
| 2025년 전반 | 뤼튼, AI 검색·도구 플랫폼으로 진화 — GPT-5 통합, 이미지 생성, 운세 등 |
| 2025년 전반 | Lunit, Microsoft 파트너십; EU MDR CE마크 획득; NCI 협력 |
| 2025년 전반 | 카카오, Kanana 고도화 — KakaoTalk 통합 AI 비서 서비스 |
| 2025년 전반 | LG AI연구원, EXAONE 3.0 시리즈 공개 — 언어/물리/바이오 인텔리전스 |
| 2025년 전반 | 트릴리온랩스, 확산 기반 LLM 'Trida-7B' 개발; 월드모델 'gWorld-32B' 출시 |
| 2025년 전반 | 모티프테크놀로지스, 'Motif-2-12.7B' 공개 — Artificial Analysis Index 국내 3위 |

### 2026 1~2월: 최신 동향

| 시기 | 사건 |
|------|------|
| 2026.01.22 | **AI 기본법 전면 시행** — 1년간 규제 유예(계도기간), AI 투명성 확보 가이드라인 공개 |
| 2026.01.23 | 국가대표 AI 추가팀 공모 시작 — 1차 탈락한 네이버클라우드·NC AI는 재도전 포기 |
| 2026.01.28 | AI 기본법 스타트업 대상 설명회 개최 (200여명 참석) |
| 2026.01.30 | 국방부, 국방 공개 데이터 국가대표AI 개발팀에 제공 발표 |
| 2026.01.30 | KAIST, AI 칩 최적 조합 LLM 인프라 개발 — GPU 의존도 완화 |
| 2026.02.02 | 한국 AI 기업 7개사 사우디 아람코 'AI 풀스택' 협력 MOU (리벨리온, 퓨리오사AI, NC AI, 업스테이지, LG AI연구원, 유라클, 메가존클라우드) |
| 2026.02.03 | 'AI 서울 2026' 컨퍼런스 — 3190명 참석, 글로벌 AI 석학 참여 |
| 2026.02.06 | 국가 AI 안전 생태계 조성 마스터플랜 간담회 |
| 2026.02.09 | 국가AI전략위원회, 'AI 기본사회 세미나' 개최 예고 |
| 2026.02.09 | 선관위, 딥페이크 영상 이용 허위사실 공표죄 최초 고발 사례 |
| 2026.02.10 | 과기부, 1441억원 한국형 국제 사업 — AI·디지털 스타트업 전주기 지원 |
| 2026.02.12 | 국가대표 AI 추가 공모 마감 — 모티프테크놀로지스, 트릴리온랩스 2곳 제안 접수 |
| 2026.02.19 | 과기부, AX대학원 10개 신규 선정 (연간 30억 지원) |
| 2026.02 현재 | 업스테이지, Solar Pro 3 출시 (최신 모델) |

---

## 서비스/제품 상세 테이블

### 🔤 LLM / 파운데이션 모델

| # | 이름 | 회사 | 출시/주요 업데이트 | 핵심 기능 | 현재 상태 | 사용자/매출 | 주요 사건 | 출처 |
|---|------|------|-------------------|-----------|-----------|-------------|-----------|------|
| 1 | **HyperCLOVA X / CLOVA X** | 네이버 | 2023.08 베타, 2024.02 정식 | 한국어 특화 LLM 기반 대화형 AI 서비스 | 성장 | 네이버 통합 (수천만 사용자 풀) | 2026.01 국가대표AI 프로젝트 탈락; SEED Think 32B 모델 발표 | [clova-x.naver.com](https://clova-x.naver.com/) |
| 2 | **Solar (Pro 2/3)** | 업스테이지 | 2023.12 (10.7B), 2025.07 (Pro 2), 2026 (Pro 3) | 소형~대형 LLM, 문서AI, 프런티어급 성능 | 급성장 | Series B 1000억원 유치 | GPT-4.1·DeepSeek V3 능가; FT 보도; 한국 최초 프런티어 LLM | [upstage.ai](https://www.upstage.ai/), [Wikipedia](https://en.wikipedia.org/wiki/Upstage_(company)) |
| 3 | **EXAONE** | LG AI Research | 2023.10 (1.0), 2024 (2.0), 2025 (3.0) | 멀티모달 LLM — 언어/물리/바이오/소재 인텔리전스 | 성장 | LG그룹 내부 활용 + 외부 제공 | 국가대표AI 1차 통과; Artificial Analysis 국내 1위; 사우디 아람코 MOU | [lgresearch.ai](https://www.lgresearch.ai/) |
| 4 | **Kanana** | 카카오 | 2023.12 착수, 2024.03 내부 공개 | 카카오톡 통합 AI 비서용 자체 LLM | 성장 | KakaoTalk 5000만+ 사용자 | 카카오 4대 과기원 AI 프로젝트 지원 | [kakaocorp.com](https://kakaocorp.com/) |
| 5 | **에이닷 AI (A.)** | SK텔레콤 | 2023.06 LLM 통합, 2024.09 에이전트 확장 | AI 비서 — 통화, 일정, 쇼핑, 정보검색 자동화 | 성장 | SKT 가입자 2300만+ | 국가대표AI 1차 통과; Sapeon-리벨리온 합병 관련 | [sktelecom.com](https://sktelecom.com/) |
| 6 | **Trida-7B / gWorld-32B** | 트릴리온랩스 | 2025 (Trida), 2026.02 (gWorld) | 확산 기반 LLM (dLLM); 세계 최초 웹코드 기반 모바일 월드모델 | 성장 (초기) | 스타트업 | 국가대표AI 추가 공모 참여 | [aitimes.com](https://www.aitimes.com/news/articleView.html?idxno=206825) |
| 7 | **Motif-2-12.7B** | 모티프테크놀로지스 | 2025 | 중형 LLM — Artificial Analysis 국내 3위 | 성장 (초기) | 스타트업 | 국가대표AI 추가 공모 참여 | [aitimes.com](https://www.aitimes.com/news/articleView.html?idxno=206825) |

### 💬 AI 플랫폼 / 비서 / 에이전트

| # | 이름 | 회사 | 출시/주요 업데이트 | 핵심 기능 | 현재 상태 | 사용자/매출 | 주요 사건 | 출처 |
|---|------|------|-------------------|-----------|-----------|-------------|-----------|------|
| 8 | **뤼튼 (Wrtn)** | 뤼튼테크놀로지스 | 2023 본격 성장, 2025 플랫폼 확장 | 무료 AI 챗봇/검색/이미지생성/도구/운세 — 한국판 종합 AI 포털 | 급성장 | 월간 수백만 사용자 (한국 AI 플랫폼 1위 스타트업) | GPT-5 통합; 실시간 검색어; 무료 모델 전략으로 10~20대 사용자 확보 | [wrtn.ai](https://wrtn.ai/) |
| 9 | **Galaxy AI** | 삼성전자 | 2024.01 (S24), 2025.01 (S25/One UI 7), 2025.07 (One UI 8) | 온디바이스+클라우드 AI — 실시간 통번역, AI 사진편집, 요약, Circle to Search | 급성장 | 삼성 Galaxy 글로벌 수억 대 | Google Gemini 통합; Bixby 대신 Gemini 기본 비서; Now Bar/Now Brief | [Wikipedia](https://en.wikipedia.org/wiki/Galaxy_AI) |
| 10 | **Bixby** | 삼성전자 | 2017 출시, 2023 AI Voice Creator, 2025 LLM 기반 업그레이드 | 음성 AI 비서 — 스마트폰, TV, 가전 | 정체→피봇 | 삼성 Galaxy 전 기기 탑재 | 2025.01 Galaxy S25에서 기본 비서 지위를 Google Gemini에 넘김 | [Wikipedia](https://en.wikipedia.org/wiki/Samsung_Bixby) |
| 11 | **CLOVA (AI 플랫폼)** | 네이버 | 2017 출시, 지속 업데이트 | AI 플랫폼 — OCR, 음성합성, 더빙, 스마트홈 | 성장 | 네이버 생태계 전체 | HyperCLOVA X로 진화; CLOVA Note, CLOVA Dubbing 등 파생 서비스 | [Wikipedia](https://en.wikipedia.org/wiki/Clova_(virtual_assistant)) |

### 🔍 AI 검색 / 번역

| # | 이름 | 회사 | 출시/주요 업데이트 | 핵심 기능 | 현재 상태 | 사용자/매출 | 주요 사건 | 출처 |
|---|------|------|-------------------|-----------|-----------|-------------|-----------|------|
| 12 | **네이버 CLOVA X 검색** | 네이버 | 2024 | HyperCLOVA X 기반 AI 검색 — 네이버 검색에 통합 | 성장 | 네이버 검색 사용자 수천만 | AI 검색 답변(AI Overview) 네이버 메인에 도입 | [naver.com](https://www.naver.com/) |
| 13 | **뤼튼 AI 검색** | 뤼튼테크놀로지스 | 2024~2025 | AI 기반 대화형 검색 — 실시간 검색어 순위 | 성장 | 월간 수백만 | 독자 검색 엔진 구축; 한국 젊은 세대 검색 대안 | [wrtn.ai](https://wrtn.ai/) |
| 14 | **네이버 파파고 (Papago)** | 네이버 | 2017 출시, 지속 업데이트 | AI 기반 다국어 번역 — 16개 언어, 이미지번역, 대화번역 | 성장 | 한국 번역 시장 1위 | 2020 이미지 바로번역 기능; HyperCLOVA 기술 접목 | [Wikipedia](https://en.wikipedia.org/wiki/Naver_Papago) |
| 15 | **DeepL (한국어)** | DeepL SE (독일) | 2023.01 한국어 지원 시작 | 고품질 신경망 기계번역 — 37개 언어 | 성장 (한국 진출) | 글로벌 수천만 사용자 | 2023.01 한국어 추가; 파파고 대비 영→한 품질 높다는 평가 | [Wikipedia](https://en.wikipedia.org/wiki/DeepL_Translator) |

### 🏥 AI 의료

| # | 이름 | 회사 | 출시/주요 업데이트 | 핵심 기능 | 현재 상태 | 사용자/매출 | 주요 사건 | 출처 |
|---|------|------|-------------------|-----------|-----------|-------------|-----------|------|
| 16 | **Lunit INSIGHT / SCOPE** | Lunit (루닛) | 2013 설립, 2023 IPO, 2024~2025 글로벌 확장 | AI 암 진단 — 흉부X선, 유방촬영, 병리 바이오마커 | 급성장 | 전 세계 1만+ 의료기관 도입 | KOSDAQ IPO(2023); WHO 권고; Volpara 인수 완료; AstraZeneca·Microsoft·NCI 파트너십; WEF Associate Partner | [lunit.io](https://www.lunit.io/) |
| 17 | **VUNO (뷰노)** | VUNO Inc. | 2014 설립, 지속 업데이트 | AI 의료 영상 분석 — 흉부X선, 골밀도, 망막, 심전도 | 성장 | 국내 종합병원 다수 도입 | 식약처 다수 인허가; KOSDAQ 상장(2021) | [vuno.co](https://www.vuno.co/) |

### 📚 AI 교육

| # | 이름 | 회사 | 출시/주요 업데이트 | 핵심 기능 | 현재 상태 | 사용자/매출 | 주요 사건 | 출처 |
|---|------|------|-------------------|-----------|-----------|-------------|-----------|------|
| 18 | **Riiid (뤼이드)** | Riiid | 2014 설립, 2023~2024 B2B 피봇 | AI 기반 적응형 학습 — 토익(Santa), 기업교육 | 정체→피봇 | 전성기 앱 수백만 DL | B2C Santa 앱에서 B2B 기업교육 AI 솔루션으로 피봇; 시리즈D $1.75억 유치(2021) | [riiid.com](https://www.riiid.com/) |
| 19 | **QANDA (콴다)** | 매스프레소 (Mathpresso) | 2016 출시, 지속 업데이트 | AI 수학 풀이 — 사진 촬영→문제 인식→풀이 제공 | 성장 | 글로벌 1억+ 다운로드 (아시아 중심) | AI 튜터 기능 강화; 동남아·일본 확장 | [qanda.ai](https://qanda.ai/) |

### 🏢 기업용 AI / B2B

| # | 이름 | 회사 | 출시/주요 업데이트 | 핵심 기능 | 현재 상태 | 사용자/매출 | 주요 사건 | 출처 |
|---|------|------|-------------------|-----------|-----------|-------------|-----------|------|
| 20 | **Document AI (Document Parse / Information Extract)** | 업스테이지 | 2023~ 지속 업데이트 | 문서 인텔리전스 — 복잡한 문서를 LLM이 읽을 수 있는 형태로 변환, 비정형 데이터 추출 | 성장 | 글로벌 기업 고객 | Solar LLM과 결합한 엔터프라이즈 AI 솔루션 | [upstage.ai](https://www.upstage.ai/) |
| 21 | **마음AI (MaumAI, 구 마인즈랩)** | 마음AI | 2014 설립, 2023~ 리브랜딩 | 음성AI, 대화AI, 비전AI — B2B 기업·공공 솔루션 | 성장 (느림) | KOSDAQ 상장; 국내 공공/기업 고객 | 마인즈랩에서 마음AI로 사명 변경; STT/TTS/챗봇 B2B | [maum.ai](https://maum.ai/) |
| 22 | **NC AI** | 엔씨소프트 (NCSoft) | 2023~ AI 조직 확대 | 게임 AI + 범용 LLM 연구 — 자체 LLM VARCO 개발 | 성장 (느림) | 엔씨소프트 내부 활용 | 국가대표AI 1차 탈락; 사우디 아람코 MOU 참여; 재도전 포기 | [ncsoft.com](https://www.ncsoft.com/) |
| 23 | **메가존클라우드** | 메가존클라우드 | 2023~ AI 사업 확대 | 클라우드+AI 인프라 구축/운영 — AWS/Azure 파트너 | 성장 | 국내 최대 MSP | 사우디 아람코 MOU 참여; AI 인프라 구축 수요 급증 | [megazone.com](https://www.megazone.com/) |
| 24 | **유라클** | 유라클 | 2023~ | LLM 운영/서비스 관리 솔루션 | 성장 | 국내 기업 고객 | 사우디 아람코 MOU 참여 | — |

### 🖥️ AI 반도체

| # | 이름 | 회사 | 출시/주요 업데이트 | 핵심 기능 | 현재 상태 | 사용자/매출 | 주요 사건 | 출처 |
|---|------|------|-------------------|-----------|-----------|-------------|-----------|------|
| 25 | **Rebellions AI Chips (ATOM/Rebel)** | 리벨리온 (Rebellions) | 2020 설립, 2021 Ion 칩, 2023 ATOM, 2024 Rebel | AI 추론 전용 NPU — 데이터센터/엣지용 AI 칩 | 급성장 | Series B $1.24억 | Sapeon 합병→한국 최초 AI칩 유니콘; 삼성 협업; 2025 IPO 검토; 사우디 아람코 MOU | [Wikipedia](https://en.wikipedia.org/wiki/Rebellions_(company)) |
| 26 | **FuriosaAI** | 퓨리오사AI | 2017 설립 | AI 추론 가속기 — RNGD 칩 | 성장 | 시리즈B+ 투자 유치 | 사우디 아람코 MOU 참여; 한국 AI 반도체 양대 산맥 | [furiosa.ai](https://www.furiosa.ai/) |

### 🎨 AI 이미지/영상/크리에이티브

| # | 이름 | 회사 | 출시/주요 업데이트 | 핵심 기능 | 현재 상태 | 사용자/매출 | 주요 사건 | 출처 |
|---|------|------|-------------------|-----------|-----------|-------------|-----------|------|
| 27 | **뤼튼 이미지 생성** | 뤼튼테크놀로지스 | 2024~2025 | AI 이미지 생성 — 텍스트→이미지, 무료 제공 | 성장 | 뤼튼 플랫폼 내 통합 | 한국 10대 사이에서 AI 이미지 생성 '짤 만들기' 유행 | [wrtn.ai](https://wrtn.ai/) |
| 28 | **카카오브레인 Karlo** | 카카오브레인 | 2022.12 출시, 2023 업데이트 | AI 이미지 생성 — 텍스트→이미지 (한국어 지원) | 정체 | 카카오 생태계 내 | 카카오 AI 조직 재편 과정에서 독립 서비스 지위 불투명 | [karlo.ai](https://karlo.ai/) |
| 29 | **SNOW / B612 AI** | SNOW Corp (네이버 자회사) | 2023~2025 AI 기능 강화 | AI 프로필사진, AI 아바타, 뷰티 필터 | 성장 | 글로벌 수억 다운로드 | AI 프로필사진 한국에서 대유행 (2023); AI 프로필 트렌드 선도 | [snow.me](https://snow.me/) |

### ⚖️ AI 법률/문서 (리걸테크)

| # | 이름 | 회사 | 출시/주요 업데이트 | 핵심 기능 | 현재 상태 | 사용자/매출 | 주요 사건 | 출처 |
|---|------|------|-------------------|-----------|-----------|-------------|-----------|------|
| 30 | **인텔리콘 (Intellicon)** | 인텔리콘 | 2018 설립, 2023~ AI 법률 서비스 | AI 기반 법률 리서치, 판례 분석, 계약서 검토 | 성장 | 국내 로펌·기업 법무팀 | 한국 리걸테크 대표 스타트업 | [intellicon.ai](https://www.intellicon.ai/) |
| 31 | **로앤컴퍼니 (LawTalk)** | 로앤컴퍼니 | 2015 설립, 2024 AI 기능 추가 | 변호사 매칭 플랫폼 + AI 법률 상담 | 성장 | 국내 법률 플랫폼 1위 | AI 법률 Q&A 추가; 변호사 네트워크 기반 | [lowtalk.co.kr](https://www.lawtalk.co.kr/) |

### 🤖 AI 코딩/개발 도구

| # | 이름 | 회사 | 출시/주요 업데이트 | 핵심 기능 | 현재 상태 | 사용자/매출 | 주요 사건 | 출처 |
|---|------|------|-------------------|-----------|-----------|-------------|-----------|------|
| 32 | **VARCO (엔씨소프트 LLM 코드 모델)** | 엔씨소프트 | 2023~ | 자체 LLM VARCO 시리즈 — 코드 생성 포함 | 성장 (느림) | 내부 활용 중심 | 한국 자체 코딩 AI는 아직 글로벌 GitHub Copilot/Cursor 수준에 미달; 대부분 해외 도구 사용 | — |
| 33 | **네이버 CLOVA Code** | 네이버 | 2024~ | 코드 생성/자동완성 — HyperCLOVA X 기반 개발자 도구 | 초기 | 네이버 내부 우선 | 글로벌 경쟁 대비 초기 단계 | — |

---

## 분야별 정리

### LLM/파운데이션 모델 경쟁 구도 (2026.02 기준)

| 순위 (국내) | 모델 | 회사 | 비고 |
|-------------|------|------|------|
| 1 | K-EXAONE | LG AI연구원 | Artificial Analysis Index 국내 1위 |
| 2 | HyperCLOVA X SEED Think 32B | 네이버클라우드 | 국내 2위; 국가대표AI 프로젝트 탈락 |
| 3 | Motif-2-12.7B | 모티프테크놀로지스 | 신흥 스타트업 |
| — | Solar Pro 3 | 업스테이지 | 프런티어급; 글로벌 벤치마크 상위 |
| — | Kanana | 카카오 | 내부 활용 중심 |
| — | 에이닷 AI | SKT | 통신사 AI 비서 |

### 국가대표 AI 파운데이션 모델 프로젝트

과기정통부가 2024년 6월 시작한 프로젝트. 글로벌 AI 모델 대비 95% 이상 성능 목표.

- **1차 통과 (2025.01)**: LG AI연구원, SK텔레콤, 업스테이지
- **1차 탈락**: 네이버클라우드, NC AI (둘 다 재도전 포기)
- **추가 공모 (2026.01~02)**: 모티프테크놀로지스, 트릴리온랩스 2곳 접수
- **지원**: 엔비디아 B200 768장, 데이터 공동 구매, 'K-AI 기업' 명칭 부여
- **2차 평가**: 2026년 8월 예정 (벤치마크+전문가+사용자+글로벌 리더보드)

### 한국 AI 의료 — 글로벌 선두

| 회사 | 제품 | 글로벌 진출 |
|------|------|-------------|
| Lunit | INSIGHT CXR, MMG, DBT, SCOPE IO/PD-L1 | 70+ 국가, 1만+ 의료기관; WHO 권고; AstraZeneca, Guardant, Microsoft, NCI 파트너 |
| VUNO | VUNO Med (흉부, 골밀도, 심전도) | 국내 중심, 동남아 확장 중 |

### 한국 AI 반도체 — NVIDIA 대안 도전

| 회사 | 칩 | 비고 |
|------|-----|------|
| 리벨리온 | ATOM, Rebel | 사페온 합병→유니콘; 삼성 파운드리 협업; 2025 IPO 검토 |
| 퓨리오사AI | RNGD | 추론 가속기; 데이터센터용 |

---

## 정책/규제 흐름

### AI 기본법 타임라인

| 시점 | 사건 |
|------|------|
| 2024.12 | AI 기본법 국회 통과 — 세계 두 번째 (EU AI Act 다음) |
| 2025.01~ | 하위법령 정비단 운영 (민간 전문가 80명, 70여 차례 의견수렴) |
| 2025.09 | 국가AI전략위원회 출범; 시행령 초안 공개 |
| 2025.11 | 입법예고 |
| 2026.01.22 | **AI 기본법 전면 시행** |

### AI 기본법 주요 내용
- **국가AI전략위원회**: 대통령 위원장, 법정위원회로 격상
- **AI 산업 진흥**: R&D, 학습데이터, AI 도입/활용, 창업, 융합, 인력, 데이터센터 지원
- **필요최소 규제 원칙**: 기업 의무사항·제재 최소화
- **1년 계도기간**: 사실조사/과태료 유예 (인명사고·인권훼손 시에만 사실조사)
- **AI 투명성**: AI 생성물 워터마크 의무 (딥페이크 방지)
- **AI 기본법 지원데스크**: 기업 컨설팅 제공 (익명 가능)

### 과기정통부 AI 정책 (2025~2026)
- 독자 AI 파운데이션 모델 프로젝트 (국가대표 AI)
- AI 안전 생태계 조성 마스터플랜
- AX(AI 전환) 대학원 확대 (2026년 10개 신규, 연간 30억)
- 피지컬 AI 실증 사업
- 한국형 국제 사업 (1441억원 — AI·디지털 스타트업 전주기 지원)
- 국방 AX 가속화 (국방 공개데이터 → AI 개발팀 제공)
- 양자 분야 마스터플랜 (3년간 210억 투자)

### 주요 규제/논란 이슈
- **2026.02**: 딥페이크 영상 이용 허위사실 공표죄 최초 고발 (선관위)
- **2025~2026**: 네이버/카카오 AI 데이터 수집 관련 개인정보보호 이슈
- **2024~2025**: 삼성 Galaxy AI 무료→유료 전환 가능성 논란 (2025년까지 무료 유지 발표)

---

## 한국 AI 생태계 특징 요약

### 강점
1. **재벌 주도 생태계**: 삼성(Galaxy AI), 네이버(HyperCLOVA X), 카카오(Kanana), SK(에이닷), LG(EXAONE) — 대기업이 AI 인프라 주도
2. **AI 의료 글로벌 선두**: Lunit은 세계적 AI 의료 기업으로 성장
3. **AI 반도체 독자 개발**: 리벨리온, 퓨리오사AI — NVIDIA 대안 칩 개발
4. **정부 적극 지원**: 국가대표AI 프로젝트, AI 기본법, AX 정책
5. **빠른 사용자 채택**: 뤼튼(무료 AI), Galaxy AI(기기 내장) 등 빠른 대중화

### 약점/과제
1. **글로벌 LLM 격차**: OpenAI, Google, Anthropic 대비 성능 차이 (Solar Pro 2가 최초 프런티어급)
2. **코딩 AI 부재**: GitHub Copilot, Cursor 등 해외 도구 의존
3. **독자 생태계 파편화**: 각 대기업이 독자 LLM 개발 → 자원 분산
4. **인재 유출**: AI 핵심 인력 해외(미국) 유출 문제
5. **데이터 부족**: 한국어 학습데이터 규모가 영/중어 대비 제한적

### 글로벌 평가
- 2026.02 기준, 글로벌 AI 평가기관에서 **한국을 세계 3위 AI 국가로 평가** (미국, 중국 다음)
- 사우디 아람코와 'AI 풀스택' MOU — 한국 AI의 중동 진출 본격화

---

## 출처 목록

| # | 출처 | URL |
|---|------|-----|
| 1 | Wikipedia — Upstage (company) | https://en.wikipedia.org/wiki/Upstage_(company) |
| 2 | Wikipedia — Clova (virtual assistant) | https://en.wikipedia.org/wiki/Clova_(virtual_assistant) |
| 3 | Wikipedia — Galaxy AI | https://en.wikipedia.org/wiki/Galaxy_AI |
| 4 | Wikipedia — Bixby (software) | https://en.wikipedia.org/wiki/Samsung_Bixby |
| 5 | Wikipedia — Naver Papago | https://en.wikipedia.org/wiki/Naver_Papago |
| 6 | Wikipedia — DeepL Translator | https://en.wikipedia.org/wiki/DeepL_Translator |
| 7 | Wikipedia — Rebellions (company) | https://en.wikipedia.org/wiki/Rebellions_(company) |
| 8 | Wikipedia — Naver Corporation | https://en.wikipedia.org/wiki/Naver_Corporation |
| 9 | Wikipedia — Kakao | https://en.wikipedia.org/wiki/Kakao |
| 10 | Wikipedia — SK Telecom | https://en.wikipedia.org/wiki/SK_Telecom |
| 11 | AI타임스 — AI 기본법 22일 시행 | https://www.aitimes.com/news/articleView.html?idxno=205781 |
| 12 | AI타임스 — 국가대표 AI 추가팀 공모 | https://www.aitimes.com/news/articleView.html?idxno=205865 |
| 13 | AI타임스 — 모티프·트릴리온랩스 국가대표AI 경합 | https://www.aitimes.com/news/articleView.html?idxno=206825 |
| 14 | AI타임스 — 7개사 사우디 아람코 AI 풀스택 | https://www.aitimes.com/news/articleView.html?idxno=206226 |
| 15 | AI타임스 — AI 서울 2026 | https://www.aitimes.com/news/articleView.html?idxno=206306 |
| 16 | AI타임스 — AX대학원 10개 신규 | https://www.aitimes.com/news/articleView.html?idxno=206963 |
| 17 | AI타임스 — AI 투명성 가이드라인 | https://www.aitimes.com/news/articleView.html?idxno=205782 |
| 18 | AI타임스 — 딥페이크 고발 사례 | https://www.aitimes.com/news/articleView.html?idxno=206597 |
| 19 | Financial Times — Upstage enters global AI race (2025.08) | https://www.ft.com/content/549a34f1-5eb5-43bd-8400-2171e6e32022 |
| 20 | DigiTimes — Solar Pro 2 takes global stage (2025.07) | https://www.digitimes.com/news/a20250722PD219/ |
| 21 | Yonhap — Upstage Series B (2024.04) | https://en.yna.co.kr/view/AEN20240416007500320 |
| 22 | Korea Herald — Rebellions Sapeon merge (2024.12) | https://www.koreaherald.com/article/10012110 |
| 23 | TechCrunch — Rebellions $124M (2024.01) | https://techcrunch.com/2024/01/29/rebellions-lands-124m-for-ai-chip-rebel-in-collab-with-samsung/ |
| 24 | Forbes — Korea AI Chip Champion (2025) | https://www.forbes.com/sites/johnkang/2025/04/14/south-koreas-ai-chip-champion-is-poised-to-carve-out-global-niche/ |
| 25 | KEDGlobal — Upstage Solar in KakaoTalk (2024.01) | https://www.kedglobal.com/artificial-intelligence/newsView/ked202401110002 |
| 26 | Lunit 공식 | https://www.lunit.io/ |
| 27 | 업스테이지 공식 | https://www.upstage.ai/ |
| 28 | 뤼튼 공식 | https://wrtn.ai/ |
| 29 | LG AI Research 공식 | https://www.lgresearch.ai/ |
| 30 | CLOVA X 공식 | https://clova-x.naver.com/ |

---

*이 문서는 2026-02-21 기준으로 작성되었으며, 웹 검색(web_fetch)을 통해 수집한 정보와 공개 출처를 기반으로 합니다. 일부 정보는 최신 상황과 다를 수 있습니다.*
