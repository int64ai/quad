# GPT-5.3 / GPT-5.3-Codex 조사 결과

> 조사일: 2026-02-20  
> 방법: OpenAI 공식 모델 목록 및 개발자 문서 직접 확인  
> Tavily API 할당량 초과로 web_fetch로 대체

## 핵심 결론: GPT-5.3은 존재하지 않는다

**2026년 2월 20일 현재, OpenAI는 GPT-5.3 또는 GPT-5.3-Codex를 출시한 적이 없다.**

OpenAI 공식 모델 목록(developers.openai.com/api/docs/models)에 GPT-5.3 관련 모델은 **단 하나도 없다**.

---

## 1. GPT-5.3은 별도로 발표/출시된 모델인가?

**아니다.** GPT-5.3은 존재하지 않는다. 최신 모델은 **GPT-5.2** (2025-12-11 스냅샷).

---

## 2. 실제 존재하는 OpenAI GPT-5 패밀리 모델 (공식 확인)

### 기본 모델
| 모델 | 설명 | 스냅샷/출시일 | 가격 (Input/Output per 1M) |
|------|------|-------------|--------------------------|
| **GPT-5** | 최초 GPT-5, 코딩/에이전틱 추론 | 2025-08-07 | $1.25/$10 |
| **GPT-5 mini** | GPT-5의 작은 버전 | - | $0.25/- |
| **GPT-5 nano** | 가장 빠르고 저렴한 버전 | - | $0.05/- |
| **GPT-5.1** | GPT-5 후속, reasoning effort 구성 가능 | 2025-11-13 | $1.25/$10 |
| **GPT-5.2** | 현재 최신 플래그십 | 2025-12-11 | $1.75/$14 |
| **GPT-5.2 pro** | GPT-5.2의 확장 추론 버전 | - | - |

### Codex 변형
| 모델 | 설명 |
|------|------|
| **GPT-5-Codex** | GPT-5 기반, Codex 에이전틱 코딩 최적화 |
| **GPT-5.1-Codex** | GPT-5.1 기반 | $1.25/- |
| **GPT-5.1-Codex-Max** | 장시간 실행 작업 최적화 |
| **GPT-5.1-Codex-Mini** | 비용 효율적 소형 버전 |
| **GPT-5.2-Codex** | **현재 최신** Codex 모델 | $1.75/$14 |

### ChatGPT 변형
- gpt-5-chat-latest
- gpt-5.1-chat-latest
- gpt-5.2-chat-latest

---

## 3. GPT-5 → 5.1 → 5.2 변경 사항

### GPT-5 → GPT-5.1
- reasoning effort 구성 가능 (none, low, medium, high)
- 지식 cutoff 동일: 2024-09-30

### GPT-5.1 → GPT-5.2
- **새 기능**: xhigh reasoning effort 레벨 추가
- **새 기능**: concise reasoning summaries
- **새 기능**: context management using compaction
- 일반 지능, 지시 따르기, 정확성, 토큰 효율성 향상
- 멀티모달(특히 vision) 향상
- 코드 생성(특히 프론트엔드 UI) 향상
- 스프레드시트 이해/생성 향상
- 지식 cutoff: 2025-08-31 (5.1의 2024-09-30에서 크게 확장)
- 가격 인상: $1.25→$1.75 (input), $10→$14 (output)

---

## 4. OpenAI 모델 버전 체계

OpenAI는 GPT-5 패밀리에서 **점진적 소수점 버전**을 사용:
- **GPT-5** (v1, 2025-08): 기본 모델
- **GPT-5.1** (2025-11): 첫 번째 업데이트
- **GPT-5.2** (2025-12): 두 번째 업데이트, 현재 최신

각 버전에 대해 파생 모델 존재:
- **-Codex**: 에이전틱 코딩 최적화 (Codex 환경용)
- **-pro**: 확장 추론 (더 많은 compute 사용)
- **-chat-latest**: ChatGPT 제품에서 사용되는 버전
- **mini/nano**: 소형/초소형 저비용 버전

이전 세대(GPT-4 계열)에서는 GPT-4.1, GPT-4.1 mini, GPT-4.1 nano 등이 있었음.

---

## 5. GPT-5.2-Codex vs GPT-5.2 차이

공식 문서 기준:
- **GPT-5.2**: "The best model for coding and agentic tasks across industries" — 범용 플래그십
- **GPT-5.2-Codex**: "Our most intelligent coding model optimized for long-horizon, agentic coding tasks" — Codex/코딩 에이전트 환경 특화

주요 차이:
- GPT-5.2: reasoning effort `none`(기본), low, medium, high, xhigh
- GPT-5.2-Codex: reasoning effort low, medium, high, xhigh (none 없음, 항상 reasoning)
- GPT-5.2: Distillation 지원 / GPT-5.2-Codex: Distillation 미지원
- 동일 가격: $1.75/$14 per 1M tokens
- 동일 context: 400K / 128K max output

---

## 6. Terminal-Bench 2.0 관련

검색 결과에서 "Terminal-Bench 2.0"에 대한 정보는 발견되지 않았다. 공식 OpenAI 벤치마크로는 SWE-bench Verified, Aider Polyglot, τ2-bench, AIME, MMMU, HealthBench 등이 언급됨.

---

## 출처

- https://developers.openai.com/api/docs/models (전체 모델 목록)
- https://developers.openai.com/api/docs/models/gpt-5.2 (GPT-5.2 상세)
- https://developers.openai.com/api/docs/models/gpt-5.2-codex (GPT-5.2-Codex 상세)
- https://developers.openai.com/api/docs/models/gpt-5.1 (GPT-5.1 상세)
- https://developers.openai.com/api/docs/models/gpt-5 (GPT-5 상세)
- https://developers.openai.com/api/docs/guides/latest-model (GPT-5.2 사용 가이드)
- https://openai.com/index/introducing-gpt-5/ (GPT-5 소개 블로그)
- https://openai.com/index/introducing-gpt-5-for-developers/ (GPT-5 개발자용 소개)
- https://openai.com/index/introducing-codex/ (Codex 소개)
