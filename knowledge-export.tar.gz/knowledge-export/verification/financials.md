# 재무 수치 독립 검증 보고서

> 작성일: 2026-02-18
> 목적: 1차 AI 서비스 시장 조사의 핵심 재무 수치를 독립 소스로 교차 검증

---

## 1. Gamma

### 1차 조사 수치
- ARR $102M (2025 Oct), 52명 팀, 365% YoY 성장, $2.1B 밸류에이션
- 출처: Sacra

### 독립 검증
| 수치 | Sacra | 독립 소스 | 출처 |
|------|-------|-----------|------|
| ARR | $102M (Oct 2025) | "$100M+ ARR while profitable" | a16z 공식 투자 발표 (Nov 2025) |
| 밸류에이션 | $2.1B | $2.1B (a16z led $68M round) | a16z 투자 발표 |
| 총 펀딩 | $80M | $68M (Series) + $12M (2024) = $80M | a16z 투자 발표 / Sacra 일치 |
| 사용자 | 70M customers, 600K paying | "over 70 million users" | a16z 투자 발표 |
| 팀 규모 | 52명 | 명시 없음 (a16z에서는 미언급) | Sacra만 |
| 성장률 | 365% YoY ($30.5M→$102M) | 수학적 정합: $30.5M→$102M = ~234%, 아닌 365% | **계산 불일치** |
| 수익성 | 2023년부터 흑자 | "profitable" 확인 | a16z 투자 발표 |

### 판정: ✅ 대체로 일치 / ⚠️ 성장률 계산 주의
- **신뢰도: 높음**
- a16z가 "$100M+ ARR while profitable"을 공식 발표에서 직접 언급 → 투자자가 검증한 수치로 신뢰도 높음
- ⚠️ 365% 성장률: Sacra 기준 "2024년 성장률"이라 하면 2023→2024 ($30.5M 2024 말 기준이면 이전 연도에서의 성장). Sacra 원문은 "2024" 시점 성장률로 표기. 2023 초→2024 말 $30.5M이면 이전 기저가 ~$6.5M이어야 365% 성립. 가능하나 검증 불가.
- 52명 팀으로 $100M ARR 달성은 $1.96M ARR/직원으로 이례적이지만, PLG + freemium 모델에선 이론적으로 가능

---

## 2. Synthesia

### 1차 조사 수치
- ARR $146M, $4B 밸류, Fortune 100의 90% 사용
- 출처: Sacra

### 독립 검증
| 수치 | Sacra | 독립 소스 | 출처 |
|------|-------|-----------|------|
| ARR | $146M (Sep 2025) | "$100M ARR 돌파" (Apr 2025) | Sacra 자체 언급 (회사 발표 인용) |
| 밸류에이션 | $4B (Jan 2026 Series E) | $4B (Series E, $200M, GV led) | Sacra (Series E 세부 확인) |
| 이전 밸류 | $2.1B (Jan 2025 Series D) | $2.1B, $180M, NEA led | Sacra 일관 |
| Fortune 100 | "90% of Fortune 100" | Sacra 원문: "80% of Fortune 100"→후반부 "90% of Fortune 100 and 70% of FTSE 100" | **Sacra 내에서도 80%↔90% 혼용** |
| 총 펀딩 | $530M+ | 계산: $90M(C) + $180M(D) + $200M(E) + 기타 = ~$530M 정합 | 펀딩 이력으로 계산 가능 |
| 직원 | ~600명 | 명시 없음 (독립 확인 불가) | Sacra만 |

### 판정: ⚠️ 부분 일치 / Fortune 100 수치 불안정
- **신뢰도: 중간**
- ARR $146M은 Sacra 추정치 (Oct 2025). 회사 자체 "$100M ARR" 발표(Apr 2025)와 방향은 일치하나, $146M 자체는 Sacra 추정
- **"Fortune 100의 90%"는 마케팅 과장 가능성 높음**: Sacra 원문에서도 경쟁 섹션에서 "80%"로, 후반부에서 "90%"로 기재. 이런 수치는 보통 "최소 1명의 유저가 계정 보유" 기준일 가능성. 실제 엔터프라이즈 계약 기반은 아닐 수 있음
- $4B 밸류는 Series E 기준으로 실제 펀딩 이벤트에 기반하여 비교적 신뢰

---

## 3. HeyGen

### 1차 조사 수치
- ARR $95M, $74M 펀딩으로 흑자
- 출처: Sacra

### 독립 검증
| 수치 | Sacra | 독립 소스 | 출처 |
|------|-------|-----------|------|
| ARR | $95M (Sep 2025) | 독립 확인 불가 | Sacra만 |
| 밸류에이션 | $500M (2023 Series A) | $500M, $60M Series A, Benchmark led | Sacra + HeyGen about 페이지 투자자 확인 (Benchmark, Conviction, Thrive, Bond) |
| 총 펀딩 | $74M | $60M (Series A) + ~$14M (이전) | Sacra 기반 계산 |
| 흑자 | "Q2 2023부터 흑자, ~20% 마진" | Sacra에서만 언급 | **독립 확인 불가** |
| 성장 이력 | $1M→$2M→$3M (2023 초) | Sacra에서 제공 | Sacra만 |

### 판정: ⚠️ 검증 불충분
- **신뢰도: 낮음~중간**
- ARR $95M은 순전히 Sacra 추정치. 회사 공식 발표 없음
- 흑자 여부: Sacra가 "profitability achieved in Q2 2023 suggesting operating margins around 20%"라고 기술. 이는 $24/mo unlimited 모델에서 ElevenLabs/OpenAI API 비용을 감안하면 가능하지만, 독립 검증 소스 없음
- 밸류에이션 $500M은 2023년 기준. 2025년 기준 밸류에이션 업데이트 없음 → 현재 가치는 훨씬 높을 가능성
- 투자자 목록(Benchmark, Thrive, Bond)은 HeyGen 공식 사이트에서 확인

---

## 4. Granola

### 1차 조사 수치
- "temporarily unsustainable economics" 인정
- ARR/사용자 수 미확인
- 출처: Sacra

### 독립 검증
| 수치 | Sacra | 독립 소스 | 출처 |
|------|-------|-----------|------|
| ARR | **미공개** (Sacra에도 ARR 수치 없음) | 확인 불가 | — |
| 가격 | $18/user/mo (개인), $14/user (비즈니스), $35 (엔터프라이즈) | 확인 불가 | Sacra만 |
| 사용자 | 57% 리더십 포지션 | 확인 불가 | Sacra만 |
| 무료 한도 | 25회 무료 미팅 후 유료 전환 | 확인 불가 | Sacra만 |
| 비용 구조 | "temporarily unsustainable economics" — 프론티어 AI 모델 사용 비용 | Sacra 상세 분석 | Sacra |
| 제품 현황 | Mac 전용, 2025 모바일 예정 | 공식 블로그 내용 없음 (빈 페이지) | Sacra만 |

### 판정: 🔴 검증 불가
- **신뢰도: 미검증**
- Sacra 페이지에 ARR 헤드라인 수치 자체가 없음 → revenue 데이터가 존재하지 않음
- "temporarily unsustainable economics"는 Sacra 분석 내용 (회사가 직접 인정한 것인지, Sacra가 해석한 것인지 불명확)
- 매우 초기 단계 스타트업으로 보이며, 공개 재무 데이터가 극히 부족
- 공식 블로그도 실질적 내용 없음

---

## 5. n8n

### 1차 조사 수치
- ARR $40M, $2.5B 밸류에이션
- 출처: Sacra

### 독립 검증
| 수치 | Sacra | 독립 소스 | 출처 |
|------|-------|-----------|------|
| ARR | $40M (Jul 2025) | "10x revenue growth" (블로그에서 언급) | n8n 공식 블로그 (Oct 2025) |
| 밸류에이션 | $2.5B | $2.5B | n8n 공식 블로그 (Oct 2025) |
| 펀딩 라운드 | $180M Series C, Accel led | $180M Series C, Accel led, NVentures 참여 | n8n 공식 블로그 (Oct 2025) |
| 총 펀딩 | $253.5M | $240M | n8n 블로그 ("bringing our total funding to $240 million") |
| 사용자 | 230K+ active users | "6x user growth" | n8n 블로그 (상대적 언급만) |
| 이전 라운드 | €55M Series B (Mar 2025), €300M 밸류, Highland Europe | 일치 | Sacra |

### 판정: ✅ 대체로 일치
- **신뢰도: 높음**
- $2.5B 밸류와 $180M Series C는 회사 공식 블로그에서 직접 확인
- 총 펀딩: Sacra $253.5M vs n8n 블로그 $240M → **약 $13M 차이**. Sacra가 이전 라운드를 더 세밀히 계산했거나, n8n이 반올림했을 수 있음
- "10x revenue growth" 언급 → ARR $40M이 맞다면 이전 ~$4M에서 성장한 것이므로 Sacra의 $40M과 방향 일치
- 가장 신뢰할 수 있는 수치 중 하나 (회사 직접 발표)

---

## 6. Notion

### 1차 조사 수치
- ARR $500M
- 출처: Sacra

### 독립 검증
| 수치 | Sacra | 독립 소스 | 출처 |
|------|-------|-----------|------|
| ARR | $500M (Sep 2025) | 독립 확인 불가 | Sacra만 |
| 밸류에이션 | $10B (Oct 2021) | $10B (Series C, Coatue/Sequoia led) | 널리 보도된 사실 |
| 총 펀딩 | $344M | ~$344M | 다수 소스 일치 |
| 가격 | $10/seat (Plus), $20/seat (Business) | 공식 사이트에서 확인 가능 | Notion 공식 |

### 판정: ⚠️ 부분 검증
- **신뢰도: 중간**
- $500M ARR은 순전히 Sacra 추정치. Notion은 비상장이고 ARR을 공식 발표하지 않음
- 그러나 $10B 밸류(2021)와 4년간의 성장을 감안하면 $500M은 합리적 범위
- 2021년 $10B 밸류 시점에서 추정 ARR ~$100-150M 수준이었으므로, 4년간 3-5x 성장은 합리적
- 마지막 밸류에이션이 2021년이라 현재 기업가치는 불명확 (시장에서 $15-25B 추정)

---

## 7. Zapier

### 1차 조사 수치
- ARR $310M+
- 출처: Sacra

### 독립 검증
| 수치 | Sacra | 독립 소스 | 출처 |
|------|-------|-----------|------|
| ARR | $310M (end of 2023) | 독립 확인 불가 | Sacra만 |
| 성장률 | 35% YoY (2023) | Sacra 추정 | Sacra |
| 밸류에이션 | $5B (2021) | $5B (Sequoia led) | 널리 보도 |
| 총 펀딩 | $1.4M | $1.4M (seed only) | 다수 소스 일치 |
| 수익성 | 2014년부터 흑자 | 널리 알려진 사실 | 다수 소스 |

### 판정: ⚠️ 부분 검증 / 오래된 데이터
- **신뢰도: 중간~낮음**
- **$310M은 2023년 말 추정치** → 현재(2026년 2월) 기준 2년+ 오래된 데이터
- 35% YoY 성장 유지 시 현재 ~$565M 수준일 수 있으나 추측
- Zapier의 극도의 자본 효율성($1.4M 펀딩→$310M+ ARR)은 유명한 사실
- BusinessofApps에 Zapier 통계 페이지 없음 (404)
- 2023년 이후 업데이트된 ARR 정보를 찾을 수 없음

---

## 8. Perplexity

### 1차 조사 수치
- MAU 3000만~4500만, ARR $1.48억, $180~200억 밸류
- 출처: Sacra

### 독립 검증
| 수치 | Sacra | DemandSage | BusinessofApps | 판정 |
|------|-------|------------|----------------|------|
| MAU | 30M | 45M | 45M (website+app) / 20M (active users로 별도 표현) | **수치 분산** |
| ARR | $148M (Jun 2025) | $148M | "$80M run rate by end 2024" (2025 수치는 2배+ 예상) | ✅ 일치 |
| 밸류에이션 | $20B (Sep 2025) | $20B | "$9B" (outdated, Oct 2024 기준) | ✅ 최신 $20B 일치 |
| 총 펀딩 | $1.22B | $1.22B+ (상세 라운드 합계) | "$915M" → **outdated** (Sep 2025 라운드 미반영) | 소스 갱신 시점 차이 |
| 쿼리 | 780M/월 (May 2025) | 780M (May 2025) | "230M 쿼리 이래" (매우 오래됨) | ✅ 최신 소스 일치 |

### 판정: ✅ 대체로 일치
- **신뢰도: 높음**
- ARR $148M은 Sacra와 DemandSage 모두 일치 (DemandSage는 Sacra를 소스로 인용)
- $20B 밸류는 Sacra, DemandSage 모두 확인
- MAU: "30M" vs "45M" 차이는 시점 차이. Sacra는 "about 30M monthly users" (June 2025 기준), DemandSage는 "45M" (H2 2025). 급성장 중이라 시점 차이 설명 가능
- ⚠️ BusinessofApps 데이터는 상당 부분 outdated (2024 Q4 기준)
- DemandSage의 $148M ARR 소스는 TechCrunch, Yahoo Finance, **Sacra** → 독립 소스라기보다 Sacra 재인용

---

## 9. Character.AI

### 1차 조사 수치
- MAU 20M, $30-50M 매출, 피크에서 하락
- 출처: Sacra

### 독립 검증
| 수치 | Sacra | DemandSage | BusinessofApps | 판정 |
|------|-------|------------|----------------|------|
| MAU | 20M (early 2024에서 인용) | 20M (2025) | 20M (Jan 2025, 피크 28M에서 하락) | ✅ 일치 |
| 매출 | $30M (Jul 2025 annualized), 연말 $50M 전망 | $32.2M | 매출 수치 미게시 | ✅ 범위 일치 |
| 밸류에이션 | $1B (Mar 2023 Series A) | $1B (2025), 피크 $2.5B (2024) | Google $2.7B acqui-hire 투자 (Aug 2024) | ✅ 일치 |
| 펀딩 | $193M (2 rounds) | $193M (Seed $43M + Series A $150M) | "$150K" (오류 — $150M의 오기) | ✅ 일치 |
| 하락 추세 | 언급 없음 | 피크 28M→20M (하락) | "20M, 6개월간 8M 감소" | ✅ 하락 확인 |

### 판정: ✅ 일치
- **신뢰도: 높음**
- MAU 20M, 피크 28M에서 하락은 3개 소스 모두 일치
- $30-50M 매출 범위: Sacra $30M (Jul 2025), DemandSage $32.2M → 일치
- Google acqui-hire ($2.7B 투자)는 BusinessofApps에서 확인
- 하락 원인: "affordable and more capable generative AI chatbots의 등장" (DemandSage)
- ⚠️ BusinessofApps 펀딩 섹션에 "$150K"는 명백한 오류 ($150M이어야 함)

---

## 10. Descript

### 1차 조사 수치
- ARR $55M, 75% 성장
- 출처: Sacra

### 독립 검증
| 수치 | Sacra | 독립 소스 | 출처 |
|------|-------|-----------|------|
| ARR | $55M (late 2024) | 독립 확인 불가 | Sacra만 |
| 성장률 | 75% YoY | 독립 확인 불가 | Sacra만 |
| 총 펀딩 | $100M | $100M (Series C $50M by OpenAI Startup Fund, Nov 2022) | Sacra (다수 소스에서 확인된 펀딩) |
| 가격 | Creator $144/yr, Pro $288/yr, Enterprise ~$600/yr | 공식 사이트에서 확인 가능 | Descript 공식 |

### 판정: ⚠️ 검증 불충분
- **신뢰도: 낮음**
- ARR $55M과 75% 성장은 오직 Sacra 추정치
- Sacra 원문에서 "$55M in late 2024"이라 했는데, 이는 "representing 75% year-over-year growth"와 함께 "$31M ARR as of August 2024"라는 중간 수치도 제공 → 자체 모순? (late 2024에 $55M이면 Aug 2024에 $31M은 4개월 만에 77% 성장 의미 → 가능하나 급격)
- OpenAI Startup Fund의 $50M Series C (2022)는 널리 보도된 사실
- 비상장 회사로 공개 데이터 부족

---

## 요약 매트릭스

| 회사 | 핵심 수치 | 신뢰도 | 검증 결과 | 특이사항 |
|------|----------|--------|-----------|----------|
| **Gamma** | ARR $102M | 🟢 높음 | ✅ a16z가 "$100M+ ARR profitable" 확인 | 365% 성장률 계산법 불명확 |
| **Synthesia** | ARR $146M, $4B | 🟡 중간 | ⚠️ ARR은 추정, 밸류는 확인 | Fortune 100 "90%" 수치 불안정 (80%↔90%) |
| **HeyGen** | ARR $95M, 흑자 | 🟡 중간~낮음 | ⚠️ 대부분 Sacra만 | 흑자 주장 독립 검증 불가 |
| **Granola** | ARR 미공개 | 🔴 미검증 | 🔴 데이터 부족 | 매우 초기, ARR 자체가 없음 |
| **n8n** | ARR $40M, $2.5B | 🟢 높음 | ✅ 공식 블로그에서 확인 | 총 펀딩 $13M 차이 (반올림) |
| **Notion** | ARR $500M | 🟡 중간 | ⚠️ Sacra 추정만 | 비상장, 마지막 밸류 2021년 |
| **Zapier** | ARR $310M+ | 🟡 중간~낮음 | ⚠️ 2023년 데이터, 현재 불명 | 2년+ 오래된 수치 |
| **Perplexity** | ARR $148M, $20B | 🟢 높음 | ✅ 다수 소스 일치 | MAU 30M→45M 시점 차이 |
| **Character.AI** | MAU 20M, $30-50M | 🟢 높음 | ✅ 3개 소스 일치 | 피크에서 하락 확인 |
| **Descript** | ARR $55M | 🔴 낮음 | ⚠️ Sacra만 | 중간 수치 자체 모순 가능 |

---

## 방법론 한계

1. **web_search 미사용** (Brave API 키 없음) → URL을 직접 추측하여 fetch하는 방식으로 제한
2. **TechCrunch, Forbes, Reuters** 등 주요 뉴스 소스는 대부분 403/404 반환 → 페이월 또는 봇 차단
3. **Crunchbase** Cloudflare 차단
4. **DemandSage와 BusinessofApps**는 많은 소규모 AI 회사에 대해 통계 페이지 없음
5. **DemandSage의 Perplexity 데이터**는 Sacra를 소스로 인용 → "독립" 검증이 아닌 재인용

### 소스별 신뢰도 평가
- **Sacra**: 추정치 기반. 정확할 수 있지만 독립 검증이 필요한 1차 소스
- **a16z/회사 공식 블로그**: 투자자/회사 자체 발표로 가장 신뢰할 수 있지만, 과장 인센티브 존재
- **DemandSage/BusinessofApps**: 2차 집계 소스. 종종 Sacra나 다른 추정치를 재인용
- **SimilarWeb**: 트래픽/MAU 추정에 대해서는 독립적이고 신뢰할 수 있는 소스
