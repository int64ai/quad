# AI 서비스 실사용자 센티먼트 분석
> 조사일: 2026-02-18 | 소스: Reddit (r/productivity, r/SaaS, r/Notion, r/duolingo, r/n8n, r/automation 등) + Hacker News

---

## 1. Granola (미팅 AI 노트)

### 긍정 센티먼트
- r/SaaS 북마크 큐레이터: **"Meeting notes - Granola is my favorite"** — 다수 도구 중 1순위로 선택
- 로컬 실행(봇이 미팅에 참여하지 않음)이 핵심 차별점으로 인식됨
- HN에서 "Granola, Krisp.ai, Amie.so — they are all great"로 긍정 언급
- r/productivity: Granola를 일상적으로 쓰는 유저가 "미팅 노트용으로 쓰고 있다"고 자연스럽게 언급

### 부정 센티먼트
- r/productivity 유저: **"I used Granola for meeting notes and Bear for general notes... all three are causing me to now have too much information and actions... I seem to spend ages going back and forward on each platform"** — 정보 과부하/워크플로우 파편화 문제
- HN: "Granola AI meeting assistant being replaced?" 라는 제목의 글 존재 — 대안 서비스들의 도전
- 프라이버시 우려로 오픈소스 대안(Hyprnote) 등장: **"companies banned certain meeting notetakers due to data concerns"**

### 마케팅 vs 현실 괴리: ★★☆☆☆ (낮음)
마케팅이 약속하는 "로컬 퍼스트, 봇 없음"은 실제로 유저가 가장 좋아하는 점과 일치. 다만 워크플로우 통합 한계는 마케팅에서 잘 드러나지 않음.

### 만족도 등급: B+ (높은 만족, 니치 한계)

---

## 2. Fathom (미팅 AI)

### 긍정 센티먼트
- r/productivity 상세 비교: **"Very generous free tier. Best option if budget is the primary concern"**
- **"Summaries: Clean and useful. Action item detection is solid"**
- Zoom 특화 정확도가 높다는 평가
- 무료 티어 관대함이 반복적으로 언급됨

### 부정 센티먼트
- **"Search: Works but more limited than Fellow or Otter"** — 검색 기능이 경쟁사 대비 약함
- Zoom 중심이라 다른 플랫폼 지원 한계
- HN: **"Granola and Otter, Fathom available, but I have not found one that can transcribe and summarise on Linux"** — Linux 미지원이 개발자에게 큰 단점

### 마케팅 vs 현실 괴리: ★★☆☆☆ (낮음)
무료로 시작할 수 있다는 마케팅은 현실과 일치. "AI meeting assistant" 포지셔닝도 실제 작동함. 다만 Zoom 외 플랫폼 한계가 마케팅에서 잘 드러나지 않음.

### 만족도 등급: B+ (가성비 최강, 기능 한계)

---

## 3. Fellow.ai (미팅 AI)

### 긍정 센티먼트
- r/productivity 30개 미팅 비교 리뷰: **"Summaries: More structured and useful. Breaks down key points, decisions, action items in clear sections. Consistently captures action items that Zoom missed"**
- **"Search: This is the big differentiator. Search across all your meetings, find specific topics or decisions from months ago. Actually useful for 'wait what did we agree on' moments"**
- 미팅을 프로젝트/팀/사람별로 조직화하는 기능 호평
- 캘린더 및 타 도구와의 통합

### 부정 센티먼트
- **"Cost: Subscription adds to your stack cost. Pricing is per user"** — 유저당 과금이 팀 도입 시 부담
- Zoom 네이티브 대비 추가 비용 정당화가 필요
- 전사적 기술 용어 처리는 "marginal difference" 수준

### 마케팅 vs 현실 괴리: ★★☆☆☆ (낮음)
"미팅 관리 허브" 포지셔닝은 실제 사용자 경험과 일치. 크로스 미팅 검색이 진짜 킬러 기능이라는 점도 부합.

### 만족도 등급: A- (기능 만족, 가격 부담)

---

## 4. Otter.ai (미팅 AI)

### 긍정 센티먼트
- r/productivity: **"Strong accuracy, they've been doing this a long time. Good with different accents"**
- **"Wins on: balance of features and price"**
- **"Generous free tier for testing. Paid plans are reasonable"**
- 다양한 악센트 처리 능력 인정

### 부정 센티먼트
- **"Summaries: Basic. Better than Zoom native but not as structured as Fellow"** — 요약 품질 중간
- **"Interface is functional but not as clean"**
- HN: **"Monthly time limits"** — 사용량 제한이 헤비 유저에게 문제
- 프라이버시 우려로 이탈: 로컬 대안(Note67, Hyprnote) 개발자들이 **"Otter.ai replacement"**로 포지셔닝
- 클라우드 의존성에 대한 기업 거부감: **"companies banned certain meeting notetakers due to data concerns"**

### 이탈 사유 & 대안
- 프라이버시 → Granola, Hyprnote (로컬 퍼스트)
- 요약 품질 → Fellow.ai
- 무료 → Fathom
- 크로스 미팅 검색 → Fellow.ai

### 마케팅 vs 현실 괴리: ★★★☆☆ (중간)
"AI meeting assistant" 마케팅은 맞지만, 실사용자들은 요약 품질과 검색 기능에서 경쟁사에 뒤진다고 평가. 오래된 브랜드 인지도에 비해 혁신이 둔화.

### 만족도 등급: B (무난하지만 차별화 약화)

---

## 5. Khanmigo (교육 AI)

### 긍정 센티먼트
- HN 리스크 매니지먼트 전문가: **"I'm more confident in Khanmigo's safety and security (tailored to a young, non-adult audience)... Khan Academy incentives are not OpenAI incentives. I trust my kids alone with Khanmigo, I would not trust them alone with ChatGPT"**
- 안전성/가드레일이 핵심 차별점으로 인식
- GPT 기반이지만 fact-checking + hallucination 방지에 투자
- Sal Khan의 TED 토크가 교육자 커뮤니티에서 높은 신뢰도

### 부정 센티먼트
- 직접적 불만 데이터가 Reddit/HN에서 매우 적음 — 사용자 규모가 아직 크지 않은 것으로 추정
- HN: AI 기반 학교에 대한 비판적 기사에서 Khanmigo가 "rebranding" 수준이라는 냉소적 시각 존재
- ChatGPT Study Mode 출시로 Khanmigo의 차별점이 약화될 수 있다는 우려

### 마케팅 vs 현실 괴리: ★★☆☆☆ (낮음)
"안전한 AI 튜터"라는 포지셔닝은 실사용자(학부모) 반응과 일치. 다만 절대적 사용자 수가 적어 데이터 한계.

### 만족도 등급: B (신뢰 높음, 경험 데이터 부족)

---

## 6. Duolingo Max (교육/학습 AI)

### 긍정 센티먼트
- r/duolingo Max 1개월 사용 리뷰: **"Lily has helped me apply the words and phrases I learnt in an actual conversation. I find this extremely helpful"**
- **"Speaking and responding is such a huge part of learning the language"** — 회화 연습 기회 제공
- AI 봇과 연습하는 것이 사람과 하는 것보다 심리적 부담이 적다는 피드백
- 기본 레벨 학습자에게는 적절한 연습 도구

### 부정 센티먼트 (매우 강함)
- **"$30/month, same as full gym membership and 3-5 times what streaming services cost"** — 가격 불만 극심
- **"Duolingo certainly has betrayed their 'Making language learning possible and fun for all' mission"**
- **"I will go buy a €15 Spanish book"** — 이탈 선언
- AI 정확도 문제: **"The AI has been wrong for me multiple times"**
- Lily 봇 한계: **"Lily's ability to engage you at a more complex level on any subject is extremely limited"** / **"she doesn't really learn even when she asks you for information"**
- 고급 대화 시 벌점: **"if you attempt to have a more complex conversation... she will give you less experience points"** — 학습 의욕 저하
- 에너지 시스템 도입 반발: **"scummy and drastically limits the number of lessons you can do daily"**
- HN 장기 관찰자: **"enshittification of Duolingo... they rug-pulled the way they extracted value from the user community's posts then copyright-washed it through AI, then turned around and tried to remarket it back to said users... While laying off thousands of their contractors and translators"**
- Max 광고가 Super 구독자에게도 뜸: **"I am so annoyed by all the Duolingo max advertisements for a feature that is apparently not even worth it"**

### 마케팅 vs 현실 괴리: ★★★★★ (매우 높음)
마케팅: "AI로 언어를 더 재미있게 배우세요!" → 현실: 비싸고, AI가 부정확하고, 복잡한 대화 불가, 기존 기능은 열화. **조사 대상 중 괴리가 가장 큰 서비스.**

### 만족도 등급: D+ (강한 불만, 가격 대비 가치 의문)

---

## 7. Gamma (크리에이티브 AI - 프레젠테이션)

### 긍정 센티먼트 (매우 강함)
- B2B SaaS 세일즈 리드: **"reps can now create custom presentations in 30-40 minutes with less hand-holding"** (이전 2-3시간)
- **"Started getting feedback that our decks look 'modern' and 'like you actually understand software'"**
- **"No complaints from the team which is rare for any tool rollout"**
- 15년 파워포인트 경력자: **"Output was better than what I produce in PowerPoint despite 15 years of experience. That was humbling but also clarifying"**
- Canva 대비: **"Gamma way faster for decks"** — 1시간 vs 3-4시간
- 경쟁사 비교에서 일관된 승리:
  - Tome: **"felt very AI generated"**
  - Beautiful.ai: **"limited flexibility"**
  - Slidebean: **"still required too much manual adjustment"**
- 소셜미디어 마케터: **"Client loved strategy, approved campaign. Didn't mention presentation"** (= 프레젠테이션이 자연스러웠다)

### 부정 센티먼트
- "Close rates haven't dramatically changed" — 디자인 개선이 실매출로 직결되진 않음
- HN에서 오픈소스 대안(Presenton) 등장 — BYOK 모델로 도전
- 무료 티어에서 시작하지만 유료 전환 시 가격 데이터 부족
- 극도의 커스터마이징은 여전히 PPT 필요

### 마케팅 vs 현실 괴리: ★☆☆☆☆ (매우 낮음)
마케팅이 약속하는 "빠르고 깔끔한 프레젠테이션"이 실사용자 경험과 거의 정확히 일치. **조사 대상 중 괴리가 가장 작은 서비스.**

### 만족도 등급: A (높은 만족도, 실무 검증됨)

---

## 8. Synthesia (크리에이티브 AI - 비디오)

### 긍정 센티먼트
- HN: **"The best ones I've seen are Synthesia and HeyGen"** — 카테고리 리더 인정
- 엔터프라이즈 교육/세일즈 비디오에 주로 사용
- 다국어 지원이 글로벌 기업에 유용

### 부정 센티먼트
- HN: **"There's still a bit of 'uncanny valley' going on"** — 부자연스러움 문제 지속
- 카메라 앞에 서는 것을 대체하지만 "인간미"가 부족하다는 인식
- 가격이 엔터프라이즈 레벨로 높음
- Reddit/HN에서 구체적인 도입 후 만족도 데이터가 매우 적음 — 엔터프라이즈 특성상 공개 리뷰 한계

### 마케팅 vs 현실 괴리: ★★★☆☆ (중간)
"사람 같은 AI 아바타"를 약속하지만 uncanny valley가 여전히 존재. 기업 교육 같은 맥락에서는 괜찮지만, 마케팅/외부용으로는 부자연스러움이 문제.

### 만족도 등급: B- (용도 한정적, uncanny valley)

---

## 9. HeyGen (크리에이티브 AI - 비디오)

### 긍정 센티먼트
- SaaS 도구 목록에서 Synthesia와 함께 **"Video - HeyGen, Synthesia, Pictory"**로 반복 언급
- 립싱크/아바타 기술이 빠르게 발전 중
- 마케터/크리에이터 커뮤니티에서 인지도 높음

### 부정 센티먼트
- Synthesia와 동일한 **"uncanny valley"** 문제
- Reddit/HN에서 구체적 실사용 리뷰가 매우 적음
- 법적 우려: HN에서 **"It's Now Officially Illegal to Use AI to Impersonate a Human Actor"** 맥락에서 Synthesia/HeyGen 언급 — 규제 리스크

### 마케팅 vs 현실 괴리: ★★★☆☆ (중간)
Synthesia와 유사한 패턴. 기술 데모는 인상적이지만 실제 사용에서의 부자연스러움 + 법적 리스크.

### 만족도 등급: B- (기술은 발전 중, 실무 검증 데이터 부족)

---

## 10. n8n vs Make vs Zapier (자동화)

### Zapier
**긍정:**
- **"Feels steady and predictable. Easy to start with. You set it up and move on"**
- 기업 환경에서 안정성 인정
- Copilot + Canvas + Agents 같은 AI 기능 투자

**부정:**
- **"Incredibly expensive as they charge for each step in workflows"**
- **"Zapier's task-based pricing can spiral out of control quickly"**
- **"As workflows grow, limits become noticeable"**
- 부트스트래퍼: **"$400/month before I even have clients"**

### Make
**긍정:**
- Zapier보다 저렴, 시각적 편집기
- 컨설턴트 실사용: $536/년 지출하며 "go-to automation platform"으로 사용

**부정:**
- **"Takes forever to learn"**
- **"Over time, it became noisy. Too many steps, too many things to watch. I was fixing workflows more than actually using them"**
- **"Development was pretty slow over the last years"** — n8n에 밀림

### n8n
**긍정:**
- **"When you need real power and flexibility, n8n delivers what Zapier can't"**
- 자체 호스팅으로 완전한 데이터 제어
- **"Flat pricing — you can run thousands of operations without your bill exploding"**
- JavaScript 삽입, 서브워크플로우, 루프 등 개발자 친화적
- **"n8n having an incredible year"** — 2025년 급성장

**부정:**
- **"Requires more involvement. Setup and maintenance are part of the deal"**
- **"Self-hosting means you're managing servers... why?"**
- 비개발자에게 진입장벽 높음

### 전체 패턴
- HN: **"Automation Tools Are Overkill for 90% of People"** — 대다수에게 과도한 복잡성
- 실무자: 용도별 혼용이 일반적 (Make + n8n 동시 사용)
- AI 에이전트로의 전환 논의: **"Traditional automation is 'if this then that'. Agent groups are 'here's the goal, figure out the steps'"**

### 마케팅 vs 현실 괴리: ★★★☆☆ (중간)
세 도구 모두 "쉬운 자동화"를 마케팅하지만, 실제로는 유의미한 학습곡선 존재. 특히 Zapier의 "simple" 마케팅과 실제 비용 스케일링의 괴리가 큼.

### 만족도 등급:
- Zapier: B- (쉽지만 비쌈)
- Make: B (균형, 학습곡선)
- n8n: B+ (파워풀, 기술 요구)

---

## 11. Notion AI

### 긍정 센티먼트
- r/productivity: **"Built-in AI helps with drafting outlines or summarizing messy notes after meetings. It's not perfect, but it's solid when I'm too tired to structure my thoughts"**
- **"I'll paste in rough notes and ask it to pull out action items or make a to-do list"** — 간단한 정리 용도로 유용
- Notion 컨설턴트는 별도 AI 도구(ChatGPT, Claude)를 쓰면서도 Notion은 기반 도구로 유지

### 부정 센티먼트
- Evernote 이탈자: **"I do not need or want any AI-based features"** — AI 추가가 오히려 기피 사유
- Notion 파워유저들은 ChatGPT/Claude를 직접 쓰는 것이 더 효과적이라고 인식
- Notion AI 자체에 대한 구체적 불만보다는 **"그냥 ChatGPT 쓰면 됨"** 센티먼트가 지배적
- $10/월 추가 비용에 대해 명시적 반발은 적지만, 적극적 추천도 거의 없음
- HN: Notion의 AI를 구체적으로 칭찬하는 코멘트 발견 못함

### 마케팅 vs 현실 괴리: ★★★★☆ (높음)
마케팅: "AI가 당신의 작업 공간을 혁신합니다" → 현실: "쓸 만하지만 ChatGPT로 충분한데 왜 추가 비용을?" 기능은 작동하지만, **독립형 AI 도구 대비 경쟁력이 불분명.**

### 만족도 등급: C+ (무난하지만 돈 낼 가치 의문)

---

## 종합 매트릭스

| 서비스 | 만족도 | 마케팅 괴리 | 과금 반응 | 핵심 인사이트 |
|--------|--------|------------|----------|-------------|
| Granola | B+ | ★★☆ 낮음 | 수용적 | 로컬 퍼스트가 진짜 차별점 |
| Fathom | B+ | ★★☆ 낮음 | 매우 수용적 | 무료 티어가 최대 무기 |
| Fellow.ai | A- | ★★☆ 낮음 | 비싸지만 가치 인정 | 크로스 미팅 검색이 킬러 기능 |
| Otter.ai | B | ★★★ 중간 | 수용적 | 프라이버시 이슈로 이탈 증가 |
| Khanmigo | B | ★★☆ 낮음 | 데이터 부족 | 안전성이 유일한 차별점 |
| **Duolingo Max** | **D+** | **★★★★★ 매우 높음** | **강한 반발** | **enshittification 전형** |
| **Gamma** | **A** | **★☆ 매우 낮음** | **수용적** | **마케팅 = 현실, 드문 케이스** |
| Synthesia | B- | ★★★ 중간 | 엔터프라이즈 | uncanny valley 지속 |
| HeyGen | B- | ★★★ 중간 | 제한적 데이터 | 규제 리스크 부상 |
| n8n | B+ | ★★★ 중간 | 가성비 좋음 | 개발자에게 최적 |
| Make | B | ★★★ 중간 | 수용적 | 학습곡선이 숨겨진 비용 |
| Zapier | B- | ★★★ 중간 | 비싸다는 불만 | 단순함 ↔ 가격의 트레이드오프 |
| Notion AI | C+ | ★★★★ 높음 | 가치 의문 | ChatGPT가 있는데 왜? |

---

## 핵심 발견사항

### 1. 마케팅과 현실이 가장 괴리되는 서비스
- **Duolingo Max**: 가격 폭리, AI 부정확, 기존 기능 열화 → 유저 이탈 선언 다수
- **Notion AI**: "혁신적 AI"라 하지만 실사용자는 ChatGPT/Claude가 더 낫다고 인식

### 2. 마케팅과 현실이 가장 일치하는 서비스
- **Gamma**: 빠르고 깔끔한 프레젠테이션이라는 약속을 정확히 이행
- **Fathom**: 무료로 좋은 품질이라는 포지셔닝이 현실과 일치

### 3. 공통 이탈 패턴
- **가격 스케일링**: Zapier, Duolingo Max에서 가장 두드러짐
- **프라이버시**: Otter.ai → Granola/로컬 대안으로 이동
- **AI가 "그냥 됨" vs "쓸모없음"**: 미팅 AI(75:25), Gamma(90:10), Duolingo Max(40:60), Notion AI(50:50)

### 4. 블루오션 시사점
- **미팅 AI**: 시장은 성숙기. 프라이버시 + 로컬 퍼스트가 다음 물결. Granola 모델이 유망
- **교육 AI**: Khanmigo의 "안전한 AI" 접근은 부모에게 유효하지만 ChatGPT Study Mode에 위협받음
- **프레젠테이션 AI**: Gamma가 카테고리 킬러. 진입 어려운 시장
- **AI 비디오**: uncanny valley가 핵심 허들. 기술 성숙까지 2-3년 필요
- **자동화**: AI 에이전트가 전통 자동화를 대체하기 시작 — n8n이 이 전환에 가장 빠르게 적응 중
