# 🔮 2026 하반기 전망 & 주시 포인트

> 출처: AI 업계 지형도 2025-2026 핵심 인사이트 #08 (2026-02-17 기준)

---

## 5대 주시 포인트

### ① GPT-5 패밀리의 코딩 임팩트
- GPT-5.2 + Codex 조합이 **Claude Code 독주를 깨뜨릴 수 있는가?**
- Windsurf 인수 무산 후 OpenAI의 IDE 전략이 관건
- 현재: 코딩은 Claude, 범용은 GPT — 이 공식이 바뀌는가?

### ② Gemini 3 생태계 확전
- Deep Think: ARC-AGI-2 **84.6%** (추론 SOTA)
- **650M+** Gemini 사용자에게 에이전트 기능 본격 확산되면?
- 가격 대비 성능 최강 (Flash $0.50/$3/M으로 SWE-bench 78%)

### ③ SaaS 비즈니스 모델 재편
- SaaSpocalypse (2026.02) 이후 좌석 기반 과금 → API/에이전트 기반 전환 중
- **Salesforce·ServiceNow의 적응 속도**가 시장 회복의 신호
- Forrester: "우리가 아는 SaaS는 죽었다"

### ④ 로컬 모델의 프로덕션 침투
- Qwen 3.5 (397B/17B MoE), DeepSeek V3.2가 기업 내부에 얼마나 깊이 들어갈 수 있는가
- **오픈웨이트의 진짜 해자 = 데이터 프라이버시**
- 지역별 분화: EU → Mistral, 미국 → Llama/DeepSeek, 아시아 → Qwen

### ⑤ Claude Code → GitHub 커밋 20% 전망
- SemiAnalysis 예측이 현실화되면, **소프트웨어 개발의 근본 구조가 바뀐다**
- 현재 4% (2026.02) → 연말 20%+
- Anthropic 자체에서 "코딩의 70%를 AI가 한다"고 발표

---

## 분야별 전망

### LLM / 기초 모델
- 3강 구도 확정: OpenAI vs Anthropic vs Google
- 성능 수렴 → 차별화는 **에이전트 역량** + **가격** + **생태계**로 이동
- 오픈웨이트(DeepSeek, Qwen, Mistral)가 프론티어와 1~2단계 격차로 근접

### 코딩 AI
- AI IDE = "역사상 가장 빠르게 성장하는 SaaS 카테고리"
- 2025.12 기준 시장 **$3.1B**, 2028년 **$12.6B** 전망
- 승자독식 아님 — Claude Code(터미널/에이전트), Cursor(IDE), Copilot(워크플로우), Codex(비동기) 공존
- **코딩의 의미가 바뀜**: 주니어 반복작업 → AI, 시니어 아키텍처 판단 → 인간

### 이미지 생성
- 저작권 소송이 업계 규칙을 결정 (디즈니+워너 vs Midjourney 병합 소송)
- 로컬: FLUX.2 Klein FP8이 8GB VRAM에서 실용 구동 → 월 구독 없이 프로급 결과물
- "저작권 안전" 포지셔닝 (Adobe Firefly) 기업 시장에서 급부상

### 비디오 생성
- Veo 3 (오디오 동기 생성) vs Kling (2개월마다 메이저 버전업) vs Runway (벤치마크 1위 탈환)
- 중국 AI의 속도 vs 서양 저작권 장벽 동시 부각
- 오픈소스: HunyuanVideo 1.5 + Wan 2.2 → "비디오 생성의 Stable Diffusion 모먼트"

### 음성 / 음악
- ElevenLabs $11B → 음성 AI가 단독 $10B+ 카테고리 증명
- AI 음악: "고소→합의→라이선싱" 공식 정착 (UMG·WMG-Suno/Udio)
- AI 음악 스팸: Deezer 탐지 — 하루 6만 곡(전체 39%)이 AI 생성
- 음성 에이전트: OpenAI gpt-realtime로 TTS → 실시간 대화 에이전트 진화

### AI 에이전트
- 프레임워크 전쟁 종결 → **패턴 전쟁** (Hub-and-Spoke, Human-in-the-Loop, Guard Rail)
- MCP 보안이 2026 핵심 과제 (서버 43%에 취약점)
- 엔터프라이즈: 파일럿 → 프로덕션은 **연 단위** 프로젝트
- "에이전트 인터넷" 실험 (Moltbook) — 가능성과 위험 동시 부각
