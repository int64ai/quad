# AI 업계 지형도 Knowledge Base
> 기준일: 2026-02-17 | 원본: canvas/ai-landscape-2025.html (255KB)

## 사용법
- 이 README만 로드하면 전체 서열/핵심 요약 확인 가능
- 깊은 내용이 필요하면 해당 카테고리 파일을 읽을 것
- 교차 인사이트는 `meta/cross-insights.md` 참고

---

## 현재 서열 요약 (2026.02)

### LLM
- **코딩**: Claude Opus 4.6 > Sonnet 4.6 ≈ GPT-5.2 > Gemini 3 Pro
- **추론**: Gemini 3 Deep Think (ARC-AGI-2 84.6%) > Grok 4 Heavy > o3
- **가성비**: Gemini 3 Flash ($0.50/$3) > GPT-4.1 mini > Haiku 4.5
- **오픈웨이트**: DeepSeek V3.2 ≈ Qwen 3.5 > Mistral Large 3 > Llama 4
- **X 데이터 특화**: Grok 4/Heavy (실시간 센티먼트, Grok 4.20 출시 임박)
- 핵심: "최고의 모델"은 없고, "이 작업에 최적의 모델"만 있다

### AI 검색
- **도전자**: Perplexity (30M MAU, $656M 매출 목표)
- **통합형**: ChatGPT Search, Google AI Overviews
- 핵심: 검색의 재정의가 진행 중이지만 Google 독점은 아직 건재

### Apple Intelligence
- 온디바이스 + Private Cloud Compute, 프라이버시 중심 전략
- 핵심: 소비자 시장 침투력은 압도적이나 기능 깊이에서 아직 초기

### 엔터프라이즈 AI
- Microsoft Copilot M365, Salesforce Agentforce, ServiceNow, SAP Joule
- 핵심: 마케팅 vs 현실 괴리가 가장 큰 영역

### 코딩 AI
- **IDE**: Cursor (ARR $1B, $29.3B 밸류)
- **터미널**: Claude Code (ARR $2.5B, GitHub 커밋 4%→20% 전망)
- **비동기**: Codex (GPT-5-Codex, 7시간+ 연속)
- **볼륨**: GitHub Copilot (180만 유료, $10/월)
- **과대평가**: Devin (실사용 성공률 15%, $10.2B 밸류)
- 핵심: 코딩 AI = 역사상 가장 빠르게 성장하는 SaaS 카테고리

### 이미지 생성
- **종합/접근성**: GPT-4o Image (지브리파이 바이럴, 텍스트 렌더링 최강)
- **미학**: Midjourney V7 (디즈니+워너 소송 리스크)
- **오픈소스/인프라**: FLUX ($4B, Adobe·Grok·Meta 배후)
- **저작권 안전**: Adobe Firefly
- 핵심: 승자는 "생성"이 아니라 "편집"을 장악한 자

### 비디오 생성
- **오디오 동기화**: Veo 3/3.1 (킬러피쳐, 아무도 못 따라잡음)
- **스펙**: Kling 3.0 (4K/60FPS, 5개국어 립싱크)
- **벤치마크**: Runway Gen-4.5 (1위 탈환)
- **오픈소스**: HunyuanVideo + Wan (비디오의 SD/FLUX)
- **과대평가**: Sora (약속만 반복, 다운로드 -45%)
- 핵심: 체리피킹 주의. 모든 회사가 상위 1-5% 결과만 보여줌

### 오디오/음악
- **음악**: Suno (Studio 1.2로 DAW 진화, $2.45B)
- **플랫폼**: ElevenLabs ($11B, 가장 넓은 오디오 플랫폼)
- **팟캐스트**: NotebookLM (문서→팟캐스트 독보적)
- **미래**: Sesame/CSM (가장 자연스러운 대화형 음성)
- 핵심: UMG/WMG 라이선싱 파도 → "다 긁어 훈련" 시대 종료

### AI 에이전트
- **인프라 표준**: MCP ("AI의 HTTP", 12개월 만에 테이블 스테이크)
- **소비자**: ChatGPT 에이전트 모드 (Operator 통합)
- **프레임워크**: Agents SDK, n8n AI, LangGraph
- 핵심: 프레임워크 전쟁은 끝, 패턴 전쟁이 시작

---

## 도메인 관통 핵심 교훈 (→ meta/cross-insights.md)
1. DeepSeek가 비용 장벽을 깨부쉈다 — $6M으로 프론티어급
2. 2025년 진짜 승자는 모델이 아니라 도구
3. 토큰 비용 98% 폭락 — 그런데 총 지출은 늘었다 (제본스 패러독스)
4. 벤치마크는 거짓말한다 — Meta "fudged", LM Arena 독립성 의혹
5. 저작권법이 기술보다 승자를 결정
6. 오픈웨이트 격차 축소 중이지만, "근접 ≠ 동등"
7. 데모 ≠ 프로덕션 — 자율 AI 마케팅 vs 현실 괴리

---

## 디렉토리 구조
```
knowledge/
├── README.md              ← 지금 이 파일 (인덱스 + 서열 요약)
├── llm/
│   ├── landscape.md       ← 10개 플레이어 상세
│   └── insights.md        ← LLM 트렌드/인사이트
├── coding/
│   ├── landscape.md       ← 8개 플레이어 상세
│   └── insights.md        ← 코딩 AI 트렌드/인사이트
├── image/
│   ├── landscape.md       ← 8개 플레이어 상세
│   └── insights.md        ← 이미지 생성 트렌드
├── video/
│   ├── landscape.md       ← 8개 플레이어 상세
│   └── insights.md        ← 비디오 생성 트렌드
├── audio/
│   ├── landscape.md       ← 플레이어 상세
│   └── insights.md        ← 오디오/음악 트렌드
├── agents/
│   ├── landscape.md       ← 플레이어 상세
│   └── insights.md        ← 에이전트/자동화 트렌드
├── meta/
│   ├── cross-insights.md  ← 도메인 관통 교훈 11개
│   ├── predictions.md     ← 2026 하반기 전망
│   └── timeline.md        ← 핵심 이벤트 연표 (역순)
└── comparisons/
    ├── coding-tools.md    ← Claude Code vs Codex vs Cursor vs OpenClaw
    └── architecture.md    ← Agent Team vs Subagent
```
├── search/
│   ├── landscape.md       ← AI 검색 플레이어 (Perplexity, ChatGPT Search, Google AI Overviews)
│   └── insights.md        ← 검색 재정의 트렌드
├── apple/
│   └── landscape.md       ← Apple Intelligence 현황
└── enterprise/
    └── landscape.md       ← 엔터프라이즈 AI (Microsoft Copilot M365, Salesforce, ServiceNow)
```
총 22개+ 파일
